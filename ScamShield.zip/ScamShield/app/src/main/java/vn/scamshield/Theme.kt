package vn.scamshield

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Bảng màu theo thiết kế: nền xanh navy, nâu + vàng ở màn hình chính, xanh ngọc ở màn hình đăng nhập. */
object C {
    val Bg = Color(0xFF0E1A36)
    val Bar = Color(0xFF0B1630)
    val Brown = Color(0xFF3A2B28)
    val Gold = Color(0xFFFFC21A)
    val Tile = Color(0xFF1FB57A)
    val Label = Color(0xFF2FB58F)
    val Ok = Color(0xFF3DDC97)
    val Warn = Color(0xFFFBBF24)
    val Bad = Color(0xFFF87171)
    val Sub = Color(0xFFCBD5E1)
    val Dim = Color(0xFF94A3B8)
    val LoginBg = Color(0xFF212B40)
    val Blob = Color(0xFF4A6A94)
    val Teal = Color(0xFF9ACFD4)
    val Ink = Color(0xFF1B2540)
}

/** Ô nhập dạng viên thuốc (bo tròn hai đầu). */
@Composable fun PillField(
    value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier,
    password: Boolean = false, bg: Color = Color.White, fg: Color = C.Ink, center: Boolean = true, trailing: String? = null
) {
    BasicTextField(value, onChange, modifier.fillMaxWidth(), singleLine = true,
        textStyle = TextStyle(color = fg, fontSize = 15.sp, textAlign = if (center) TextAlign.Center else TextAlign.Start),
        cursorBrush = SolidColor(fg),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        decorationBox = { inner ->
            Box(Modifier.fillMaxWidth().height(46.dp).background(bg, RoundedCornerShape(23.dp)).padding(horizontal = 18.dp),
                contentAlignment = if (center) Alignment.Center else Alignment.CenterStart) {
                if (value.isEmpty()) Text(hint, color = fg.copy(alpha = 0.55f), fontSize = 14.sp, maxLines = 1)
                inner()
                if (trailing != null) Box(Modifier.align(Alignment.CenterEnd)) { Text(trailing, fontSize = 18.sp) }
            }
        })
}

/** Khối nền nâu bo góc dùng cho thẻ nội dung. */
@Composable fun Card2(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.fillMaxWidth().background(C.Brown, RoundedCornerShape(20.dp)).padding(16.dp), Arrangement.spacedBy(10.dp), content = content)

@Composable fun GoldButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) =
    Button(onClick, modifier.fillMaxWidth(), enabled = enabled, shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(containerColor = C.Gold, contentColor = Color(0xFF2A1F00),
            disabledContainerColor = C.Gold.copy(alpha = 0.35f), disabledContentColor = Color(0xFF2A1F00).copy(alpha = 0.5f))) {
        Text(text, fontWeight = FontWeight.Bold) }

@Composable fun GhostButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) =
    OutlinedButton(onClick, modifier.fillMaxWidth(), enabled = enabled, shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, C.Gold.copy(alpha = 0.6f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = C.Gold)) { Text(text) }

@Composable fun SectionTitle(t: String) = Text(t, color = C.Dim, fontSize = 20.sp, fontWeight = FontWeight.Medium)

/** Ô danh mục: khối vuông xanh lá + nhãn. */
@Composable fun CatTile(icon: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) =
    Column(modifier.clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(66.dp).background(C.Tile, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Text(icon, fontSize = 30.sp) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = C.Label, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
    }

/** Thẻ đề xuất cuộn ngang. */
@Composable fun RecCard(icon: String, title: String, badge: String, grad: List<Color>, onClick: () -> Unit) =
    Column(Modifier.width(132.dp).clickable(onClick = onClick), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().height(150.dp).background(Brush.verticalGradient(grad), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 52.sp) }
        Text(title, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 2)
        Box(Modifier.background(C.Brown, RoundedCornerShape(14.dp)).padding(horizontal = 10.dp, vertical = 4.dp)) {
            Text(badge, color = C.Sub, fontSize = 11.sp, maxLines = 1) }
    }
