package vn.scamshield

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Bảng màu: nền navy đậm, thẻ nổi nhẹ có viền mảnh, MỘT màu nhấn xanh ngọc. Vàng/đỏ chỉ dùng cho cảnh báo. */
object C {
    val Bg = Color(0xFF0B1220)
    val Surface = Color(0xFF141D31)
    val SurfaceHi = Color(0xFF1B2640)
    val Field = Color(0xFF1B2640)
    val Stroke = Color(0xFF26324D)
    val Accent = Color(0xFF34D399)
    val AccentSoft = Color(0x2634D399)
    val OnAccent = Color(0xFF05261B)
    val Bar = Color(0xFF0F172A)
    val Ok = Color(0xFF4ADE80)
    val Warn = Color(0xFFFBBF24)
    val Bad = Color(0xFFF87171)
    val Sub = Color(0xFFCBD5E1)
    val Dim = Color(0xFF8A97AD)

    // Tên cũ giữ lại để các màn hình khác vẫn dùng được, nay trỏ về bảng màu mới.
    val Brown = Surface
    val Gold = Accent
    val Tile = Accent
    val Teal = Accent
    val Ink = OnAccent
    val Label = Sub
    val LoginBg = Bg
    val Blob = Surface
}

val Shape16 = RoundedCornerShape(16.dp)
val Shape24 = RoundedCornerShape(24.dp)

/** Ô nhập bo góc, nền tối, tùy chọn biểu tượng đầu dòng. */
@Composable fun PillField(
    value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier,
    password: Boolean = false, bg: Color = C.Field, fg: Color = Color.White, center: Boolean = false,
    trailing: String? = null, leading: String? = null
) {
    BasicTextField(value, onChange, modifier.fillMaxWidth(), singleLine = true,
        textStyle = TextStyle(color = fg, fontSize = 15.sp, textAlign = if (center) TextAlign.Center else TextAlign.Start),
        cursorBrush = SolidColor(C.Accent),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        decorationBox = { inner ->
            Row(Modifier.fillMaxWidth().height(54.dp).background(bg, Shape16).border(1.dp, C.Stroke, Shape16).padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (leading != null) Text(leading, fontSize = 18.sp)
                Box(Modifier.weight(1f), contentAlignment = if (center) Alignment.Center else Alignment.CenterStart) {
                    if (value.isEmpty()) Text(hint, color = C.Dim, fontSize = 14.sp, maxLines = 1)
                    inner()
                }
                if (trailing != null) Text(trailing, fontSize = 18.sp)
            }
        })
}

/** Thẻ nội dung: nền nổi nhẹ, viền mảnh, đệm rộng. */
@Composable fun Card2(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.fillMaxWidth().background(C.Surface, Shape24).border(1.dp, C.Stroke, Shape24).padding(20.dp),
        Arrangement.spacedBy(12.dp), content = content)

@Composable fun GoldButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) =
    Button(onClick, modifier.fillMaxWidth().height(52.dp), enabled = enabled, shape = Shape16,
        colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent,
            disabledContainerColor = C.Accent.copy(alpha = 0.3f), disabledContentColor = C.OnAccent.copy(alpha = 0.6f))) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp) }

@Composable fun GhostButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) =
    OutlinedButton(onClick, modifier.fillMaxWidth().height(52.dp), enabled = enabled, shape = Shape16,
        border = BorderStroke(1.dp, C.Stroke),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text(text, fontSize = 14.sp) }

@Composable fun SectionTitle(t: String) = Text(t, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)

/** Nút tròn nhỏ (quay lại, cài đặt…). */
@Composable fun IconBtn(icon: String, onClick: () -> Unit) =
    Box(Modifier.size(44.dp).background(C.Surface, CircleShape).border(1.dp, C.Stroke, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) { Text(icon, fontSize = 18.sp, color = Color.White) }

/** Nhãn chọn (bộ lọc, danh mục bài đăng). */
@Composable fun Chip(text: String, on: Boolean, onClick: () -> Unit) =
    Box(Modifier.background(if (on) C.Accent else C.SurfaceHi, RoundedCornerShape(12.dp)).clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 9.dp)) {
        Text(text, color = if (on) C.OnAccent else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }

/** Ô danh mục: khối bo góc nền màu nhạt + nhãn. */
@Composable fun CatTile(icon: String, label: String, modifier: Modifier = Modifier, tint: Color = C.Accent, onClick: () -> Unit) =
    Column(modifier.clickable(onClick = onClick).padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(60.dp).background(tint.copy(alpha = 0.16f), RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 26.sp) }
        Spacer(Modifier.height(8.dp))
        Text(label, color = C.Sub, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 15.sp)
    }

/** Thẻ đề xuất dạng lưới 2 cột. */
@Composable fun FeatureCard(icon: String, title: String, badge: String, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) =
    Column(modifier.background(C.Surface, RoundedCornerShape(22.dp)).border(1.dp, C.Stroke, RoundedCornerShape(22.dp))
        .clickable(onClick = onClick).padding(16.dp), Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(44.dp).background(tint.copy(alpha = 0.18f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 22.sp) }
        Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, minLines = 2)
        Text(badge, color = tint, fontSize = 12.sp, maxLines = 1)
    }
