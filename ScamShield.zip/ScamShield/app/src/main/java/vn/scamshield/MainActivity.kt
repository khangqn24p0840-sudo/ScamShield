package vn.scamshield
import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONObject
import vn.scamshield.face.FaceBus

private val Ink = Color(0xFF0A1633); private val Blue = Color(0xFF1B4DB3)
private val Ok = Color(0xFF34D399); private val Warn = Color(0xFFFBBF24); private val Bad = Color(0xFFF87171)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    private val roleL = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    private val permL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    var aiMsg by mutableStateOf("")
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (bytes.size > 5_000_000) aiMsg = "Ảnh quá lớn (tối đa 5MB)" else {
                aiMsg = "Đang kiểm tra ảnh…"
                Api.call(this, "POST", "/api/analyze/media", JSONObject().put("mime", contentResolver.getType(uri) ?: "image/jpeg")
                    .put("data", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))) { code, j -> aiMsg = fmtMedia(code, j) }
            }
        } catch (e: Exception) { aiMsg = "Không đọc được ảnh" }
    }
    private val captureL = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null)
            androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, ScreenFaceService::class.java).putExtra("code", r.resultCode).putExtra("data", r.data))
    }

    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } } }
    override fun onResume() { super.onResume(); tick++ }

    private val recL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++; if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListen()
    }
    private fun startListen() { ListenService.running = true; androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java)); tick++ }
    private val callPermL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
        if (Build.VERSION.SDK_INT >= 29 && !roleOn()) roleL.launch(getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
    }
    private fun roleOn() = Build.VERSION.SDK_INT >= 29 && getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
    private fun permsOn() = PhoneStateReceiver.perms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    private fun callOn() = roleOn() || permsOn()
    private fun smsOn() = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    @Composable private fun Panel(content: @Composable ColumnScope.() -> Unit) = Card(
        Modifier.fillMaxWidth(), RoundedCornerShape(22.dp),
        CardDefaults.cardColors(Color(0x26FFFFFF), Color.White)) { Column(Modifier.padding(18.dp), Arrangement.spacedBy(10.dp), content = content) }

    @Composable private fun Stat(n: Int, label: String, col: Color, m: Modifier) = Column(
        m.background(Color(0x26FFFFFF), RoundedCornerShape(18.dp)).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$n", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = col); Text(label, fontSize = 12.sp, color = Color(0xFFCBD5E1)) }

    @Composable private fun App() {
        val t = tick; val c = this
        var input by remember { mutableStateOf("") }
        var res by remember { mutableStateOf<Result?>(null) }
        var num by remember { mutableStateOf("") }
        val protectedAll = callOn() && smsOn()
        LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Ink, Blue))).statusBarsPadding().navigationBarsPadding(),
            contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("ScamShield VN", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("Chặn cuộc gọi & tin nhắn lừa đảo", color = Color(0xFFCBD5E1))
                Text("Phiên bản " + packageManager.getPackageInfo(packageName, 0).versionName, fontSize = 12.sp, color = Color(0xFF94A3B8)) }
            item { Panel {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(if (protectedAll) "🛡️" else "⚠️", fontSize = 44.sp)
                    Column { Text(if (protectedAll) "Đang được bảo vệ" else "Chưa bật đủ bảo vệ", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = if (protectedAll) Ok else Warn)
                        Text("Cuộc gọi: ${if (callOn()) "Bật" else "Tắt"}  •  Tin nhắn: ${if (smsOn()) "Bật" else "Tắt"}", fontSize = 13.sp) } }
                if (!callOn()) Button({ callPermL.launch(PhoneStateReceiver.perms()) }, Modifier.fillMaxWidth()) { Text("Bật chặn cuộc gọi") }
                if (!smsOn()) Button({ permL.launch(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS)) }, Modifier.fillMaxWidth()) { Text("Bật cảnh báo tin nhắn") }
            } }
            item { Panel {
                Text("Cảnh báo nâng cao", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                val ov = android.provider.Settings.canDrawOverlays(c); val sc = SocialListener.enabled(c)
                Text("Viền màn hình vàng/đỏ: ${if (ov) "Bật" else "Tắt"}  •  Quét Zalo, Messenger…: ${if (sc) "Bật" else "Tắt"}", fontSize = 13.sp)
                if (!ov) Button({ startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))) }, Modifier.fillMaxWidth()) { Text("Bật viền cảnh báo màn hình") }
                if (!sc) Button({ startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("Bật quét thông báo mạng xã hội") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ Alerter.fire(c, 1) }, Modifier.weight(1f)) { Text("Thử vàng") }
                    OutlinedButton({ Alerter.fire(c, 2) }, Modifier.weight(1f)) { Text("Thử đỏ") } }
            } }
            item { Panel {
                Text("🎙️ Nghe cuộc gọi qua loa ngoài", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("Khi số lạ gọi tới: bắt máy, bật loa ngoài rồi bấm bắt đầu. App phân tích lời nói và cảnh báo nếu có dấu hiệu lừa đảo.", fontSize = 13.sp)
                Button({ if (ListenService.running) { ListenService.running = false; stopService(Intent(c, ListenService::class.java)); tick++ }
                    else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListen()
                    else recL.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)) },
                    Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (ListenService.running) Bad else Blue)) {
                    Text(if (ListenService.running) "Dừng nghe" else "Bắt đầu nghe") }
            } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat(Store.count(c, "blocked"), "Đã chặn", Bad, Modifier.weight(1f)); Stat(Store.count(c, "warned"), "Đã cảnh báo", Warn, Modifier.weight(1f)); Stat(Store.blocklist(c).size, "Số bị chặn", Ok, Modifier.weight(1f)) } }
            item { Panel {
                Text("Kiểm tra tin nhắn / nội dung chat", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), placeholder = { Text("Dán nội dung nghi ngờ vào đây…") }, minLines = 3)
                Button({ res = ScamDetector.analyze(input) }, Modifier.fillMaxWidth(), enabled = input.isNotBlank()) { Text("Phân tích") }
                res?.let { r -> val col = listOf(Ok, Warn, Bad)[r.level]
                    Text(listOf("✅ Chưa thấy dấu hiệu lừa đảo", "⚠️ Đáng ngờ", "🚨 Rất có thể là LỪA ĐẢO")[r.level] + "  (${r.score}/100)", color = col, fontWeight = FontWeight.Bold)
                    r.reasons.forEach { Text("• $it", fontSize = 13.sp) } }
            } }
            item { Panel {
                Text("Danh sách chặn", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(num, { num = it }, Modifier.weight(1f), placeholder = { Text("Số điện thoại") }, singleLine = true)
                    Button({ Store.addBlock(c, num); num = ""; tick++ }) { Text("Chặn") } }
                Store.blocklist(c).forEach { n -> Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text(n); TextButton({ Store.removeBlock(c, n); tick++ }) { Text("Bỏ chặn") } } }
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text("Chặn mọi số nước ngoài (+ khác +84)", Modifier.weight(1f), fontSize = 14.sp)
                    Switch(Store.blockForeign(c), { Store.setBlockForeign(c, it); tick++ }) }
            } }
            item { Text("Lịch sử cảnh báo", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White) }
            val h = Store.history(c)
            if (h.isEmpty()) item { Text("Chưa có cảnh báo nào.", color = Color(0xFFCBD5E1)) }
            items(h) { e -> Panel {
                Text(e[2], fontWeight = FontWeight.Bold, color = if (e[1] == "2") Bad else Warn)
                Text(e[3], fontSize = 13.sp, maxLines = 3)
                Text(SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(Date(e[0].toLong())), fontSize = 11.sp, color = Color(0xFF94A3B8)) } }
            item { FacePanel({ captureL.launch(getSystemService(android.media.projection.MediaProjectionManager::class.java).createScreenCaptureIntent()) },
                { stopService(Intent(c, ScreenFaceService::class.java)); FaceBus.running = false }) }
            item { AiPanel(c, aiMsg, { picker.launch("image/*") }) { aiMsg = it } }
            item { AccountPanel(c) }
            item { SurveyPanel(c) }
            item { Text("Mẹo: ngân hàng, công an không bao giờ yêu cầu OTP hay chuyển tiền qua điện thoại.", fontSize = 12.sp, color = Color(0xFFCBD5E1)) }
        }
    }
}
