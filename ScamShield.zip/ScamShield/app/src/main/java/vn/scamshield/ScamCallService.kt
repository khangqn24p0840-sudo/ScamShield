package vn.scamshield
import android.telecom.Call
import android.telecom.CallScreeningService

class ScamCallService : CallScreeningService() {
    override fun onScreenCall(d: Call.Details) {
        val num = d.handle?.schemeSpecificPart ?: ""
        val foreign = num.startsWith("+") && !num.startsWith("+84")
        val block = Store.isBlocked(this, num) || (foreign && Store.blockForeign(this))
        if (block) {
            respondToCall(d, CallResponse.Builder().setDisallowCall(true).setRejectCall(true).setSkipCallLog(false).setSkipNotification(true).build())
            Store.log(this, 2, "Đã chặn cuộc gọi", num)
            Notifier.show(this, "🛡️ Đã chặn cuộc gọi lừa đảo", "Số $num nằm trong danh sách chặn.")
        } else {
            respondToCall(d, CallResponse.Builder().build())
            if (foreign) {
                Store.log(this, 1, "Cuộc gọi quốc tế lạ", num)
                Notifier.show(this, "⚠️ Cuộc gọi từ số nước ngoài", "$num – cẩn thận, không cung cấp OTP hay chuyển tiền.")
            }
        }
    }
}
