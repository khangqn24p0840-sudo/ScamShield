package vn.scamshield

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import vn.scamshield.face.FaceBus

/** Khung trang con: nút quay lại + tiêu đề + nội dung cuộn. */
@Composable fun Page(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) Text("←", color = C.Gold, fontSize = 26.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 14.dp, top = 4.dp, bottom = 4.dp))
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        content()
    }
}

@Composable fun SubScreen(c: Context, h: Hooks, sub: String, back: () -> Unit, open: (String) -> Unit) {
    when (sub) {
        "all" -> HistoryScreen(c, 0, back)
        "blocked" -> HistoryScreen(c, 2, back)
        "video" -> Page("Video Call Deepfake", back) { FacePanel(h.startFace, h.stopFace) }
        "blocklist" -> BlocklistScreen(c, back)
        "msg" -> MessageScreen(c, back, open)
        "social" -> SocialScreen(c, h, back)
        "malware", "link" -> MalwareScreen(c, back)
        "ai" -> Page("Yêu cầu AI", back) { AiPanel(c, h.aiMsg(), h.pickImage) { h.setAiMsg(it) } }
        "live" -> LiveScreen(h, back)
        "stats" -> StatsScreen(c, back)
        else -> OtherScreen(c, back)
    }
}

@Composable fun ResultCard(r: Result) {
    val col = listOf(C.Ok, C.Warn, C.Bad)[r.level]
    Card2 {
        Text(listOf("✅ Chưa thấy dấu hiệu lừa đảo", "⚠️ Đáng ngờ", "🚨 Rất có thể là LỪA ĐẢO")[r.level] + "  (${r.score}/100)", color = col, fontWeight = FontWeight.Bold)
        r.reasons.forEach { Text("• $it", fontSize = 13.sp, color = Color.White) }
        if (r.level == 0) Text("Chưa thấy dấu hiệu không có nghĩa là chắc chắn an toàn. Đừng đọc OTP hay chuyển tiền cho người lạ.", fontSize = 12.sp, color = C.Sub)
    }
}

// ───────────────────────── Nhật ký ─────────────────────────

@Composable fun HistoryRow(e: List<String>) {
    val bad = e[1] == "2"
    Card2 {
        Text((if (bad) "🚫 " else "⚠️ ") + e[2], fontWeight = FontWeight.Bold, color = if (bad) C.Bad else C.Warn)
        Text(e[3], fontSize = 13.sp, maxLines = 3, color = Color.White)
        Text(SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(Date(e[0].toLong())), fontSize = 11.sp, color = C.Dim)
    }
}

@Composable fun HistoryScreen(c: Context, initial: Int, back: (() -> Unit)?) {
    var f by remember(initial) { mutableIntStateOf(initial) }
    Page("Nhật ký cảnh báo", back) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Tất cả", "Cảnh báo", "Đã chặn").forEachIndexed { i, t ->
                Box(Modifier.background(if (f == i) C.Gold else C.Brown, RoundedCornerShape(16.dp)).clickable { f = i }.padding(horizontal = 14.dp, vertical = 7.dp)) {
                    Text(t, color = if (f == i) Color(0xFF2A1F00) else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
        val all = Store.history(c)
        val list = when (f) { 1 -> all.filter { it[1] == "1" }; 2 -> all.filter { it[1] == "2" }; else -> all }
        if (list.isEmpty()) Text("Chưa có mục nào.", color = C.Sub)
        list.forEach { HistoryRow(it) }
    }
}

// ───────────────────────── Tin nhắn ─────────────────────────

@Composable fun MessageScreen(c: Context, back: (() -> Unit)?, open: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    var res by remember { mutableStateOf<Result?>(null) }
    Page("Kiểm tra tin nhắn", back) {
        Text("Dán nội dung tin nhắn, lời thoại hoặc link nghi ngờ. Phân tích nhanh chạy ngay trong máy, không gửi đi đâu.", fontSize = 13.sp, color = C.Sub)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = { Text("Dán nội dung nghi ngờ vào đây…") }, minLines = 4)
        GoldButton("Phân tích nhanh (trong máy)", enabled = text.isNotBlank()) { res = ScamDetector.analyze(text) }
        res?.let { ResultCard(it) }
        GhostButton("Phân tích sâu bằng AI (cần đăng nhập)") { open("ai") }
    }
}

// ───────────────────────── Cài đặt ─────────────────────────

@Composable fun SettingsTab(c: Context, h: Hooks) {
    h.tick()
    var rev by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val r0 = rev
    Page("Cài đặt bảo vệ", null) {
        val callOn = h.callOn(); val smsOn = h.smsOn()
        val ov = Settings.canDrawOverlays(c); val sc = SocialListener.enabled(c)
        Card2 {
            Text("Bảo vệ cơ bản", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Chặn cuộc gọi: ${if (callOn) "Bật" else "Tắt"}  •  Cảnh báo tin nhắn: ${if (smsOn) "Bật" else "Tắt"}", fontSize = 13.sp)
            if (!callOn) GoldButton("Bật chặn cuộc gọi") { h.enableCalls() }
            if (!smsOn) GoldButton("Bật cảnh báo tin nhắn") { h.enableSms() }
        }
        Card2 {
            Text("Cảnh báo nâng cao", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Viền màn hình vàng/đỏ: ${if (ov) "Bật" else "Tắt"}  •  Quét Zalo, Messenger…: ${if (sc) "Bật" else "Tắt"}", fontSize = 13.sp)
            if (!ov) GoldButton("Bật viền cảnh báo màn hình") { h.openOverlay() }
            if (!sc) GoldButton("Bật quét thông báo mạng xã hội") { h.openSocial() }
        }
        Card2 {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Chặn mọi số nước ngoài (+ khác +84)", Modifier.weight(1f), fontSize = 14.sp)
                Switch(Store.blockForeign(c), { Store.setBlockForeign(c, it); rev++ })
            }
        }
        Card2 {
            Text("Thử cảnh báo", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Thử vàng", Modifier.weight(1f)) { Alerter.fire(c, 1) }
                GhostButton("Thử đỏ", Modifier.weight(1f)) { Alerter.fire(c, 2) }
            }
        }
        Text("ScamShield VN • phiên bản " + c.packageManager.getPackageInfo(c.packageName, 0).versionName, fontSize = 12.sp, color = C.Dim)
    }
}

// ───────────────────────── Số lừa đảo ─────────────────────────

@Composable fun BlocklistScreen(c: Context, back: () -> Unit) {
    var rev by remember { mutableIntStateOf(0) }
    var num by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    @Suppress("UNUSED_VARIABLE") val r0 = rev
    Page("SĐT lừa đảo", back) {
        Card2 {
            Text("Danh sách chặn (${Store.blocklist(c).size})", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(num, { num = it }, Modifier.weight(1f), placeholder = { Text("Số điện thoại") }, singleLine = true)
                Button({ Store.addBlock(c, num); num = ""; rev++ }, colors = ButtonDefaults.buttonColors(containerColor = C.Gold, contentColor = Color(0xFF2A1F00))) { Text("Chặn") }
            }
            Store.blocklist(c).forEach { n ->
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text(n); TextButton({ Store.removeBlock(c, n); rev++ }) { Text("Bỏ chặn", color = C.Gold) } }
            }
        }
        Card2 {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Chặn mọi số nước ngoài (+ khác +84)", Modifier.weight(1f), fontSize = 14.sp)
                Switch(Store.blockForeign(c), { Store.setBlockForeign(c, it); rev++ })
            }
        }
        Card2 {
            Text("Danh sách cộng đồng", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Tải các số lừa đảo do máy chủ của bạn tổng hợp (cần đăng nhập).", fontSize = 12.sp, color = C.Sub)
            GhostButton("Tải danh sách số lừa đảo cộng đồng") { syncCommunity(c) { m -> msg = m; rev++ } }
            if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.Warn)
        }
    }
}

// ───────────────────────── Zalo / Messenger ─────────────────────────

@Composable fun SocialScreen(c: Context, h: Hooks, back: () -> Unit) {
    h.tick()
    Page("Chat Zalo, Messenger…", back) {
        val sc = SocialListener.enabled(c); val ov = Settings.canDrawOverlays(c)
        Card2 {
            Text("Quét thông báo mạng xã hội", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("App đọc thông báo tin nhắn đến từ Zalo, Messenger… ngay trong máy, phát hiện nội dung lừa đảo và cảnh báo bạn. Không lưu và không gửi nội dung đi.", fontSize = 13.sp, color = C.Sub)
            Text("Quét thông báo: ${if (sc) "Bật ✅" else "Tắt"}   •   Viền cảnh báo: ${if (ov) "Bật ✅" else "Tắt"}", fontSize = 13.sp)
            if (!sc) GoldButton("Bật quét thông báo mạng xã hội") { h.openSocial() }
            if (!ov) GoldButton("Bật viền cảnh báo màn hình") { h.openOverlay() }
        }
        Card2 {
            Text("Thử cảnh báo", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Thử vàng", Modifier.weight(1f)) { Alerter.fire(c, 1) }
                GhostButton("Thử đỏ", Modifier.weight(1f)) { Alerter.fire(c, 2) }
            }
        }
    }
}

// ───────────────────────── Mã độc & link ─────────────────────────

class AppRisk(val name: String, val pkg: String, val score: Int, val why: List<String>)

/** Quét ứng dụng đã cài (không phải app hệ thống) và chấm điểm theo các quyền/hành vi hay bị lạm dụng. Chỉ là chỉ báo. */
@Suppress("DEPRECATION")
fun scanApps(c: Context): List<AppRisk> {
    val pm = c.packageManager
    val acc = (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").lowercase()
    val out = ArrayList<AppRisk>()
    for (p in pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
        val ai = p.applicationInfo ?: continue
        if ((ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) continue
        if (p.packageName == c.packageName) continue
        val perms = p.requestedPermissions?.toSet() ?: emptySet()
        var s = 0; val why = ArrayList<String>()
        if (acc.contains(p.packageName.lowercase() + "/")) { s += 40; why += "Đang bật dịch vụ Trợ năng (có thể đọc và điều khiển màn hình)" }
        if ("android.permission.SYSTEM_ALERT_WINDOW" in perms) { s += 15; why += "Được vẽ đè lên ứng dụng khác" }
        if ("android.permission.READ_SMS" in perms || "android.permission.RECEIVE_SMS" in perms) { s += 20; why += "Đọc/nhận tin nhắn SMS (có thể lấy OTP)" }
        if ("android.permission.REQUEST_INSTALL_PACKAGES" in perms) { s += 10; why += "Có thể cài thêm ứng dụng khác" }
        val installer = try { pm.getInstallerPackageName(p.packageName) } catch (_: Exception) { null }
        if (installer == null) { s += 10; why += "Không cài từ cửa hàng ứng dụng" }
        if (s >= 30) out += AppRisk(pm.getApplicationLabel(ai).toString(), p.packageName, s.coerceAtMost(100), why)
    }
    return out.sortedByDescending { it.score }.take(15)
}

/** Chấm điểm một đường link dựa trên dấu hiệu bề ngoài (không truy cập link). */
fun linkCheck(u: String): Result {
    val s = u.trim().lowercase()
    val host = s.removePrefix("https://").removePrefix("http://").substringBefore("/").substringBefore("?").substringBefore(":")
    var score = 0; val why = ArrayList<String>()
    if (s.startsWith("http://")) { score += 25; why += "Không dùng HTTPS" }
    if (Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host)) { score += 40; why += "Dùng địa chỉ IP thay vì tên miền" }
    if (host.startsWith("xn--") || host.contains(".xn--")) { score += 35; why += "Tên miền chứa ký tự dễ giả mạo (punycode)" }
    if (Regex("^(bit\\.ly|tinyurl\\.com|cutt\\.ly|rebrand\\.ly|t\\.co|is\\.gd|s\\.id|goo\\.gl)$").matches(host)) { score += 25; why += "Link rút gọn, không biết đích đến" }
    if (Regex("\\.(xyz|top|vip|club|icu|cc|click|shop|site|online|live)$").containsMatchIn(host)) { score += 20; why += "Đuôi tên miền hay bị lạm dụng" }
    if (host.count { it == '.' } >= 3) { score += 15; why += "Nhiều tầng tên miền phụ" }
    if (host.contains("-") && Regex("vietcombank|vcb|techcombank|mbbank|bidv|vietinbank|agribank|tpbank|momo|zalopay|vneid|bocongan|dichvucong").containsMatchIn(host)) {
        score += 35; why += "Tên miền nhái tên ngân hàng/cơ quan nhà nước" }
    if (s.contains(".apk")) { score += 40; why += "Link tải file cài đặt .apk" }
    val base = ScamDetector.analyze(u)
    score += base.score / 2; why += base.reasons
    return Result(score.coerceAtMost(100), why.distinct())
}

@Composable fun MalwareScreen(c: Context, back: () -> Unit) {
    var link by remember { mutableStateOf("") }
    var lr by remember { mutableStateOf<Result?>(null) }
    var apps by remember { mutableStateOf<List<AppRisk>?>(null) }
    var scanning by remember { mutableStateOf(false) }
    Page("Mã độc & link", back) {
        Card2 {
            Text("🔗 Kiểm tra đường link", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Dán link nhận được qua tin nhắn/Zalo. App chỉ xem dấu hiệu bề ngoài, không mở link.", fontSize = 12.sp, color = C.Sub)
            OutlinedTextField(link, { link = it }, Modifier.fillMaxWidth(), placeholder = { Text("https://…") }, singleLine = true)
            GoldButton("Kiểm tra link", enabled = link.isNotBlank()) { lr = linkCheck(link) }
        }
        lr?.let { ResultCard(it) }
        Card2 {
            Text("🦠 Quét ứng dụng đáng ngờ", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Liệt kê các ứng dụng bạn đã cài có quyền hay bị mã độc lạm dụng (Trợ năng, đọc SMS, vẽ đè màn hình…). Đây chỉ là chỉ báo: app ngân hàng, ví điện tử, trình quản lý cũng có thể xin các quyền này.", fontSize = 12.sp, color = C.Sub)
            GoldButton(if (scanning) "Đang quét…" else "Quét ứng dụng", enabled = !scanning) {
                scanning = true
                Thread { val r = scanApps(c); Handler(Looper.getMainLooper()).post { apps = r; scanning = false } }.start()
            }
        }
        apps?.let { list ->
            if (list.isEmpty()) Text("✅ Không thấy ứng dụng nào có tổ hợp quyền đáng ngờ.", color = C.Ok)
            list.forEach { a ->
                Card2 {
                    Text("${a.name}  (${a.score}/100)", fontWeight = FontWeight.Bold, color = if (a.score >= 60) C.Bad else C.Warn)
                    Text(a.pkg, fontSize = 11.sp, color = C.Dim)
                    a.why.forEach { Text("• $it", fontSize = 13.sp, color = Color.White) }
                    GhostButton("Mở cài đặt ứng dụng (gỡ nếu không dùng)") {
                        c.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
            }
        }
    }
}

// ───────────────────────── Nghe cuộc gọi ─────────────────────────

@Composable fun LiveScreen(h: Hooks, back: () -> Unit) {
    h.tick()
    Page("Nghe cuộc gọi", back) {
        Card2 {
            Text("🎙️ Nghe cuộc gọi qua loa ngoài", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Khi số lạ gọi tới: bắt máy, bật loa ngoài rồi bấm bắt đầu. App phân tích lời nói và cảnh báo nếu có dấu hiệu lừa đảo.", fontSize = 13.sp, color = C.Sub)
            Text(if (ListenService.running) "Trạng thái: đang nghe 🔴" else "Trạng thái: chưa nghe", fontSize = 14.sp, color = if (ListenService.running) C.Bad else C.Sub)
            Button({ h.toggleListen() }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (ListenService.running) C.Bad else C.Gold, contentColor = Color(0xFF2A1F00))) {
                Text(if (ListenService.running) "Dừng nghe" else "Bắt đầu nghe", fontWeight = FontWeight.Bold) }
        }
    }
}

// ───────────────────────── Thống kê ─────────────────────────

@Composable fun StatsScreen(c: Context, back: () -> Unit) {
    Page("Thống kê cảnh báo", back) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(Triple(Store.count(c, "blocked"), "Đã chặn", C.Bad), Triple(Store.count(c, "warned"), "Đã cảnh báo", C.Warn), Triple(Store.blocklist(c).size, "Số bị chặn", C.Ok)).forEach { (n, l, col) ->
                Column(Modifier.weight(1f).background(C.Brown, RoundedCornerShape(18.dp)).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = col); Text(l, fontSize = 12.sp, color = C.Sub) }
            }
        }
        val kinds = Store.history(c).groupingBy { Sync.kindOf(it[2]) }.eachCount()
        val names = mapOf("call" to "Cuộc gọi", "voice" to "Nghe qua loa ngoài", "sms" to "Tin nhắn SMS", "social" to "Zalo / Messenger", "face" to "Video call giả mạo", "habit" to "Giao dịch / nhiều số lạ")
        Card2 {
            Text("Theo loại (trong 100 mục gần nhất)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (kinds.isEmpty()) Text("Chưa có dữ liệu.", color = C.Sub)
            val mx = (kinds.values.maxOrNull() ?: 1).coerceAtLeast(1)
            kinds.entries.sortedByDescending { it.value }.forEach { (k, v) ->
                Text("${names[k] ?: k}: $v", fontSize = 13.sp)
                Box(Modifier.fillMaxWidth(v.toFloat() / mx).height(8.dp).background(C.Tile, RoundedCornerShape(4.dp)))
            }
        }
    }
}

// ───────────────────────── Khác ─────────────────────────

@Composable fun OtherScreen(c: Context, back: () -> Unit) {
    Page("Khác", back) {
        SurveyPanel(c)
        Card2 {
            Text("Mẹo an toàn", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("• Ngân hàng, công an không bao giờ yêu cầu OTP hay chuyển tiền qua điện thoại.\n• Không bấm link lạ, không cài app theo hướng dẫn của người lạ.\n• Nghi ngờ thì cúp máy và gọi lại bằng số đã lưu hoặc số in trên thẻ.", fontSize = 13.sp, color = C.Sub)
        }
        Text("ScamShield VN • phiên bản " + c.packageManager.getPackageInfo(c.packageName, 0).versionName, fontSize = 12.sp, color = C.Dim)
    }
}

// ───────────────────────── Tài khoản ─────────────────────────

@Composable fun AccountTab(c: Context, onLogin: () -> Unit) {
    var logged by remember { mutableStateOf(Store.str(c, "token").isNotEmpty()) }
    var consent by remember { mutableStateOf(Store.flag(c, "consent")) }
    var msg by remember { mutableStateOf("") }
    var server by remember { mutableStateOf(Store.str(c, "server")) }
    var advanced by remember { mutableStateOf(false) }
    var askDel by remember { mutableStateOf(false) }
    var nameEdit by remember { mutableStateOf(Store.str(c, "name")) }
    val hasDefault = Config.SERVER_URL.isNotBlank()
    Page("Tài khoản", null) {
        Card2 {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Avatar(c) {}
                Column {
                    Text(displayName(c), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(if (logged) Store.str(c, "email") else "Chưa đăng nhập", color = C.Sub, fontSize = 13.sp)
                }
            }
        }
        if (!logged) Card2 {
            Text("Đăng nhập để dùng phân tích bằng AI và danh sách số lừa đảo cộng đồng. Chặn cuộc gọi và cảnh báo tin nhắn vẫn hoạt động đầy đủ khi không có tài khoản.", fontSize = 13.sp, color = C.Sub)
            GoldButton("Đăng nhập / Đăng ký") { onLogin() }
        } else Card2 {
            Text("Tên hiển thị trong Cộng đồng", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            OutlinedTextField(nameEdit, { nameEdit = it.take(24) }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Tên hiển thị (2–24 ký tự)") })
            GhostButton("Lưu tên hiển thị", enabled = nameEdit.trim().length >= 2) {
                Api.call(c, "POST", "/api/profile", JSONObject().put("name", nameEdit.trim())) { code, j ->
                    if (code in 200..299) { Store.putStr(c, "name", nameEdit.trim()); msg = "Đã lưu tên hiển thị" } else msg = err(j) } }
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Gửi thống kê ẩn danh (chỉ loại và mức cảnh báo; KHÔNG gửi nội dung, số điện thoại, số tiền)", Modifier.weight(1f), fontSize = 13.sp)
                Switch(consent, { consent = it; Store.putFlag(c, "consent", it); Api.call(c, "POST", "/api/consent", JSONObject().put("analytics", it)) { _, _ -> } })
            }
            GhostButton("Tải danh sách số lừa đảo cộng đồng") { syncCommunity(c) { m -> msg = m } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Đăng xuất", Modifier.weight(1f)) { Store.putStr(c, "token", ""); logged = false; msg = "Đã đăng xuất" }
                GhostButton(if (askDel) "Bấm lại để xóa" else "Xóa tài khoản", Modifier.weight(1f)) {
                    if (!askDel) { askDel = true; msg = "Xóa tài khoản sẽ xóa toàn bộ dữ liệu của bạn trên máy chủ. Bấm lại để xác nhận." }
                    else Api.call(c, "DELETE", "/api/me", null) { code, j ->
                        askDel = false
                        if (code == 200) { Store.putStr(c, "token", ""); logged = false; msg = "Đã xóa tài khoản và dữ liệu" } else msg = err(j) }
                }
            }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.Warn)
        if (!hasDefault || advanced) OutlinedTextField(server, { server = it; Store.putStr(c, "server", it.trim()) }, Modifier.fillMaxWidth(),
            label = { Text(if (hasDefault) "Máy chủ riêng (để trống = dùng mặc định)" else "Địa chỉ máy chủ (https://...)") },
            placeholder = { if (hasDefault) Text(Config.SERVER_URL) }, singleLine = true)
        if (hasDefault) TextButton({ advanced = !advanced }) { Text(if (advanced) "Ẩn nâng cao" else "⚙️ Nâng cao", fontSize = 12.sp, color = C.Dim) }
        Text("🔒 Nội dung tin nhắn, số tiền và danh bạ chỉ được xử lý trong máy.", fontSize = 12.sp, color = C.Sub)
    }
}
