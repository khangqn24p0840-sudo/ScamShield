package vn.scamshield
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.*
import android.provider.Settings
import android.view.View
import android.view.WindowManager

/** Rung + viền màn hình: level 1 = vàng, 2 = đỏ. */
object Alerter {
    fun fire(c: Context, level: Int) { buzz(c, level); Overlay.show(c, level) }
    @Suppress("DEPRECATION")
    private fun buzz(c: Context, level: Int) {
        val v = c.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        val pat = if (level >= 2) longArrayOf(0, 700, 200, 700, 200, 1000) else longArrayOf(0, 250, 150, 250)
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pat, -1)) else v.vibrate(pat, -1)
    }
}

object Overlay {
    private var view: View? = null
    private val h = Handler(Looper.getMainLooper())
    @Suppress("DEPRECATION")
    fun show(c: Context, level: Int) {
        if (!Settings.canDrawOverlays(c)) return
        val ctx = c.applicationContext
        h.post {
            hide(ctx)
            val lp = WindowManager.LayoutParams(-1, -1,
                if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            val v = BorderView(ctx, if (level >= 2) 0xFFFF1744.toInt() else 0xFFFFC107.toInt(), level >= 2)
            try { ctx.getSystemService(WindowManager::class.java).addView(v, lp); view = v } catch (_: Exception) {}
            h.postDelayed({ hide(ctx) }, if (level >= 2) 30000L else 10000L)
        }
    }
    fun hide(c: Context) {
        h.removeCallbacksAndMessages(null)
        view?.let { try { c.applicationContext.getSystemService(WindowManager::class.java).removeView(it) } catch (_: Exception) {} }
        view = null
    }
}

class BorderView(c: Context, col: Int, fast: Boolean) : View(c) {
    private val d = resources.displayMetrics.density
    private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 26 * d; color = col }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8 * d; color = col }
    private val anim = ValueAnimator.ofFloat(0.3f, 1f).apply {
        duration = if (fast) 350 else 700; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { val a = it.animatedValue as Float; outer.alpha = (a * 200).toInt(); inner.alpha = (a * 255).toInt(); invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val a = outer.strokeWidth / 2; cv.drawRect(a, a, width - a, height - a, outer)
        val b = outer.strokeWidth + inner.strokeWidth / 2; cv.drawRect(b, b, width - b, height - b, inner)
    }
}
