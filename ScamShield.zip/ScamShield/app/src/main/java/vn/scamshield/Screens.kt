package vn.scamshield

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import vn.scamshield.face.FaceBus

/** Cầu nối giữa giao diện và các hành động cần Activity (xin quyền, mở cài đặt...). */
class Hooks(
    val tick: () -> Int,
    val callOn: () -> Boolean, val smsOn: () -> Boolean,
    val enableCalls: () -> Unit, val enableSms: () -> Unit,
    val toggleListen: () -> Unit,
    val pickImage: () -> Unit,
    val startFace: () -> Unit, val stopFace: () -> Unit,
    val openOverlay: () -> Unit, val openSocial: () -> Unit,
    val aiMsg: () -> String, val setAiMsg: (String) -> Unit
)

fun displayName(c: Context): String {
    val n = Store.str(c, "name")
    if (n.isNotBlank()) return n
    val e = Store.str(c, "email")
    return if (e.isNotBlank()) e.substringBefore("@") else "Khách"
}

@Composable fun ShieldApp(c: Context, h: Hooks) {
    h.tick()
    var loginDone by remember { mutableStateOf(Store.str(c, "token").isNotEmpty() || Store.flag(c, "skip_login")) }
    Surface(Modifier.fillMaxSize(), color = C.Bg, contentColor = Color.White) {
        if (!loginDone) LoginScreen(c, { loginDone = true }, { Store.putFlag(c, "skip_login", true); loginDone = true })
        else MainShell(c, h) { Store.putFlag(c, "skip_login", false); loginDone = false }
    }
}

// ───────────────────────── Đăng nhập ─────────────────────────

@Composable private fun FieldRow(icon: String, content: @Composable RowScope.() -> Unit) =
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(42.dp).background(C.Teal, CircleShape), contentAlignment = Alignment.Center) { Text(icon, fontSize = 20.sp) }
        content()
    }

@Composable fun LoginScreen(c: Context, onDone: () -> Unit, onSkip: () -> Unit) {
    var reg by remember { mutableStateOf(false) }
    var user by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(Store.str(c, "email")) }
    var pass by remember { mutableStateOf("") }
    var server by remember { mutableStateOf(Store.str(c, "server")) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showServer by remember { mutableStateOf(false) }
    val hasDefault = Config.SERVER_URL.isNotBlank()

    fun finish(code: Int, j: JSONObject?) {
        busy = false
        if (j != null && code in 200..299 && j.has("token")) {
            Store.putStr(c, "token", j.getString("token")); Store.putStr(c, "email", email.trim())
            val nm = user.trim().ifEmpty { Store.str(c, "name").ifEmpty { email.trim().substringBefore("@") } }
            Store.putStr(c, "name", nm)
            onDone()
        } else msg = err(j)
    }
    fun submit() {
        if (email.isBlank() || pass.length < 8) { msg = "Nhập email và mật khẩu (từ 8 ký tự)"; return }
        busy = true; msg = if (reg) "Đang đăng ký…" else "Đang đăng nhập…"
        Api.call(c, "POST", if (reg) "/api/register" else "/api/login",
            JSONObject().put("email", email.trim()).put("password", pass)) { code, j -> finish(code, j) }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF12203D), C.Bg)))) {
        Box(Modifier.size(300.dp).align(Alignment.TopEnd).offset(x = 110.dp, y = (-90).dp)
            .background(Brush.radialGradient(listOf(C.Accent.copy(alpha = 0.25f), Color.Transparent)), CircleShape))
        Column(Modifier.align(Alignment.Center).fillMaxWidth().statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(76.dp).background(C.AccentSoft, RoundedCornerShape(26.dp)), contentAlignment = Alignment.Center) { Text("🛡️", fontSize = 38.sp) }
            Spacer(Modifier.height(20.dp))
            Text(if (reg) "Tạo tài khoản" else "Chào mừng trở lại", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("ScamShield VN giúp bạn nhận diện lừa đảo", color = C.Sub, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 28.dp))
            Column(Modifier.fillMaxWidth().background(C.Surface, RoundedCornerShape(28.dp)).border(1.dp, C.Stroke, RoundedCornerShape(28.dp)).padding(20.dp),
                Arrangement.spacedBy(14.dp)) {
                if (!hasDefault || showServer) PillField(server, { server = it; Store.putStr(c, "server", it.trim()) }, "Máy chủ https://…", leading = "🌐")
                if (reg) PillField(user, { user = it }, "Tên người dùng", leading = "👤")
                PillField(email, { email = it }, "Email", leading = "✉️")
                PillField(pass, { pass = it }, "Mật khẩu (từ 8 ký tự)", password = true, leading = "🔒")
                if (msg.isNotEmpty()) Text(msg, color = C.Warn, fontSize = 13.sp)
                GoldButton(if (reg) "Đăng ký" else "Đăng nhập", enabled = !busy) { submit() }
            }
            Spacer(Modifier.height(20.dp))
            Text(if (reg) "Đã có tài khoản? Đăng nhập" else "Chưa có tài khoản? Đăng ký", color = C.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { reg = !reg; msg = "" }.padding(8.dp))
            if (!reg) Text("Quên mật khẩu", color = C.Dim, fontSize = 13.sp, modifier = Modifier.padding(4.dp)
                .clickable { msg = "Chưa có chức năng đặt lại mật khẩu tự động. Hãy liên hệ người quản trị máy chủ." })
            TextButton({ onSkip() }) { Text("Dùng không cần tài khoản →", color = C.Sub, fontSize = 14.sp) }
            if (hasDefault) TextButton({ showServer = !showServer }) { Text(if (showServer) "Ẩn máy chủ" else "⚙️ Máy chủ", color = C.Dim, fontSize = 12.sp) }
        }
    }
}

// ───────────────────────── Khung chính + thanh điều hướng ─────────────────────────

@Composable fun MainShell(c: Context, h: Hooks, onLogin: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf("") }
    BackHandler(enabled = sub.isNotEmpty() || tab != 0) { if (sub.isNotEmpty()) sub = "" else tab = 0 }
    val open: (String) -> Unit = { sub = it }
    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (sub.isNotEmpty()) SubScreen(c, h, sub, { sub = "" }, open)
            else when (tab) {
                0 -> HomeTab(c, h, open, { tab = 5 }) { tab = 1 }
                1 -> SettingsTab(c, h)
                2 -> MessageScreen(c, null, open)
                3 -> HistoryScreen(c, 0, null)
                4 -> CommunityTab(c, onLogin)
                else -> AccountTab(c, onLogin)
            }
        }
        BottomBar(tab, sub.isNotEmpty()) { tab = it; sub = "" }
    }
}

@Composable fun BottomBar(tab: Int, inSub: Boolean, onTab: (Int) -> Unit) {
    // (chỉ số tab, biểu tượng, nhãn). Cài đặt nằm ở nút ⚙️ trên trang chủ.
    val items = listOf(Triple(0, "🏠", "Trang chủ"), Triple(3, "🔔", "Nhật ký"), Triple(2, "🛡️", "Kiểm tra"),
        Triple(4, "💬", "Cộng đồng"), Triple(5, "👤", "Tài khoản"))
    Column(Modifier.fillMaxWidth().background(C.Bar)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.Stroke))
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            items.forEach { (idx, ic, lb) ->
                val sel = !inSub && tab == idx
                Column(Modifier.weight(1f).clickable { onTab(idx) }.padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.width(60.dp).height(30.dp).background(if (sel) C.AccentSoft else Color.Transparent, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                        Text(ic, fontSize = 18.sp, modifier = Modifier.alpha(if (sel) 1f else 0.6f)) }
                    Spacer(Modifier.height(3.dp))
                    Text(lb, fontSize = 11.sp, color = if (sel) C.Accent else C.Dim, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
                }
            }
        }
    }
}

// ───────────────────────── Trang chủ ─────────────────────────

@Composable fun Avatar(c: Context, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).background(C.AccentSoft, CircleShape).border(1.dp, C.Accent.copy(alpha = 0.5f), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) {
        Text(displayName(c).take(1).uppercase(), color = C.Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
}

@Composable fun HomeTab(c: Context, h: Hooks, open: (String) -> Unit, toAccount: () -> Unit, toSettings: () -> Unit) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp), Arrangement.spacedBy(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Xin chào 👋", color = C.Dim, fontSize = 14.sp)
                Text(displayName(c), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            IconBtn("⚙️", toSettings)
            Avatar(c, toAccount)
        }
        PillField(q, { q = it }, "Tìm số điện thoại, tin nhắn, nhật ký…", leading = "🔍")
        if (q.isNotBlank()) SearchResults(c, q) else HomeBody(c, h, open)
        Spacer(Modifier.height(8.dp))
    }
}

private data class Cat(val icon: String, val label: String, val key: String, val tint: Color)
private data class Rec(val icon: String, val title: String, val badge: String, val tint: Color, val key: String)

@Composable private fun HomeBody(c: Context, h: Hooks, open: (String) -> Unit) {
    StatusCard(c, h, open)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTitle("Danh mục")
        val cats = listOf(
            Cat("🛡️", "Tất cả", "all", Color(0xFF34D399)), Cat("🎥", "Video Call\nDeepfake", "video", Color(0xFF60A5FA)),
            Cat("📵", "SĐT\nLừa Đảo", "blocklist", Color(0xFFF87171)), Cat("💬", "Tin Nhắn", "msg", Color(0xFFFBBF24)),
            Cat("🔐", "Zalo,\nMessenger", "social", Color(0xFFA78BFA)), Cat("🦠", "Mã Độc\n& Link", "malware", Color(0xFF2DD4BF)),
            Cat("🤖", "Yêu Cầu AI", "ai", Color(0xFFF472B6)), Cat("⋯", "Khác", "other", Color(0xFF94A3B8)))
        cats.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) { row.forEach { x -> CatTile(x.icon, x.label, Modifier.weight(1f), x.tint) { open(x.key) } } }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTitle("Đề xuất cho bạn")
        val recs = listOf(
            Rec("📞", "Nghe cuộc gọi qua loa ngoài", if (ListenService.running) "Đang nghe" else "Đã chặn ${Store.count(c, "blocked")}", Color(0xFFF87171), "live"),
            Rec("🎭", "Kiểm tra Deepfake", if (FaceBus.running) "Đang chạy" else "Video call", Color(0xFF60A5FA), "video"),
            Rec("📊", "Thống kê cảnh báo", "${Store.count(c, "warned") + Store.count(c, "blocked")} lần", Color(0xFF34D399), "stats"),
            Rec("🔗", "Phân tích link", "Mã độc & link", Color(0xFFA78BFA), "link"))
        recs.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), Arrangement.spacedBy(12.dp)) {
                row.forEach { x -> FeatureCard(x.icon, x.title, x.badge, x.tint, Modifier.weight(1f).fillMaxHeight()) { open(x.key) } }
            }
        }
    }
    Row(Modifier.fillMaxWidth().background(C.AccentSoft, RoundedCornerShape(20.dp)).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("💡", fontSize = 20.sp)
        Text("Ngân hàng và công an không bao giờ yêu cầu đọc OTP hay chuyển tiền qua điện thoại.", fontSize = 13.sp, color = C.Sub, lineHeight = 19.sp)
    }
}

@Composable private fun StatChip(icon: String, value: String, label: String, modifier: Modifier, onClick: () -> Unit) =
    Row(modifier.background(Color.White.copy(alpha = 0.14f), RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(icon, fontSize = 20.sp)
        Column { Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp) }
    }

@Composable private fun StatusCard(c: Context, h: Hooks, open: (String) -> Unit) {
    val callOn = h.callOn(); val smsOn = h.smsOn(); val prot = callOn && smsOn
    val grad = if (prot) listOf(Color(0xFF0F766E), Color(0xFF065F46)) else listOf(Color(0xFFB45309), Color(0xFF7C2D12))
    Column(Modifier.fillMaxWidth().background(Brush.linearGradient(grad), RoundedCornerShape(28.dp)).padding(22.dp), Arrangement.spacedBy(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(Modifier.size(60.dp).background(Color.White.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
                Text(if (prot) "🛡️" else "⚠️", fontSize = 28.sp) }
            Column(Modifier.weight(1f), Arrangement.spacedBy(3.dp)) {
                Text(if (prot) "Bạn đang được bảo vệ" else "Cần bật thêm bảo vệ", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Chặn cuộc gọi: " + (if (callOn) "Bật" else "Tắt") + "  •  Tin nhắn: " + (if (smsOn) "Bật" else "Tắt"),
                    color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
            StatChip("🚫", "${Store.count(c, "blocked")}", "Đã chặn", Modifier.weight(1f)) { open("blocked") }
            StatChip("⚠️", "${Store.count(c, "warned")}", "Cảnh báo", Modifier.weight(1f)) { open("all") }
        }
        if (!callOn) GoldButton("Bật chặn cuộc gọi") { h.enableCalls() }
        if (!smsOn) GoldButton("Bật cảnh báo tin nhắn") { h.enableSms() }
    }
}

@Composable private fun SearchResults(c: Context, q: String) {
    val n = ScamDetector.norm(q.trim())
    val qd = q.filter { it.isDigit() }
    val nums = Store.blocklist(c).filter { it.contains(q.trim()) || (qd.length >= 3 && it.filter { ch -> ch.isDigit() }.contains(qd)) }
    val hist = Store.history(c).filter { ScamDetector.norm(it[2] + " " + it[3]).contains(n) }
    if (q.trim().length >= 12) { Text("Phân tích nhanh nội dung đang nhập", color = C.Dim, fontSize = 14.sp); ResultCard(ScamDetector.analyze(q)) }
    if (nums.isNotEmpty()) {
        Text("Số đã chặn (${nums.size})", color = C.Dim, fontSize = 14.sp)
        Card2 { nums.forEach { Text("🚫 $it", color = Color.White) } }
    }
    if (hist.isNotEmpty()) {
        Text("Trong nhật ký (${hist.size})", color = C.Dim, fontSize = 14.sp)
        hist.take(20).forEach { HistoryRow(it) }
    }
    if (nums.isEmpty() && hist.isEmpty() && q.trim().length < 12) Text("Không tìm thấy kết quả khớp.", color = C.Sub)
}
