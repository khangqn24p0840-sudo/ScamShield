package vn.scamshield

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import vn.scamshield.face.FaceBus

/** Cầu nối giữa giao diện và các hành động cần Activity (xin quyền, mở cài đặt...). */
class Hooks(
    val tick: () -> Int,
    val callOn: () -> Boolean, val smsOn: () -> Boolean,
    val enableCalls: () -> Unit, val enableSms: () -> Unit,
    val toggleListen: () -> Unit,
    val pickImage: () -> Unit,
    val startFace: () -> Unit, val stopFace: () -> Unit,
    val openOverlay: () -> Unit, val openSocial: () -> Unit,
    val aiMsg: () -> String, val setAiMsg: (String) -> Unit
)

fun displayName(c: Context): String {
    val n = Store.str(c, "name")
    if (n.isNotBlank()) return n
    val e = Store.str(c, "email")
    return if (e.isNotBlank()) e.substringBefore("@") else "Khách"
}

@Composable fun ShieldApp(c: Context, h: Hooks) {
    h.tick()
    var loginDone by remember { mutableStateOf(Store.str(c, "token").isNotEmpty() || Store.flag(c, "skip_login")) }
    Surface(Modifier.fillMaxSize(), color = C.Bg, contentColor = Color.White) {
        if (!loginDone) LoginScreen(c, { loginDone = true }, { Store.putFlag(c, "skip_login", true); loginDone = true })
        else MainShell(c, h) { Store.putFlag(c, "skip_login", false); loginDone = false }
    }
}

// ───────────────────────── Đăng nhập ─────────────────────────

@Composable private fun FieldRow(icon: String, content: @Composable RowScope.() -> Unit) =
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(42.dp).background(C.Teal, CircleShape), contentAlignment = Alignment.Center) { Text(icon, fontSize = 20.sp) }
        content()
    }

@Composable fun LoginScreen(c: Context, onDone: () -> Unit, onSkip: () -> Unit) {
    var reg by remember { mutableStateOf(false) }
    var user by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(Store.str(c, "email")) }
    var pass by remember { mutableStateOf("") }
    var server by remember { mutableStateOf(Store.str(c, "server")) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showServer by remember { mutableStateOf(false) }
    val hasDefault = Config.SERVER_URL.isNotBlank()

    fun finish(code: Int, j: JSONObject?) {
        busy = false
        if (j != null && code in 200..299 && j.has("token")) {
            Store.putStr(c, "token", j.getString("token")); Store.putStr(c, "email", email.trim())
            val nm = user.trim().ifEmpty { Store.str(c, "name").ifEmpty { email.trim().substringBefore("@") } }
            Store.putStr(c, "name", nm)
            onDone()
        } else msg = err(j)
    }
    fun submit() {
        if (email.isBlank() || pass.length < 8) { msg = "Nhập email và mật khẩu (từ 8 ký tự)"; return }
        busy = true; msg = if (reg) "Đang đăng ký…" else "Đang đăng nhập…"
        Api.call(c, "POST", if (reg) "/api/register" else "/api/login",
            JSONObject().put("email", email.trim()).put("password", pass)) { code, j -> finish(code, j) }
    }

    Box(Modifier.fillMaxSize().background(C.LoginBg)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val ht = size.height
            val top = Path().apply {
                moveTo(w * 0.44f, 0f)
                cubicTo(w * 0.44f, ht * 0.07f, w * 0.58f, ht * 0.11f, w * 0.76f, ht * 0.095f)
                cubicTo(w * 0.90f, ht * 0.085f, w * 0.97f, ht * 0.05f, w, ht * 0.04f)
                lineTo(w, 0f); close()
            }
            drawPath(top, C.Blob)
            val bottom = Path().apply {
                moveTo(0f, ht * 0.90f)
                cubicTo(w * 0.18f, ht * 0.87f, w * 0.30f, ht * 0.90f, w * 0.40f, ht * 0.94f)
                cubicTo(w * 0.50f, ht * 0.98f, w * 0.52f, ht * 0.995f, w * 0.55f, ht)
                lineTo(0f, ht); close()
            }
            drawPath(bottom, C.Blob)
        }
        Column(Modifier.align(Alignment.Center).fillMaxWidth().statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🦅", fontSize = 54.sp)
            Text("Chào mừng", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Box(Modifier.padding(top = 10.dp, bottom = 24.dp).width(130.dp).height(3.dp).background(Color.Black))
            if (!hasDefault || showServer) FieldRow("🌐") { PillField(server, { server = it; Store.putStr(c, "server", it.trim()) }, "Máy chủ https://…", Modifier.weight(1f)) }
            if (reg) FieldRow("👤") { PillField(user, { user = it }, "Tên người dùng", Modifier.weight(1f)) }
            FieldRow("✉️") { PillField(email, { email = it }, "Email", Modifier.weight(1f)) }
            FieldRow("🔒") { PillField(pass, { pass = it }, "Mật khẩu (từ 8 ký tự)", Modifier.weight(1f), password = true) }
            Spacer(Modifier.height(18.dp))
            Button({ if (!busy) submit() }, Modifier.width(200.dp).height(46.dp), shape = RoundedCornerShape(23.dp),
                colors = ButtonDefaults.buttonColors(containerColor = C.Teal, contentColor = C.Ink)) {
                Text(if (reg) "Đăng ký" else "Đăng nhập", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            if (msg.isNotEmpty()) Text(msg, color = C.Warn, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            Text("Quên mật khẩu", color = C.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp)
                .clickable { msg = "Chưa có chức năng đặt lại mật khẩu tự động. Hãy liên hệ người quản trị máy chủ." })
            TextButton({ onSkip() }) { Text("Dùng không cần tài khoản →", color = C.Gold, fontSize = 14.sp) }
            if (hasDefault) TextButton({ showServer = !showServer }) { Text(if (showServer) "Ẩn máy chủ" else "⚙️ Máy chủ", color = C.Dim, fontSize = 12.sp) }
        }
        Text(if (reg) "Đã có tài khoản? Đăng nhập" else "Chưa có tài khoản? Đăng ký", color = C.Sub, fontSize = 13.sp,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(24.dp).clickable { reg = !reg; msg = "" })
    }
}

// ───────────────────────── Khung chính + thanh điều hướng ─────────────────────────

@Composable fun MainShell(c: Context, h: Hooks, onLogin: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf("") }
    BackHandler(enabled = sub.isNotEmpty() || tab != 0) { if (sub.isNotEmpty()) sub = "" else tab = 0 }
    val open: (String) -> Unit = { sub = it }
    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (sub.isNotEmpty()) SubScreen(c, h, sub, { sub = "" }, open)
            else when (tab) {
                0 -> HomeTab(c, h, open) { tab = 5 }
                1 -> SettingsTab(c, h)
                2 -> MessageScreen(c, null, open)
                3 -> HistoryScreen(c, 0, null)
                4 -> CommunityTab(c, onLogin)
                else -> AccountTab(c, onLogin)
            }
        }
        BottomBar(tab, sub.isNotEmpty()) { tab = it; sub = "" }
    }
}

@Composable fun BottomBar(tab: Int, inSub: Boolean, onTab: (Int) -> Unit) {
    val items = listOf("🧭" to "Trang chủ", "⚙️" to "Cài đặt", "🛡️" to "Kiểm tra", "🔔" to "Nhật ký", "💬" to "Cộng đồng", "👤" to "Tài khoản")
    Row(Modifier.fillMaxWidth().background(C.Bar), verticalAlignment = Alignment.CenterVertically) {
        items.forEachIndexed { i, (ic, lb) ->
            val sel = !inSub && tab == i
            Column(Modifier.weight(1f).clickable { onTab(i) }.padding(bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth(0.5f).height(2.dp).background(if (sel) C.Tile else Color.Transparent))
                Spacer(Modifier.height(5.dp))
                if (i == 2) Box(Modifier.size(40.dp).background(if (sel) C.Tile else Color(0xFF14513F), CircleShape), contentAlignment = Alignment.Center) { Text(ic, fontSize = 20.sp) }
                else Text(ic, fontSize = 22.sp, modifier = Modifier.alpha(if (sel) 1f else 0.55f))
                Text(lb, fontSize = 10.sp, color = if (sel) C.Ok else C.Dim, maxLines = 1)
            }
        }
    }
}

// ───────────────────────── Trang chủ ─────────────────────────

@Composable fun Avatar(c: Context, onClick: () -> Unit) {
    Box(Modifier.size(46.dp).background(C.Gold, CircleShape).padding(2.dp).background(C.Bg, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(displayName(c).take(1).uppercase(), color = C.Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
}

@Composable fun HomeTab(c: Context, h: Hooks, open: (String) -> Unit, toAccount: () -> Unit) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().background(C.Brown, RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)).padding(horizontal = 16.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("🦅", fontSize = 34.sp)
            PillField(q, { q = it }, "Tìm cuộc gọi, tin nhắn, số điện thoại…", Modifier.weight(1f), bg = C.Gold, fg = Color(0xFF2A1F00), center = false, trailing = "🔍")
            Avatar(c, toAccount)
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (q.isNotBlank()) SearchResults(c, q) else HomeBody(c, h, open)
        }
    }
}

@Composable private fun HomeBody(c: Context, h: Hooks, open: (String) -> Unit) {
    StatusCard(h, open)
    SectionTitle("Danh mục")
    val cats = listOf(
        Triple("🛡️", "Tất cả", "all"), Triple("🎥", "Video Call\nDeepfake", "video"), Triple("📵", "SĐT\nLừa Đảo", "blocklist"), Triple("💬", "Tin Nhắn", "msg"),
        Triple("🔐", "Chat Zalo,\nMessenger", "social"), Triple("🦠", "Mã Độc\n& Link", "malware"), Triple("🤖", "Yêu Cầu AI", "ai"), Triple("⋯", "Khác", "other"))
    cats.chunked(4).forEach { row ->
        Row(Modifier.fillMaxWidth()) { row.forEach { (ic, lb, key) -> CatTile(ic, lb, Modifier.weight(1f)) { open(key) } } }
    }
    SectionTitle("Đề xuất")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        RecCard("📞", "Nghe cuộc gọi\nqua loa ngoài", if (ListenService.running) "Đang nghe" else "Đã chặn ${Store.count(c, "blocked")}",
            listOf(Color(0xFF7F1D1D), Color(0xFF1F1013))) { open("live") }
        RecCard("🎭", "Kiểm tra\nDeepfake", if (FaceBus.running) "Đang chạy" else "Video call",
            listOf(Color(0xFF334155), Color(0xFF0F172A))) { open("video") }
        RecCard("📊", "Thống kê\ncảnh báo", "${Store.count(c, "warned") + Store.count(c, "blocked")} lần",
            listOf(Color(0xFF14532D), Color(0xFF052E16))) { open("stats") }
        RecCard("🔗", "Phân tích\nlink", "Mã độc & link", listOf(Color(0xFF1E3A8A), Color(0xFF0B1B45))) { open("link") }
    }
    Text("Mẹo: ngân hàng, công an không bao giờ yêu cầu OTP hay chuyển tiền qua điện thoại.", fontSize = 12.sp, color = C.Sub)
}

@Composable private fun StatusCard(h: Hooks, open: (String) -> Unit) {
    val callOn = h.callOn(); val smsOn = h.smsOn(); val prot = callOn && smsOn
    Column(Modifier.fillMaxWidth().background(C.Brown, RoundedCornerShape(20.dp)).padding(16.dp), Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(64.dp).background(C.Gold, CircleShape), contentAlignment = Alignment.Center) { Text(if (prot) "🛡️" else "⚠️", fontSize = 30.sp) }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(buildAnnotatedString {
                    append("Bảo vệ cuộc gọi: ")
                    withStyle(SpanStyle(color = if (callOn) C.Ok else C.Warn, fontWeight = FontWeight.Bold)) { append(if (callOn) "Đang kích hoạt (ACTIVE)" else "Chưa bật") }
                }, color = Color.White, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Trạng thái:", color = Color.White, fontSize = 13.sp)
                        Text(if (prot) "✔ An toàn" else "⚠ Cần bật thêm", color = if (prot) C.Ok else C.Warn, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Column(Modifier.clickable { open("blocked") }) {
                        Text("✅ Xem nhật ký", color = Color.White, fontSize = 13.sp)
                        Text("cuộc gọi chặn", color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }
        if (!callOn) GoldButton("Bật chặn cuộc gọi") { h.enableCalls() }
        if (!smsOn) GoldButton("Bật cảnh báo tin nhắn") { h.enableSms() }
    }
}

@Composable private fun SearchResults(c: Context, q: String) {
    val n = ScamDetector.norm(q.trim())
    val qd = q.filter { it.isDigit() }
    val nums = Store.blocklist(c).filter { it.contains(q.trim()) || (qd.length >= 3 && it.filter { ch -> ch.isDigit() }.contains(qd)) }
    val hist = Store.history(c).filter { ScamDetector.norm(it[2] + " " + it[3]).contains(n) }
    if (q.trim().length >= 12) { Text("Phân tích nhanh nội dung đang nhập", color = C.Dim, fontSize = 14.sp); ResultCard(ScamDetector.analyze(q)) }
    if (nums.isNotEmpty()) {
        Text("Số đã chặn (${nums.size})", color = C.Dim, fontSize = 14.sp)
        Card2 { nums.forEach { Text("🚫 $it", color = Color.White) } }
    }
    if (hist.isNotEmpty()) {
        Text("Trong nhật ký (${hist.size})", color = C.Dim, fontSize = 14.sp)
        hist.take(20).forEach { HistoryRow(it) }
    }
    if (nums.isEmpty() && hist.isEmpty() && q.trim().length < 12) Text("Không tìm thấy kết quả khớp.", color = C.Sub)
}
