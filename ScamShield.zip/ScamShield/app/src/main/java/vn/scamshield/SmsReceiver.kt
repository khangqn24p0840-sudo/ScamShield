package vn.scamshield
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        msgs.groupBy { it.originatingAddress ?: "?" }.forEach { (from, parts) ->
            val body = parts.joinToString("") { it.messageBody ?: "" }
            val r = ScamDetector.analyze(body)
            if (r.level >= 1 || Store.isBlocked(c, from)) {
                val t = if (r.level == 2) "🚨 Tin nhắn có dấu hiệu LỪA ĐẢO" else "⚠️ Tin nhắn đáng ngờ"
                Store.log(c, if (r.level == 2) 2 else 1, "$t từ $from", body)
                Notifier.show(c, t, "Từ $from: " + r.reasons.joinToString(", ") + ". Không bấm link, không cung cấp OTP.")
            }
        }
    }
}
