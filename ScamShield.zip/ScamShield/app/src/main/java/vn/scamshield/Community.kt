package vn.scamshield

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ───────────────────────── Dữ liệu & tiện ích ─────────────────────────

/** Một cảnh báo trên bảng tin cộng đồng. */
data class Post(
    val id: Long, val title: String, val body: String, val topic: String, val severity: String, val official: Boolean,
    val author: String, val ts: Long, val likes: Int, val comments: Int, val liked: Boolean, val mine: Boolean
)

/** Một bình luận công khai dưới cảnh báo. */
data class Comment(val id: Long, val author: String, val body: String, val ts: Long, val mine: Boolean)

val TOPICS = listOf("ngan-hang" to "Ngân hàng", "mang-xa-hoi" to "Mạng xã hội", "dien-thoai" to "Điện thoại", "viec-lam" to "Việc làm", "khac" to "Khác")
private val SEVERITIES = listOf("low" to "Thấp", "medium" to "Trung bình", "high" to "Cao")

private val FeedCyan = Color(0xFF22D3EE)
private val FeedCard = Color(0xFF0F1A2E)
private val FeedBorder = Color(0xFF1B2A44)
private val FeedChipBg = Color(0xFF1B2638)

fun topicLabel(k: String) = TOPICS.firstOrNull { it.first == k }?.second ?: "Khác"
private fun sevLabel(k: String) = SEVERITIES.firstOrNull { it.first == k }?.second ?: "Trung bình"
private fun topicColor(k: String): Color = when (k) {
    "ngan-hang" -> Color(0xFFF87171); "mang-xa-hoi" -> Color(0xFFA78BFA); "dien-thoai" -> Color(0xFFFBBF24)
    "viec-lam" -> Color(0xFF34D399); else -> Color(0xFF94A3B8)
}

fun timeAgo(ts: Long): String {
    val s = System.currentTimeMillis() / 1000 - ts
    return when {
        s < 60 -> "Vừa xong"
        s < 3600 -> "${s / 60} phút trước"
        s < 86400 -> "${s / 3600} giờ trước"
        s < 7 * 86400 -> "${s / 86400} ngày trước"
        else -> SimpleDateFormat("dd/MM/yyyy", Locale("vi", "VN")).format(Date(ts * 1000))
    }
}

fun parsePost(o: JSONObject?): Post? = o?.let {
    Post(it.optLong("id"), it.optString("title"), it.optString("body"), it.optString("topic"), it.optString("severity"), it.optBoolean("official"),
        it.optString("author"), it.optLong("ts"), it.optInt("likes"), it.optInt("comments"), it.optBoolean("liked"), it.optBoolean("mine"))
}

fun parsePosts(j: JSONObject?): List<Post> {
    val a = j?.optJSONArray("posts") ?: return emptyList()
    return (0 until a.length()).mapNotNull { parsePost(a.optJSONObject(it)) }
}

private fun parseComments(j: JSONObject?): List<Comment> {
    val a = j?.optJSONArray("comments") ?: return emptyList()
    return (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Comment(o.optLong("id"), o.optString("author"), o.optString("body"), o.optLong("ts"), o.optBoolean("mine"))
    }
}

/** Thông báo lỗi dễ hiểu cho người dùng. */
fun apiMsg(code: Int, j: JSONObject?): String = when {
    code == -1 -> "Không kết nối được máy chủ. Hãy kiểm tra mạng, server và ngrok."
    code == 404 && j?.optString("error") == "Không tìm thấy" ->
        "Máy chủ chưa được cập nhật bản mới (thiếu mục Cộng đồng). Hãy thay file server mới và chạy lại server."
    else -> err(j)
}

/** Chỉ cập nhật khi màn hình đang mở (tránh gọi máy chủ liên tục khi app chạy nền). */
@Composable private fun rememberIsResumed(): () -> Boolean {
    val owner = LocalLifecycleOwner.current
    return { owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
}

// ───────────────────────── Thành phần giao diện ─────────────────────────

@Composable private fun Tag(text: String, col: Color) =
    Box(Modifier.background(col.copy(alpha = 0.15f), RoundedCornerShape(8.dp)).border(BorderStroke(1.dp, col.copy(alpha = 0.5f)), RoundedCornerShape(8.dp))
        .padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text(text, color = col, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1) }

@Composable private fun FeedChip(label: String, on: Boolean, onClick: () -> Unit) =
    Box(Modifier.background(if (on) FeedCyan else FeedChipBg, RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(label, fontSize = 14.sp, color = if (on) Color(0xFF042F2E) else Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1) }

@Composable private fun AuthorDot(name: String) {
    val pal = listOf(Color(0xFF22D3EE), Color(0xFFA78BFA), Color(0xFFFBBF24), Color(0xFF34D399), Color(0xFFF87171), Color(0xFF60A5FA))
    val col = pal[(name.hashCode() and 0x7fffffff) % pal.size]
    Box(Modifier.size(32.dp).background(col.copy(alpha = 0.2f), CircleShape).border(BorderStroke(1.dp, col), CircleShape), contentAlignment = Alignment.Center) {
        Text(name.trim().take(1).uppercase().ifEmpty { "?" }, color = col, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}

/** Thẻ cảnh báo: nhãn chủ đề, thời gian, tiêu đề, tóm tắt, mức độ, lượt thích, bình luận. */
@Composable fun PostCard(p: Post, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(FeedCard, RoundedCornerShape(20.dp)).border(BorderStroke(1.dp, FeedBorder), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Tag(topicLabel(p.topic).uppercase(), topicColor(p.topic))
                if (p.official) Tag("CHÍNH THỨC", FeedCyan)
            }
            Text(timeAgo(p.ts), color = C.Dim, fontSize = 12.sp)
        }
        Text(p.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(p.body, color = C.Sub, fontSize = 14.sp, lineHeight = 20.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Box(Modifier.fillMaxWidth().height(1.dp).background(FeedBorder))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("🛡️ Mức độ: ${sevLabel(p.severity)}   👍 ${p.likes}   💬 ${p.comments}", color = C.Dim, fontSize = 12.sp, maxLines = 1)
            Text("Chi tiết →", color = FeedCyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

// ───────────────────────── Xem trước trên Trang chủ ─────────────────────────

/** "Cảnh Báo Nổi Bật" trên Trang chủ: 3 cảnh báo mới nhất, tự cập nhật khi có bài mới. Xem được không cần đăng nhập. */
@Composable fun FeedPreview(c: Context, onSeeAll: () -> Unit, onPost: (Long) -> Unit) {
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var rev by remember { mutableStateOf("") }
    var offline by remember { mutableStateOf(false) }
    val resumed = rememberIsResumed()
    LaunchedEffect(Store.str(c, "token").isNotEmpty()) {
        rev = ""
        while (true) {
            if (resumed()) Api.call(c, "GET", "/api/posts?limit=3&rev=$rev", null) { code, j ->
                if (code in 200..299 && j != null) {
                    offline = false
                    if (!j.optBoolean("unchanged")) { posts = parsePosts(j); rev = j.optString("rev") }
                } else offline = true
            }
            delay(10000)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("🔥 Cảnh Báo Nổi Bật", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Xem tất cả", color = FeedCyan, fontSize = 14.sp, modifier = Modifier.clickable(onClick = onSeeAll))
        }
        if (posts.isEmpty()) Text(if (offline) "Chưa tải được cảnh báo (mất kết nối máy chủ)." else "Chưa có cảnh báo nào. Hãy là người đầu tiên chia sẻ!", color = C.Sub, fontSize = 13.sp)
        posts.forEach { p -> PostCard(p) { onPost(p.id) } }
    }
}

// ───────────────────────── Tab Cộng đồng ─────────────────────────

@Composable fun CommunityTab(c: Context, onLogin: () -> Unit, openPost: Long, onOpened: () -> Unit) {
    val logged = Store.str(c, "token").isNotEmpty()
    var detail by remember { mutableLongStateOf(0L) }
    var composing by remember { mutableStateOf(false) }
    LaunchedEffect(openPost) { if (openPost > 0L) { detail = openPost; onOpened() } }
    BackHandler(enabled = composing || detail > 0L) { if (composing) composing = false else detail = 0L }
    when {
        composing -> ComposePost(c, { composing = false }, { composing = false })
        detail > 0L -> PostDetail(c, detail, logged, onLogin) { detail = 0L }
        else -> FeedList(c, logged, onLogin, { detail = it }) { composing = true }
    }
}

@Composable private fun FeedList(c: Context, logged: Boolean, onLogin: () -> Unit, onOpen: (Long) -> Unit, onCompose: () -> Unit) {
    var topic by remember { mutableStateOf("") }
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var rev by remember { mutableStateOf("") }
    var hasMore by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var needLogin by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    val resumed = rememberIsResumed()

    // Cập nhật liên tục: cứ 8 giây hỏi máy chủ "có gì mới không"; không đổi thì máy chủ trả lời rất gọn.
    LaunchedEffect(topic, logged, retry) {
        rev = ""
        while (true) {
            if (resumed()) Api.call(c, "GET", "/api/posts?limit=20&topic=$topic&rev=$rev", null) { code, j ->
                if (code in 200..299 && j != null) {
                    msg = ""
                    if (!j.optBoolean("unchanged")) { posts = parsePosts(j); rev = j.optString("rev"); hasMore = posts.size >= 20 }
                } else msg = apiMsg(code, j)
            }
            delay(8000)
        }
    }

    fun loadMore() {
        val last = posts.lastOrNull()?.id ?: return
        loadingMore = true
        Api.call(c, "GET", "/api/posts?limit=20&topic=$topic&before=$last", null) { code, j ->
            loadingMore = false
            if (code in 200..299 && j != null) { val older = parsePosts(j); posts = posts + older; hasMore = older.size >= 20 } else msg = apiMsg(code, j)
        }
    }

    if (needLogin) AlertDialog(onDismissRequest = { needLogin = false },
        title = { Text("Cần đăng nhập") }, text = { Text("Hãy đăng nhập để đăng cảnh báo, bình luận và bày tỏ quan điểm.") },
        confirmButton = { TextButton({ needLogin = false; onLogin() }) { Text("Đăng nhập") } },
        dismissButton = { TextButton({ needLogin = false }) { Text("Để sau") } })

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp), Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔥 Cảnh Báo Nổi Bật", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(8.dp).background(if (msg.isEmpty()) C.Ok else C.Bad, CircleShape))
                    Text(if (msg.isEmpty()) "Trực tiếp" else "Mất kết nối", color = C.Dim, fontSize = 12.sp)
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeedChip("Tất cả", topic == "") { topic = "" }
                TOPICS.forEach { (k, l) -> FeedChip(l, topic == k) { topic = k } }
            }
            if (msg.isNotEmpty()) {
                Text(msg, color = C.Warn, fontSize = 13.sp)
                TextButton({ retry++ }) { Text("Thử lại", color = FeedCyan) }
            }
            if (posts.isEmpty() && msg.isEmpty()) Text("Chưa có cảnh báo nào trong mục này. Hãy là người đầu tiên chia sẻ!", color = C.Sub, fontSize = 14.sp)
            posts.forEach { p -> PostCard(p) { onOpen(p.id) } }
            if (hasMore) TextButton({ if (!loadingMore) loadMore() }, Modifier.fillMaxWidth()) { Text(if (loadingMore) "Đang tải…" else "Xem thêm cảnh báo cũ hơn", color = FeedCyan) }
            Spacer(Modifier.height(96.dp))
        }
        Column(Modifier.align(Alignment.BottomEnd).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(58.dp).background(Brush.verticalGradient(listOf(Color(0xFFFB923C), Color(0xFFEA580C))), CircleShape)
                .clickable { if (logged) onCompose() else needLogin = true }, contentAlignment = Alignment.Center) {
                Text("➕", fontSize = 24.sp) }
            Text("Báo cáo", color = Color(0xFFFB923C), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 3.dp))
        }
    }
}

// ───────────────────────── Đăng cảnh báo ─────────────────────────

@Composable private fun ComposePost(c: Context, onBack: () -> Unit, onDone: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("dien-thoai") }
    var sev by remember { mutableStateOf("medium") }
    var sending by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    fun send() {
        sending = true; msg = "Đang đăng…"
        Api.call(c, "POST", "/api/posts", JSONObject().put("title", title.trim()).put("body", body.trim()).put("topic", topic).put("severity", sev)) { code, j ->
            sending = false
            if (code in 200..299) onDone() else msg = apiMsg(code, j)
        }
    }

    Page("Đăng cảnh báo", onBack) {
        Text("Chủ đề", color = C.Dim, fontSize = 13.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { TOPICS.forEach { (k, l) -> FeedChip(l, topic == k) { topic = k } } }
        Text("Mức độ nguy hiểm", color = C.Dim, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { SEVERITIES.forEach { (k, l) -> FeedChip(l, sev == k) { sev = k } } }
        OutlinedTextField(title, { title = it.take(120) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Tiêu đề (tối thiểu 3 ký tự)") })
        OutlinedTextField(body, { body = it.take(1000) }, Modifier.fillMaxWidth(), minLines = 5,
            label = { Text("Nội dung") }, placeholder = { Text("Chuyện gì xảy ra? Số điện thoại, nội dung tin nhắn, cách nhận biết…") })
        Text("${body.length}/1000 • Bài đăng hiển thị công khai dưới tên hiển thị của bạn. Không đăng OTP, số thẻ, mật khẩu hay thông tin cá nhân của người khác.", fontSize = 11.sp, color = C.Sub)
        if (msg.isNotEmpty()) Text(msg, color = C.Warn, fontSize = 13.sp)
        GoldButton("Đăng cảnh báo", enabled = title.trim().length >= 3 && body.trim().length >= 5 && !sending) { send() }
    }
}

// ───────────────────────── Chi tiết + bình luận công khai ─────────────────────────

@Composable private fun PostDetail(c: Context, id: Long, logged: Boolean, onLogin: () -> Unit, onBack: () -> Unit) {
    var post by remember { mutableStateOf<Post?>(null) }
    var comments by remember { mutableStateOf<List<Comment>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    val resumed = rememberIsResumed()

    // Bình luận mới của người khác hiện sau tối đa 5 giây.
    LaunchedEffect(id, logged, refresh) {
        while (true) {
            if (resumed()) Api.call(c, "GET", "/api/posts/$id", null) { code, j ->
                if (code in 200..299 && j != null) { post = parsePost(j.optJSONObject("post")); comments = parseComments(j); msg = "" }
                else if (code == 404 && post != null) { post = null; msg = "Bài viết không còn tồn tại hoặc đã bị ẩn." }
                else msg = apiMsg(code, j)
            }
            delay(5000)
        }
    }

    fun need(): Boolean { if (!logged) onLogin(); return !logged }
    fun like() { if (need()) return
        Api.call(c, "POST", "/api/posts/$id/like", null) { code, j ->
            if (code in 200..299 && j != null) post = post?.copy(liked = j.optBoolean("liked"), likes = j.optInt("likes")) else msg = apiMsg(code, j) } }
    fun reportPost() { if (need()) return
        Api.call(c, "POST", "/api/posts/$id/report", null) { code, j -> msg = if (code in 200..299) "Đã gửi báo cáo, cảm ơn bạn" else apiMsg(code, j) } }
    fun deletePost() = Api.call(c, "DELETE", "/api/posts/$id", null) { code, j -> if (code in 200..299) onBack() else msg = apiMsg(code, j) }
    fun sendComment() {
        sending = true
        Api.call(c, "POST", "/api/posts/$id/comments", JSONObject().put("body", draft.trim())) { code, j ->
            sending = false
            if (code in 200..299) { draft = ""; msg = ""; refresh++ } else msg = apiMsg(code, j)
        }
    }
    fun reportComment(cid: Long) = Api.call(c, "POST", "/api/comments/$cid/report", null) { code, j -> msg = if (code in 200..299) "Đã gửi báo cáo bình luận, cảm ơn bạn" else apiMsg(code, j) }
    fun deleteComment(cid: Long) = Api.call(c, "DELETE", "/api/comments/$cid", null) { code, j -> if (code in 200..299) refresh++ else msg = apiMsg(code, j) }

    confirm?.let { (text, action) ->
        AlertDialog(onDismissRequest = { confirm = null }, title = { Text("Xác nhận") }, text = { Text(text) },
            confirmButton = { TextButton({ confirm = null; action() }) { Text("Xóa") } },
            dismissButton = { TextButton({ confirm = null }) { Text("Hủy") } })
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("←", color = FeedCyan, fontSize = 26.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 14.dp, top = 4.dp, bottom = 4.dp))
                Text("Chi tiết cảnh báo", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            if (msg.isNotEmpty()) Text(msg, color = C.Warn, fontSize = 13.sp)
            val p = post
            if (p == null) {
                if (msg.isEmpty()) Text("Đang tải…", color = C.Sub)
            } else {
                Column(Modifier.fillMaxWidth().background(FeedCard, RoundedCornerShape(20.dp)).border(BorderStroke(1.dp, FeedBorder), RoundedCornerShape(20.dp)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Tag(topicLabel(p.topic).uppercase(), topicColor(p.topic))
                            if (p.official) Tag("CHÍNH THỨC", FeedCyan)
                        }
                        Text(timeAgo(p.ts), color = C.Dim, fontSize = 12.sp)
                    }
                    Text(p.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(p.body, color = Color.White, fontSize = 15.sp, lineHeight = 22.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AuthorDot(p.author)
                        Column { Text(p.author, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text("🛡️ Mức độ: ${sevLabel(p.severity)}", color = C.Dim, fontSize = 12.sp) }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(FeedBorder))
                    Row(horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text((if (p.liked) "👍 Hữu ích " else "👍🏻 Hữu ích ") + p.likes, fontSize = 14.sp, color = if (p.liked) C.Ok else C.Sub, modifier = Modifier.clickable { like() })
                        if (p.mine) Text("🗑 Xóa bài", fontSize = 14.sp, color = C.Bad, modifier = Modifier.clickable { confirm = "Xóa vĩnh viễn bài viết và các bình luận của nó?" to { deletePost() } })
                        else Text("🚩 Báo cáo", fontSize = 14.sp, color = C.Sub, modifier = Modifier.clickable { reportPost() })
                    }
                }
                Text("💬 Bình luận (${comments.size})", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                if (comments.isEmpty()) Text("Chưa có bình luận. Hãy là người đầu tiên!", color = C.Sub, fontSize = 13.sp)
                comments.forEach { cm ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AuthorDot(cm.author)
                        Column(Modifier.weight(1f).background(FeedCard, RoundedCornerShape(14.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text(cm.author + (if (cm.mine) " (bạn)" else ""), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(timeAgo(cm.ts), color = C.Dim, fontSize = 11.sp)
                            }
                            Text(cm.body, color = C.Sub, fontSize = 14.sp, lineHeight = 20.sp)
                            if (cm.mine) Text("Xóa", color = C.Bad, fontSize = 12.sp, modifier = Modifier.clickable { confirm = "Xóa bình luận này?" to { deleteComment(cm.id) } })
                            else Text("Báo cáo", color = C.Dim, fontSize = 12.sp, modifier = Modifier.clickable { if (!need()) reportComment(cm.id) })
                        }
                    }
                }
            }
        }
        if (post != null) Box(Modifier.fillMaxWidth().background(C.Bar).padding(10.dp)) {
            if (logged) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(draft, { draft = it.take(500) }, Modifier.weight(1f), maxLines = 3, placeholder = { Text("Viết bình luận công khai…") })
                Button({ if (!sending) sendComment() }, enabled = draft.isNotBlank() && !sending, shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FeedCyan, contentColor = Color(0xFF042F2E))) { Text(if (sending) "…" else "Gửi", fontWeight = FontWeight.Bold) }
            } else Button(onLogin, Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = FeedCyan, contentColor = Color(0xFF042F2E))) { Text("Đăng nhập để bình luận", fontWeight = FontWeight.Bold) }
        }
    }
}
