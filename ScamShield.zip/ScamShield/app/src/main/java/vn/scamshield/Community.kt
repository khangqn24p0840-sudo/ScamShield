package vn.scamshield

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Một bài đăng trong mục Cộng đồng. */
data class Post(
    val id: Long, val author: String, val body: String, val cat: String,
    val ts: Long, val likes: Int, val liked: Boolean, val mine: Boolean
)

private val CATS = listOf("canh-bao" to "🚨 Cảnh báo", "hoi-dap" to "❓ Hỏi đáp", "kinh-nghiem" to "💡 Kinh nghiệm")

private fun catLabel(k: String) = CATS.firstOrNull { it.first == k }?.second ?: "🚨 Cảnh báo"

private fun parsePosts(j: JSONObject?): List<Post> {
    val a = j?.optJSONArray("posts") ?: return emptyList()
    return (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Post(o.optLong("id"), o.optString("author"), o.optString("body"), o.optString("cat"),
            o.optLong("ts"), o.optInt("likes"), o.optBoolean("liked"), o.optBoolean("mine"))
    }
}

@Composable private fun CatChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.background(if (on) C.Tile else C.Bar, RoundedCornerShape(16.dp)).clickable(onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 7.dp)) {
        Text(label, fontSize = 13.sp, color = if (on) C.Ink else Color.White, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
    }
}

/** Mục Cộng đồng: xem bài, đăng bài, thích, báo cáo, xóa bài của mình. Cần đăng nhập. */
@Composable fun CommunityTab(c: Context, onLogin: () -> Unit) {
    val logged = Store.str(c, "token").isNotEmpty()
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("canh-bao") }
    var askDel by remember { mutableStateOf<Post?>(null) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale("vi", "VN")) }

    fun load() {
        loading = true
        Api.call(c, "GET", "/api/posts", null) { code, j ->
            loading = false
            if (code in 200..299) { posts = parsePosts(j); msg = "" } else msg = err(j)
        }
    }
    LaunchedEffect(logged) { if (logged) load() }

    fun send() {
        sending = true; msg = "Đang đăng…"
        val body = JSONObject().put("body", draft.trim()).put("cat", cat).put("author", displayName(c))
        Api.call(c, "POST", "/api/posts", body) { code, j ->
            sending = false
            if (code in 200..299) { draft = ""; msg = "Đã đăng bài"; load() } else msg = err(j)
        }
    }
    fun like(p: Post) = Api.call(c, "POST", "/api/posts/${p.id}/like", null) { code, j ->
        if (code in 200..299 && j != null)
            posts = posts.map { if (it.id == p.id) it.copy(liked = j.optBoolean("liked"), likes = j.optInt("likes")) else it }
        else msg = err(j)
    }
    fun report(p: Post) = Api.call(c, "POST", "/api/posts/${p.id}/report", null) { code, j ->
        msg = if (code in 200..299) "Đã gửi báo cáo, cảm ơn bạn" else err(j)
    }
    fun remove(p: Post) = Api.call(c, "DELETE", "/api/posts/${p.id}", null) { code, j ->
        if (code in 200..299) { posts = posts.filter { it.id != p.id }; msg = "Đã xóa bài" } else msg = err(j)
    }

    if (!logged) {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("👥", fontSize = 48.sp)
            Text("Cộng đồng cảnh báo lừa đảo", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            Text("Đăng nhập để xem và chia sẻ cảnh báo với mọi người.", color = C.Sub, fontSize = 14.sp, modifier = Modifier.padding(vertical = 12.dp))
            Button(onLogin, colors = ButtonDefaults.buttonColors(containerColor = C.Teal, contentColor = C.Ink)) { Text("Đăng nhập / Đăng ký") }
        }
        return
    }

    askDel?.let { p ->
        AlertDialog(onDismissRequest = { askDel = null },
            title = { Text("Xóa bài đăng?") }, text = { Text("Bài viết sẽ bị xóa vĩnh viễn.") },
            confirmButton = { TextButton({ remove(p); askDel = null }) { Text("Xóa") } },
            dismissButton = { TextButton({ askDel = null }) { Text("Hủy") } })
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("👥 Cộng đồng", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton({ if (!loading) load() }) { Text(if (loading) "Đang tải…" else "Tải lại") }
        }
        Glass {
            Text("Chia sẻ cảnh báo", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { CATS.forEach { (k, l) -> CatChip(l, cat == k) { cat = k } } }
            OutlinedTextField(draft, { draft = it.take(1000) }, Modifier.fillMaxWidth(), minLines = 3,
                placeholder = { Text("Bạn vừa gặp kiểu lừa đảo nào? Số điện thoại, nội dung tin nhắn, cách nhận biết…") })
            Text("${draft.length}/1000 • Bài đăng hiển thị công khai cho mọi người dùng. Không đăng OTP, số thẻ, mật khẩu hay thông tin cá nhân của người khác.",
                fontSize = 11.sp, color = C.Sub)
            Button({ if (!sending) send() }, Modifier.fillMaxWidth(), enabled = draft.trim().length >= 5 && !sending) { Text("Đăng bài") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.Warn)
        if (posts.isEmpty() && !loading) Text("Chưa có bài đăng nào. Hãy là người đầu tiên chia sẻ!", color = C.Sub, fontSize = 14.sp)
        posts.forEach { p ->
            Column(Modifier.fillMaxWidth().background(C.Brown, RoundedCornerShape(18.dp)).padding(14.dp), Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(34.dp).background(C.Gold, RoundedCornerShape(17.dp)), contentAlignment = Alignment.Center) {
                        Text(p.author.take(1).uppercase(), color = Color(0xFF2A1F00), fontWeight = FontWeight.Bold) }
                    Column(Modifier.weight(1f)) {
                        Text(p.author.ifBlank { "Ẩn danh" }, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(catLabel(p.cat) + " • " + fmt.format(Date(p.ts * 1000)), fontSize = 11.sp, color = C.Dim)
                    }
                }
                Text(p.body, fontSize = 14.sp, color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Text((if (p.liked) "👍 " else "👍🏻 ") + p.likes, fontSize = 13.sp, color = if (p.liked) C.Ok else C.Sub, modifier = Modifier.clickable { like(p) })
                    if (p.mine) Text("🗑 Xóa", fontSize = 13.sp, color = C.Bad, modifier = Modifier.clickable { askDel = p })
                    else Text("🚩 Báo cáo", fontSize = 13.sp, color = C.Sub, modifier = Modifier.clickable { report(p) })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
