package vn.scamshield
import java.text.Normalizer

data class Result(val score: Int, val reasons: List<String>) {
    /** 0 = an toàn, 1 = đáng ngờ, 2 = nguy hiểm. Ngưỡng đã hạ (trước đây 30/60) để ít bỏ sót hơn, đổi lại có thể báo nhầm nhiều hơn. */
    val level get() = when { score >= 50 -> 2; score >= 25 -> 1; else -> 0 }
    /** Ngưỡng báo sớm cho cuộc gọi trực tiếp: vàng từ 10, đỏ từ 30 */
    val live get() = when { score >= 30 -> 2; score >= 10 -> 1; else -> 0 }
}

object ScamDetector {
    fun norm(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace('đ', 'd')

    /**
     * Một quy tắc: biểu thức (viết trên văn bản đã bỏ dấu), điểm, nhãn hiển thị, giai đoạn của thủ đoạn:
     * X chuyển sang kênh khác, L dụ dỗ, M đòi tiền/thông tin, P đe dọa/ép thời gian, N khác.
     * Giai đoạn dùng cho ThreadGuard để nhận ra thủ đoạn diễn ra qua nhiều tin nhắn, nhiều ngày.
     */
    private class Rule(val re: Regex, val pts: Int, val label: String, val stage: Char)

    private val rules = listOf(
        Rule(Regex("""cong an|vien kiem sat|toa an|co quan dieu tra|bo cong an|lenh bat|trieu tap"""), 40, "Giả danh cơ quan chức năng", 'P'),
        Rule(Regex("""tai khoan.*(khoa\b|dong bang|tam ngung|bi han che)|xac thuc.*tai khoan"""), 30, "Dọa khóa/đóng băng tài khoản", 'P'),
        Rule(Regex("""\botp\b|ma xac thuc|ma xac minh|mat khau|so the|cvv"""), 30, "Hỏi mã OTP / thông tin nhạy cảm", 'M'),
        Rule(Regex("""trung thuong|trung giai|nhan qua|qua tang|voucher mien phi"""), 35, "Lừa trúng thưởng", 'L'),
        Rule(Regex("""viec nhe luong cao|lam nhiem vu|cong tac vien|hoa hong|chot don|tang don|tha tim|like video"""), 40, "Lừa tuyển việc làm online / nhiệm vụ", 'L'),
        Rule(Regex("""dau tu|loi nhuan|sinh loi|tien ao|usdt|crypto|cam ket lai|forex"""), 30, "Lừa đầu tư sinh lời", 'L'),
        Rule(Regex("""giai ngan|duyet vay|vay nhanh|lai suat 0|phi ho so"""), 25, "Lừa vay tiền / thu phí trước", 'L'),
        Rule(Regex("""vneid|dich vu cong|bhxh|tien dien|cuoc vien thong|cuc thue|bien ban phat"""), 20, "Giả mạo dịch vụ công / tiện ích", 'N'),
        Rule(Regex("""khan cap|ngay lap tuc|trong 24 gio|het han|neu khong se"""), 15, "Tạo áp lực thời gian", 'P'),
        Rule(Regex("""chuyen khoan|chuyen tien|nap tien|dong phi"""), 15, "Yêu cầu chuyển tiền", 'M'),
        Rule(Regex("""zalo\.me|t\.me/|telegram|lien he zalo|them zalo"""), 15, "Dẫn sang Zalo/Telegram", 'X'),
        Rule(Regex("""bit\.ly|tinyurl|cutt\.ly|rebrand\.ly|\.xyz|\.top|\.vip|\.club|\.icu|\.cc\b|http://"""), 30, "Link rút gọn / tên miền đáng ngờ", 'N'),
        Rule(Regex("""tai khoan an toan|phong toa|xac minh danh tinh|rua tien|duong day|vu an|dieu tra|ma so thue|can cuoc|cccd"""), 35, "Dọa liên quan vụ án / yêu cầu xác minh danh tính", 'P'),
        Rule(Regex("""sim.*(bi khoa|het han)|thue bao.*(khoa|ngung)"""), 30, "Dọa khóa SIM", 'P'),
        Rule(Regex("""anydesk|ultraviewer|teamviewer|chia se man hinh|cai ung dung|tai ung dung|cai dat app"""), 35, "Yêu cầu cài app / chia sẻ màn hình", 'M'),
        Rule(Regex("""buu dien|buu cuc|giao hang|don hang|\bhoan tien|\bhoan phi|shipper"""), 20, "Giả giao hàng / hoàn tiền", 'L'),
        Rule(Regex("""ngan hang|nhan vien|can bo|hop tac|giu bi mat|khong noi voi ai"""), 15, "Nhắc ngân hàng / yêu cầu giữ bí mật", 'N'),
        Rule(Regex("""https?://|www\."""), 10, "Chứa đường link", 'N'),
        Rule(Regex("""chuyen khoan truoc|thanh toan truoc|coc truoc|\bck truoc|ung truoc|dat coc|tien coc|coc (30|40|50)"""), 30, "Đòi đặt cọc / thanh toán trước khi nhận hàng, dịch vụ", 'M'),
        Rule(Regex("""combo|\btour\b|khach san|resort|ve may bay|\bvisa\b|thi thuc|ve gia re|phong nghi"""), 15, "Quảng cáo du lịch / vé / visa (hay bị giả mạo)", 'L'),
        Rule(Regex("""gia (re|sieu re|soc|hat de)|re hon (thi truong|\d+)|chi tu \d+ ?k|xa kho|thanh ly gap|flash ?sale|giam (gia )?(den )?\d+ ?%"""), 20, "Giá rẻ bất thường / khuyến mãi sốc", 'L'),
        Rule(Regex("""chi con \d+|con (lai )?\d+ (suat|cho|may|cai|chiec|phong|ve)|so luong (co han|it)|sap het hang|het (cho|suat) hom nay"""), 20, "Ép mua nhanh, 'sắp hết hàng/suất'", 'P'),
        Rule(Regex("""cam ket (dau|thanh cong|hoan|khong dau)|(dau|thanh cong) 100 ?%|\bhoan (lai )?100 ?%|bao dau|khong dau (hoan|tra) (lai )?tien"""), 30, "Cam kết quá chắc chắn (đậu 100%, hoàn tiền 100%)", 'L'),
        Rule(Regex("""da (chuyen|ck|thanh toan) (khoan )?(roi|xong|thanh cong)|(gui|xem) (bill|bien lai|hoa don)|(bill|bien lai).{0,20}(chuyen|ck)|ngan hang (xu ly cham|dang xu ly|treo|bao tri)|tien (se )?(ve|vao) (sau|cham)|(giao|gui|ship) hang (di|truoc)"""), 30, "Nói đã chuyển tiền / gửi bill rồi giục giao hàng (bill có thể giả)", 'M'),
        Rule(Regex("""cap cuu|nguy kich|phau thuat|vien phi"""), 30, "Báo người thân cấp cứu / cần viện phí gấp", 'P'),
        Rule(Regex("""tai nan|nhap vien"""), 15, "Nhắc tai nạn / nhập viện", 'P'),
        Rule(Regex("""(giao vien|co giao|thay giao|y ta|bac si|benh vien|nhan vien y te).{0,60}(con (ban|em|chi|anh)|nguoi than|me ban|bo ban|vo ban|chong ban)"""), 20, "Giả danh giáo viên / y tế nói người thân gặp chuyện", 'P'),
        Rule(Regex("""(doi|dung|co) so (moi|khac)|so moi (cua|nay)|luu (lai )?so (moi|nay)|(toi|anh|chi|em|me|bo|sep) (la|day).{0,15}so moi"""), 30, "Báo 'đổi số mới' (giả danh người quen / sếp)", 'P'),
        Rule(Regex("""(cho|can|xin) (em |minh |toi |tui |anh |chi )?(muon|vay|nho).{0,20}(tien|\d+ ?(tr|k|trieu|nghin))|(chuyen|ck|nap|mua) (giup|ho|dum|gium)|(chuyen|nap|mua).{0,12}the (cao|dien thoai)|vay (tam|gap)|(muon|vay) gap|tra (lai )?(sau|ngay mai|cuoi tuan|cuoi thang)"""), 35, "Nhờ chuyển tiền / mua thẻ / mượn tiền gấp (nghi bị chiếm tài khoản)", 'M'),
        Rule(Regex("""\bvote\b|binh chon|ban (co )?(trong|thay).{0,10}(anh|clip|video)|xem (anh|video|clip) (nay|cua ban)|boc phot|bi lo (anh|clip)|ban la ai|(anh|clip|video) cua ban"""), 25, "Mồi 'bình chọn / ảnh / clip' kèm link (phishing mạng xã hội)", 'L'),
        Rule(Regex("""mau nhi|tuyen (nguoi )?mau|thu thach|chup anh (quang cao|san pham)|ung tuyen.{0,15}(mau|be)|quang ba san pham"""), 35, "Tuyển người mẫu / 'thử thách' mua hàng", 'L'),
        Rule(Regex("""(mua san pham|chuyen khoan mua).{0,60}(\bhoan|goc|hoa hong)|(\bhoan (lai )?(tien|goc)|nhan (lai )?goc|goc (va|\+) (loi|hoa hong)).{0,60}hoa hong|hoa hong (tung|moi) don"""), 30, "Bỏ tiền mua hàng rồi được 'hoàn tiền kèm hoa hồng'", 'M'),
        Rule(Regex("""vay (tin chap|von|nhanh|tien)|khoan vay|ho tro vay|khong (can )?(the chap|chung minh)|lai suat (thap|uu dai)"""), 20, "Quảng cáo vay tiền", 'L'),
        Rule(Regex("""phi (bao hiem|bao lanh|xac minh|duyet|giai ngan|kich hoat|mo khoa)|nop them|loi he thong|sai ten (nguoi )?huong|dong bang khoan vay|ho so (bi )?(loi|sai)"""), 35, "Đòi nộp thêm 'phí' để giải ngân / sửa lỗi / rút tiền", 'M'),
        Rule(Regex("""(gui|chup|cung cap) .{0,12}(anh|hinh).{0,20}(cccd|can cuoc|cmnd|chan dung|giay to)|anh (cccd|can cuoc|cmnd)|chan dung.{0,10}cccd"""), 30, "Xin ảnh giấy tờ cá nhân (CCCD / chân dung)", 'M'),
        Rule(Regex("""\d+ ?%.{0,12}(thang|ngay|tuan|nam)|\d+ ?%/ ?(thang|ngay|tuan)|lai (suat )?\d+ ?%"""), 30, "Hứa lãi suất / lợi nhuận cao bất thường", 'L'),
        Rule(Regex("""san (giao dich|forex|crypto|vang|chung khoan)|nen tang dau tu|nhom dau tu|chuyen gia (dau tu|phan tich|tai chinh)|tin hieu (mua|ban)|ky quy|von toi thieu|da cap|hoi (thao|nghi) dau tu|chung khoan quoc te"""), 30, "Sàn / nhóm đầu tư, ký quỹ, đa cấp", 'L'),
        Rule(Regex("""khong rut (duoc|tien)|(dong|nop) (phi|thue).{0,25}(de )?(rut|nhan)|(phai|can|moi).{0,15}(dong|nop).{0,15}(phi|thue)|xac minh.{0,10}(de )?rut"""), 40, "Đòi phí / thuế mới cho rút tiền (dấu hiệu sàn lừa)", 'M'),
        Rule(Regex("""\bctv\b|lam (tai nha|online)|kiem them thu nhap|viec lam (online|tai nha)|nhiem vu (hang ngay|tren app)|nhan (don|nhiem vu)|danh gia 5 sao|tang (luot|tuong tac)|\d+ ?(k|tr|trieu)/ ?(ngay|gio|thang)"""), 25, "Việc làm online / nhận nhiệm vụ lấy hoa hồng", 'L'),
        Rule(Regex("""\bung (tien|truoc|von)|nap (tien|them) .{0,12}(nhan|lam|mo)|don (hang )?(gia tri cao|vip|lien hoan|dac biet|ket hop)|ket hop don|don lien hoan"""), 40, "Bắt ứng tiền / nạp thêm để làm nhiệm vụ", 'M'),
        Rule(Regex("""chuyen nham|nham (tai khoan|so)|vo (tinh|y) chuyen|(tra|hoan) (lai )?(so )?tien (da )?(nham|chuyen)|hoan tra (so )?tien"""), 35, "Nói chuyển nhầm tiền, đòi hoàn trả", 'M'),
        Rule(Regex("""thu hoi no|doi no|no qua han|nhac no|lai (cat co|\d+ ?%/ ?ngay)|truy (thu|no)|khoan vay (cua ban|da (nhan|giai))"""), 35, "Dọa đòi nợ / khoản vay không có thật", 'P'),
        Rule(Regex("""lay lai (tien|facebook|fb|tai khoan)|thu hoi (tien|tai khoan)|ho tro lay lai|mo khoa (facebook|fb|tai khoan)|khoi phuc (tai khoan|facebook)|luat su ho tro|dich vu thu hoi|hoan lai so tien da (mat|bi lua)"""), 35, "Dịch vụ 'lấy lại tiền / tài khoản' (hay là lừa lần hai)", 'L'),
        Rule(Regex("""(xin|gui|doc|nhap|cho) (lai )?(toi |minh |em |anh |chi )?(ma|code)\b|ma (dang nhap|xac nhan|bao mat)|ma \d ?so|login code|code (dang nhap|telegram)"""), 35, "Xin / nhờ đọc mã xác nhận", 'M'),
        Rule(Regex("""(ky su|bac si|si quan|linh|doanh nhan|nguoi (my|anh|duc|nhat|han)).{0,30}(nuoc ngoai|\bmy\b|syria|\buc\b|dubai|singapore|canada|anh quoc)|dinh cu|(sang|ve) viet nam (gap|dinh|thang)"""), 30, "Làm quen người nước ngoài / hứa gặp (lừa tình cảm)", 'L'),
        Rule(Regex("""hai quan|thue (hai quan|nhap khau)|phi (van chuyen|thong quan|luu kho)|tam giu|buu kien.{0,30}(phi|thue)"""), 40, "Đòi phí hải quan / thuế để nhận bưu kiện, quà", 'M'),
        Rule(Regex("""gui (anh|hinh|video) (nong|nhay cam|rieng tu)|phat tan (anh|clip|video)|bi lo (anh|clip)"""), 40, "Đe dọa phát tán ảnh / clip, tống tiền", 'P'),
        Rule(Regex("""(so|con|dan) (de|lo|dep)\b|lo de|bao lo|song thu|bach thu|chot so|cau (lo|de)|nuoi (lo|khung)|\bxien \d|soi cau"""), 35, "Chào bán số đề / soi cầu", 'L'),
        Rule(Regex("""phi (cau|soi|dang ky|tu van|may man|tien tri)|chia (hoa hong|lai|thuong|\d+ ?%)"""), 30, "Đòi phí / chia hoa hồng khi trúng", 'M'),
        Rule(Regex("""flash ?ai|nghe may.{0,25}(mat|tru|hut) tien|(nhan|nghe) cuoc goi.{0,20}(mat|tru|hut) tien|dung (nghe|bat) may|chuyen tiep (cho )?(moi|nguoi than)|chia se (gap|ngay) cho"""), 25, "Tin đồn 'nghe máy bị mất tiền' (tin giả, đừng chia sẻ)", 'N'),
    )

    private val stageByLabel = rules.associate { it.label to it.stage }
    fun stageOf(label: String): Char = stageByLabel[label] ?: 'N'

    /** Các quy tắc khớp với văn bản: (nhãn, điểm). Không gồm mô hình TFLite, danh sách số tài khoản hay tên miền. */
    fun hits(text: String): List<Pair<String, Int>> {
        val t = norm(text)
        return rules.filter { it.re.containsMatchIn(t) }.map { it.label to it.pts }
    }

    fun analyze(text: String): Result {
        var score = 0
        val why = mutableListOf<String>()
        for ((label, pts) in hits(text)) { score += pts; why += label }
        // Mô hình học máy TFLite: chỉ CỘNG điểm khi tin chắc là lừa đảo (tối đa +30), không bao giờ trừ điểm của bộ quy tắc
        val p = TextModel.predict(text)
        if (p != null && p >= 0.5f) {
            score += ((p - 0.5f) * 60f).toInt()
            why += "Mô hình học máy (TFLite): ${(p * 100).toInt()}% giống mẫu lừa đảo"
        }
        AccountGuard.checkText(text)?.let { score += 90; why += it }   // số tài khoản nằm trong danh sách lừa đảo
        DomainGuard.checkText(text)?.let { score += 85; why += it }    // link tới tên miền lừa đảo
        return Result(score.coerceAtMost(100), why)
    }
}
