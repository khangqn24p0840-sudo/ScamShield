package vn.scamshield

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ngân hàng theo mã BIN do NAPAS cấp (mã này nằm trong mã VietQR).
 * Danh sách viết từ trí nhớ, hãy đối chiếu lại với danh sách chính thức của NAPAS trước khi phát hành.
 * Mã lạ vẫn hiển thị được dưới dạng "Ngân hàng (BIN xxxxxx)".
 */
object Banks {
    data class Bank(val bin: String, val name: String)

    val all = listOf(
        Bank("970436", "Vietcombank"), Bank("970415", "VietinBank"), Bank("970418", "BIDV"), Bank("970405", "Agribank"),
        Bank("970407", "Techcombank"), Bank("970422", "MB Bank"), Bank("970423", "TPBank"), Bank("970432", "VPBank"),
        Bank("970416", "ACB"), Bank("970403", "Sacombank"), Bank("970441", "VIB"), Bank("970437", "HDBank"),
        Bank("970448", "OCB"), Bank("970426", "MSB"), Bank("970443", "SHB"), Bank("970431", "Eximbank"),
        Bank("970429", "SCB"), Bank("970440", "SeABank"), Bank("970425", "ABBank"), Bank("970438", "BaoViet Bank"),
        Bank("970449", "LPBank (LienVietPostBank)"), Bank("970428", "Nam A Bank"), Bank("970412", "PVcomBank"),
        Bank("970409", "BacA Bank"), Bank("970419", "NCB"), Bank("970427", "VietABank"), Bank("970430", "PG Bank"),
        Bank("970433", "VietBank"), Bank("970452", "KienlongBank"), Bank("970454", "Viet Capital Bank"),
        Bank("970400", "SaigonBank"), Bank("970406", "DongA Bank"), Bank("970408", "GPBank"), Bank("970444", "CBBank"),
        Bank("970446", "Co-opBank"), Bank("970457", "Woori Bank"), Bank("970424", "Shinhan Bank"), Bank("970442", "Hong Leong Bank")
    )

    fun byBin(bin: String): Bank? = all.firstOrNull { it.bin == bin }
    fun name(bin: String): String = if (bin.isEmpty()) "Không rõ ngân hàng" else byBin(bin)?.name ?: "Ngân hàng (BIN $bin)"
}

/**
 * Danh sách số tài khoản lừa đảo lưu trong máy, mỗi mục dạng "bin:sốTK" (bin có thể rỗng = không rõ ngân hàng).
 * Mục không có bin khớp mọi ngân hàng; nếu người dùng không nêu ngân hàng thì cũng khớp mọi mục có số đó.
 * Nhờ đăng ký trong ScamDetector.analyze, mọi tin nhắn / thông báo / nội dung cuộc gọi có chứa số này đều được cảnh báo.
 */
object AccountGuard {
    private const val KEY = "acc_bl"
    private var appCtx: Context? = null
    fun init(c: Context) { appCtx = c.applicationContext }

    fun digits(s: String) = s.filter { it.isDigit() }
    fun valid(acct: String) = acct.length in 6..19

    /**
     * Có vẻ là SỐ THẺ (15–19 chữ số, qua kiểm tra Luhn, đầu số thẻ thường gặp). Số thẻ nhạy cảm hơn số tài khoản nhiều:
     * app không lưu và không gửi số này lên máy chủ. (Một số tài khoản dài có thể bị nhận nhầm, khi đó chỉ mất phần hỏi cộng đồng.)
     */
    fun looksLikeCard(acct: String): Boolean {
        val a = digits(acct)
        if (a.length !in 15..19) return false
        var sum = 0; var alt = false
        for (i in a.length - 1 downTo 0) {
            var d = a[i] - '0'
            if (alt) { d *= 2; if (d > 9) d -= 9 }
            sum += d; alt = !alt
        }
        return sum % 10 == 0 && (a.startsWith("9704") || a[0] in "23456")
    }
    fun mask(acct: String) = if (acct.length <= 4) acct else "•".repeat(acct.length - 4) + acct.takeLast(4)

    fun entries(c: Context): List<String> = Store.str(c, KEY).split('\n').filter { it.contains(':') }.distinct()
    private fun save(c: Context, list: List<String>) = Store.putStr(c, KEY, list.joinToString("\n"))

    fun add(c: Context, acct: String, bin: String): Boolean {
        val a = digits(acct)
        if (!valid(a) || looksLikeCard(a)) return false
        val e = "$bin:$a"
        val cur = entries(c)
        if (e !in cur) save(c, cur + e)
        return true
    }

    fun remove(c: Context, entry: String) = save(c, entries(c).filter { it != entry })

    /** Gỡ mọi mục đang làm cho isListed(acct, bin) trả về true. */
    fun removeMatching(c: Context, acct: String, bin: String) {
        val a = digits(acct)
        save(c, entries(c).filterNot { e ->
            val i = e.indexOf(':')
            e.substring(i + 1) == a && (bin.isEmpty() || e.substring(0, i).isEmpty() || e.substring(0, i) == bin)
        })
    }

    fun isListed(c: Context, acct: String, bin: String): Boolean {
        val a = digits(acct)
        if (!valid(a)) return false
        return entries(c).any { e ->
            val i = e.indexOf(':')
            e.substring(i + 1) == a && (bin.isEmpty() || e.substring(0, i).isEmpty() || e.substring(0, i) == bin)
        }
    }

    // ───────── Tìm số tài khoản trong văn bản (tin nhắn, thông báo, lời thoại cuộc gọi) ─────────

    // Văn bản đã bỏ dấu + chữ thường. Chỉ nhận số đứng ngay sau từ khóa chuyển khoản hoặc tên ngân hàng, tránh bắt nhầm số khác.
    private val KW = Regex("(?:\\bstk\\b|\\bso tk\\b|so tai khoan|\\btai khoan\\b|\\bchuyen khoan\\b|\\bchuyen tien\\b|\\bck\\b|\\baccount\\b)[^0-9]{0,20}((?:\\d[ .-]?){8,19})")
    private val BANKS = mapOf(
        "vietcombank" to "970436", "vcb" to "970436", "vietinbank" to "970415", "bidv" to "970418", "agribank" to "970405",
        "techcombank" to "970407", "tcb" to "970407", "mbbank" to "970422", "mb bank" to "970422", "acb" to "970416",
        "sacombank" to "970403", "tpbank" to "970423", "vpbank" to "970432", "hdbank" to "970437", "eximbank" to "970431",
        "seabank" to "970440", "lpbank" to "970449")
    private val BANK_RE = Regex("(" + BANKS.keys.joinToString("|") { Regex.escape(it) } + ")[^0-9]{0,15}((?:\\d[ .-]?){8,19})")

    /** Danh sách (số tài khoản, bin) tìm thấy; bin rỗng nếu không thấy tên ngân hàng đi kèm. */
    fun extract(text: String): List<Pair<String, String>> {
        val t = ScamDetector.norm(text.take(2000))
        val out = LinkedHashSet<Pair<String, String>>()
        BANK_RE.findAll(t).forEach { m -> val a = digits(m.groupValues[2]); if (a.length in 8..19) out += a to (BANKS[m.groupValues[1]] ?: "") }
        KW.findAll(t).forEach { m -> val a = digits(m.groupValues[1]); if (a.length in 8..19 && out.none { it.first == a }) out += a to "" }
        return out.toList()
    }

    /** Dòng cảnh báo nếu văn bản chứa số tài khoản nằm trong danh sách; ngược lại null. */
    fun checkText(text: String): String? {
        val c = appCtx ?: return null
        if (entries(c).isEmpty()) return null
        val hit = extract(text).firstOrNull { isListed(c, it.first, it.second) } ?: return null
        return "Số tài khoản ${mask(hit.first)} nằm trong danh sách lừa đảo"
    }

    // ───────── Máy chủ ─────────

    /** Tải các số đã xác minh từ máy chủ (cần đăng nhập). */
    fun sync(c: Context, onMsg: (String) -> Unit) {
        onMsg("Đang tải…")
        Api.call(c, "GET", "/api/accounts", null) { code, j ->
            if (code == 200 && j != null) {
                val a = j.optJSONArray("accounts") ?: JSONArray()
                var n = 0
                for (i in 0 until a.length()) {
                    val o = a.optJSONObject(i) ?: continue
                    if (add(c, o.optString("n"), o.optString("b"))) n++
                }
                onMsg("Đã cập nhật $n số tài khoản lừa đảo từ cộng đồng")
            } else onMsg(err(j))
        }
    }

    /** cb(mã HTTP, JSON {verified, reports}). */
    fun check(c: Context, acct: String, bin: String, cb: (Int, JSONObject?) -> Unit) =
        Api.call(c, "GET", "/api/accounts/check?number=${digits(acct)}&bank=$bin", null, cb)

    fun report(c: Context, acct: String, bin: String, cb: (Int, JSONObject?) -> Unit) =
        Api.call(c, "POST", "/api/accounts/report", JSONObject().put("number", digits(acct)).put("bank", bin), cb)
}
