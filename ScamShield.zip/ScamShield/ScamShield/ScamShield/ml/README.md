# Mô hình học máy TFLite của ScamShield

App có mô hình `app/src/main/assets/scam_text.tflite` (hồi quy logistic trên đặc trưng băm n-gram, 4096 chiều).
`TextModel.kt` nạp file này bằng TensorFlow Lite; `ScamDetector.analyze` cộng thêm điểm khi mô hình tin đó là lừa đảo.
Không có file hoặc nạp lỗi thì app tự chạy bằng bộ quy tắc như cũ (không crash).

- `build_starter_model.py` – tạo mô hình khởi động, không cần TensorFlow (đã chạy sẵn, kết quả nằm trong assets).
- `train_tflite.py` – huấn luyện bằng Keras với dữ liệu thật của bạn (CSV: content,label) và xuất model .tflite.
- `features.py` – cách biến chữ thành vector. PHẢI khớp `TextModel.kt`; sửa một bên thì sửa cả hai.
- `seed_data.py` – dữ liệu TỔNG HỢP để chạy thử, không dùng để báo cáo độ chính xác.


## Model bên ngoài APK (ưu tiên)

Từ phiên bản này, `TextModel.kt` ưu tiên model ở:

`<Android/data>/vn.scamshield/files/models/scam_text.tflite`

Nếu không có model bên ngoài hoặc model ngoài bị lỗi, app tự động dùng `app/src/main/assets/scam_text.tflite` làm model dự phòng.

### Huấn luyện lại mà không build lại APK

Trên máy tính:

```bash
python train_tflite.py --csv du_lieu_moi.csv --epochs 40
```

Model mới mặc định được tạo tại `ml/exports/scam_text.tflite`. Sau đó chép nó vào:

```text
Android/data/vn.scamshield/files/models/scam_text.tflite
```

Có thể thay file khi app đã cài. Nếu app đang mở, lần phân tích kế tiếp sẽ phát hiện file thay đổi và tự nạp lại model. Không cần build lại APK cho mỗi lần huấn luyện.

Lưu ý: thư mục `Android/data` có thể bị một số trình quản lý file Android hạn chế truy cập. Khi đó có thể dùng Android Studio Device Explorer hoặc ADB để chép file.
