package vn.scamshield
import java.text.Normalizer

/**
 * corroborated: có đủ dấu hiệu KHỚP NHAU hay chưa. Một từ khóa đơn lẻ ("hoa hồng", "trúng thưởng", "mật khẩu"...) rất hay gặp trong tin nhắn
 * bình thường nên KHÔNG đủ để cảnh báo; cần ít nhất 2 quy tắc, trong đó có một quy tắc mạnh (từ 25 điểm) và thuộc 2 giai đoạn khác nhau
 * của thủ đoạn. Không dùng tổng điểm để thay thế bằng chứng độc lập. Ngoại lệ: số tài khoản / tên miền trong danh sách lừa đảo, và quy tắc rất đặc trưng.
 * solid: bằng chứng chắc (từ 2 quy tắc mạnh, hoặc từ 4 quy tắc); chỉ khi đó mới lên mức "nguy hiểm".
 * Các Result do nơi khác dựng sẵn (mã QR...) mặc định corroborated = solid = true, chỉ xét theo điểm như trước.
 */
data class Result(val score: Int, val reasons: List<String>, val corroborated: Boolean = true, val solid: Boolean = true) {
    /** 0 = an toàn, 1 = đáng ngờ, 2 = nguy hiểm. */
    val level get() = levelIn(false)
    /** Trong nhóm chat, ngưỡng cao hơn 10 điểm vì tin nhắn nhóm đa dạng và dễ bị báo nhầm hơn. */
    fun levelIn(group: Boolean): Int {
        if (!corroborated) return 0
        val d = if (group) 10 else 0
        return when { score >= 50 + d && solid -> 2; score >= 25 + d -> 1; else -> 0 }
    }
    /** Ngưỡng báo sớm cho cuộc gọi trực tiếp: vàng từ 10, đỏ từ 30 (vẫn cần corroborated) */
    val live get() = if (!corroborated) 0 else when { score >= 30 && solid -> 2; score >= 10 -> 1; else -> 0 }
}

object ScamDetector {
    // Regex chuẩn hóa — compile một lần, tránh tạo object mới mỗi lần gọi norm()
    private val MN_RE = Regex("\\p{Mn}+")

    fun norm(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        .replace(MN_RE, "").replace('đ', 'd')

    /**
     * Một quy tắc: biểu thức (viết trên văn bản đã bỏ dấu), điểm, nhãn hiển thị, giai đoạn của thủ đoạn:
     * X chuyển sang kênh khác, L dụ dỗ, M đòi tiền/thông tin, P đe dọa/ép thời gian, N khác.
     * Giai đoạn dùng cho ThreadGuard để nhận ra thủ đoạn diễn ra qua nhiều tin nhắn, nhiều ngày.
     */
    private class Rule(val re: Regex, val pts: Int, val label: String, val stage: Char)

    private val rules = listOf(
        Rule(Regex("""cong an|vien kiem sat|toa an|co quan dieu tra|bo cong an|lenh bat|trieu tap"""), 40, "Giả danh cơ quan chức năng", 'P'),
        Rule(Regex("""tai khoan.{0,40}(se bi khoa|bi khoa|se dong|bi dong|dong bang|tam ngung|bi han che)|(se bi khoa|se dong|dong bang).{0,30}tai khoan"""), 30, "Dọa khóa/đóng băng tài khoản", 'P'),
        // Không đánh dấu chỉ vì SMS chứa OTP (nhiều ngân hàng gửi OTP hợp pháp).
        // Chỉ khớp khi người gửi yêu cầu người nhận cung cấp/đọc/nhập mã hoặc thông tin thẻ.
        Rule(Regex("""(yeu cau|vui long|hay|doc|gui|cung cap|nhap|cho biet).{0,28}(otp|ma xac thuc|ma xac minh|mat khau|cvv|so the)|(otp|ma xac thuc|ma xac minh|cvv).{0,24}(cho chung toi|cho nhan vien|qua dien thoai|gui lai|doc lai|cung cap)"""), 35, "Yêu cầu cung cấp OTP / thông tin nhạy cảm", 'M'),
        Rule(Regex("""trung thuong|trung giai|nhan qua|qua tang|voucher mien phi"""), 35, "Lừa trúng thưởng", 'L'),
        Rule(Regex("""viec nhe luong cao|lam nhiem vu|cong tac vien|hoa hong|chot don|tang don|tha tim|like video"""), 40, "Lừa tuyển việc làm online / nhiệm vụ", 'L'),
        Rule(Regex("""dau tu|loi nhuan|sinh loi|usdt|crypto|cam ket lai|forex"""), 30, "Lừa đầu tư sinh lời", 'L'),
        Rule(Regex("""giai ngan|duyet vay|vay nhanh|lai suat 0|phi ho so"""), 25, "Lừa vay tiền / thu phí trước", 'L'),
        Rule(Regex("""vneid|dich vu cong|bhxh|tien dien|cuoc vien thong|cuc thue|bien ban phat"""), 20, "Giả mạo dịch vụ công / tiện ích", 'N'),
        Rule(Regex("""trong 24 gio.{0,30}(khoa|phat|xu ly)|neu khong.{0,30}(khoa|phat|bat|truy cuu)|ngay lap tuc.{0,25}(chuyen|nop|xac minh)"""), 15, "Tạo áp lực để buộc thực hiện hành động", 'P'),
        Rule(Regex("""(yeu cau|hay|vui long|can).{0,25}(chuyen tien|chuyen khoan|nap tien|dong phi)|(chuyen tien|chuyen khoan).{0,20}(ngay|gap|vao tai khoan)"""), 20, "Yêu cầu chuyển tiền", 'M'),
        Rule(Regex("""zalo\.me|t\.me/|telegram|lien he zalo|them zalo"""), 15, "Dẫn sang Zalo/Telegram", 'X'),
        Rule(Regex("""bit\.ly|tinyurl|cutt\.ly|rebrand\.ly|\.xyz|\.top|\.vip|\.club|\.icu|\.cc\b|http://"""), 30, "Link rút gọn / tên miền đáng ngờ", 'N'),
        Rule(Regex("""tai khoan an toan|phong toa|xac minh danh tinh|rua tien|duong day|vu an|dieu tra|ma so thue|can cuoc|cccd"""), 35, "Dọa liên quan vụ án / yêu cầu xác minh danh tính", 'P'),
        Rule(Regex("""(cong an|vien kiem sat|toa an|co quan dieu tra|bo cong an).{0,100}(tai khoan an toan|chuyen tien|dong phi|cung cap cccd|doc otp|gui otp)"""), 50, "Giả danh cơ quan chức năng để đòi tiền / thông tin", 'M'),
        Rule(Regex("""sim.*(bi khoa|het han)|thue bao.*(khoa|ngung)"""), 30, "Dọa khóa SIM", 'P'),
        Rule(Regex("""anydesk|ultraviewer|teamviewer|chia se man hinh|cai ung dung|tai ung dung|cai dat app"""), 35, "Yêu cầu cài app / chia sẻ màn hình", 'M'),
        Rule(Regex("""buu dien|buu cuc|giao hang|don hang|\bhoan tien|\bhoan phi|shipper"""), 20, "Giả giao hàng / hoàn tiền", 'L'),
        Rule(Regex("""https?://|www\."""), 10, "Chứa đường link", 'N'),
        Rule(Regex("""(nhan|bam|truy cap|mo).{0,20}(link|duong dan).{0,35}(dang nhap|xac minh|nhap otp|nhap mat khau)|(dang nhap|xac minh|nhap otp|nhap mat khau).{0,30}(link|duong dan)"""), 30, "Dẫn link để đăng nhập / xác minh thông tin", 'M'),
        Rule(Regex("""(voucher|qua tang|trung thuong|nhan qua).{0,100}(\.xyz|\.top|\.vip|bit\.ly|tinyurl|http)|(\.xyz|\.top|\.vip).{0,80}(voucher|qua tang|trung thuong)"""), 35, "Dùng quà tặng / voucher để dụ truy cập tên miền lạ", 'M'),
        Rule(Regex("""xac minh.{0,30}(otp|ma xac thuc).{0,50}(\.top|\.xyz|\.vip|http)|tai khoan.{0,60}(dang nhap bat thuong|hoat dong bat thuong).{0,60}(\.top|\.xyz|\.vip)"""), 35, "Yêu cầu xác minh tài khoản qua tên miền lạ", 'M'),
        Rule(Regex("""(phat nguoi|bien ban phat).{0,100}(nop phat|thanh toan|\.top|\.xyz|http)|(nop phat|thanh toan).{0,60}(phat nguoi|bien ban phat)"""), 35, "Giả mạo phạt nguội / yêu cầu nộp phạt qua link", 'M'),
        Rule(Regex("""nhan vao day.{0,50}(xac minh|gui don|khieu nai|dang nhap)|vi pham (ban quyen|chinh sach).{0,80}(xoa|khoa|xac minh)"""), 30, "Dọa khóa tài khoản mạng xã hội để dụ xác minh", 'M'),
        Rule(Regex("""chuyen.{0,25}(vao|den).{0,20}(stk|tai khoan|so tai khoan)|chuyen tien.{0,25}(vao|den)"""), 30, "Yêu cầu chuyển tiền vào tài khoản", 'M'),
        Rule(Regex("""chuyen khoan truoc|thanh toan truoc|coc truoc|\bck truoc|ung truoc|dat coc|tien coc|coc (30|40|50)"""), 30, "Đòi đặt cọc / thanh toán trước khi nhận hàng, dịch vụ", 'M'),
        Rule(Regex("""cam ket (dau|thanh cong|hoan|khong dau)|(dau|thanh cong) 100 ?%|\bhoan (lai )?100 ?%|bao dau|khong dau (hoan|tra) (lai )?tien"""), 30, "Cam kết quá chắc chắn (đậu 100%, hoàn tiền 100%)", 'L'),
        Rule(Regex("""da (chuyen|ck|thanh toan) (khoan )?(roi|xong|thanh cong)|(gui|xem) (bill|bien lai|hoa don)|(bill|bien lai).{0,20}(chuyen|ck)|ngan hang (xu ly cham|dang xu ly|treo|bao tri)|tien (se )?(ve|vao) (sau|cham)|(giao|gui|ship) hang (di|truoc)"""), 30, "Nói đã chuyển tiền / gửi bill rồi giục giao hàng (bill có thể giả)", 'M'),
        Rule(Regex("""cap cuu|nguy kich|phau thuat|vien phi"""), 30, "Báo người thân cấp cứu / cần viện phí gấp", 'P'),
        Rule(Regex("""(cap cuu|nguy kich|tai nan|phau thuat|nhap vien).{0,80}(chuyen tien|gui tien|vien phi|tai khoan|stk)|(chuyen tien|gui tien).{0,40}(cap cuu|phau thuat|tai nan)"""), 35, "Dùng tình huống khẩn cấp để yêu cầu chuyển tiền", 'M'),
        Rule(Regex("""tai nan|nhap vien"""), 15, "Nhắc tai nạn / nhập viện", 'P'),
        Rule(Regex("""(giao vien|co giao|thay giao|y ta|bac si|benh vien|nhan vien y te).{0,60}(con (ban|em|chi|anh)|nguoi than|me ban|bo ban|vo ban|chong ban)"""), 20, "Giả danh giáo viên / y tế nói người thân gặp chuyện", 'P'),
        Rule(Regex("""(doi|dung|co) so (moi|khac)|so moi (cua|nay)|luu (lai )?so (moi|nay)|(toi|anh|chi|em|me|bo|sep) (la|day).{0,15}so moi"""), 30, "Báo 'đổi số mới' (giả danh người quen / sếp)", 'P'),
        Rule(Regex("""(cho|can|xin) (em |minh |toi |tui |anh |chi )?(muon|vay|nho).{0,20}(tien|\d+ ?(tr|k|trieu|nghin))|(chuyen|ck|nap|mua) (giup|ho|dum|gium)|(chuyen|nap|mua).{0,12}the (cao|dien thoai)|vay (tam|gap)|(muon|vay) gap|tra (lai )?(sau|ngay mai|cuoi tuan|cuoi thang)"""), 35, "Nhờ chuyển tiền / mua thẻ / mượn tiền gấp (nghi bị chiếm tài khoản)", 'M'),
        Rule(Regex("""\bvote\b|binh chon|ban (co )?(trong|thay).{0,10}(anh|clip|video)|xem (anh|video|clip) (nay|cua ban)|boc phot|bi lo (anh|clip)|ban la ai|(anh|clip|video) cua ban"""), 25, "Mồi 'bình chọn / ảnh / clip' kèm link (phishing mạng xã hội)", 'L'),
        Rule(Regex("""mau nhi|tuyen (nguoi )?mau|thu thach|chup anh (quang cao|san pham)|ung tuyen.{0,15}(mau|be)|quang ba san pham"""), 35, "Tuyển người mẫu / 'thử thách' mua hàng", 'L'),
        Rule(Regex("""(mua san pham|chuyen khoan mua).{0,60}(\bhoan|goc|hoa hong)|(\bhoan (lai )?(tien|goc)|nhan (lai )?goc|goc (va|\+) (loi|hoa hong)).{0,60}hoa hong|hoa hong (tung|moi) don"""), 30, "Bỏ tiền mua hàng rồi được 'hoàn tiền kèm hoa hồng'", 'M'),
        Rule(Regex("""vay (tin chap|von|nhanh|tien)|khoan vay|ho tro vay|khong (can )?(the chap|chung minh)|lai suat (thap|uu dai)"""), 20, "Quảng cáo vay tiền", 'L'),
        Rule(Regex("""phi (bao hiem|bao lanh|xac minh|duyet|giai ngan|kich hoat|mo khoa)|nop them|loi he thong|sai ten (nguoi )?huong|dong bang khoan vay|ho so (bi )?(loi|sai)"""), 35, "Đòi nộp thêm 'phí' để giải ngân / sửa lỗi / rút tiền", 'M'),
        Rule(Regex("""(gui|chup|cung cap) .{0,12}(anh|hinh).{0,20}(cccd|can cuoc|cmnd|chan dung|giay to)|anh (cccd|can cuoc|cmnd)|chan dung.{0,10}cccd"""), 30, "Xin ảnh giấy tờ cá nhân (CCCD / chân dung)", 'M'),
        Rule(Regex("""\d+ ?%.{0,12}(thang|ngay|tuan|nam)|\d+ ?%/ ?(thang|ngay|tuan)|lai (suat )?\d+ ?%"""), 30, "Hứa lãi suất / lợi nhuận cao bất thường", 'L'),
        Rule(Regex("""san (giao dich|forex|crypto|vang|chung khoan)|nen tang dau tu|nhom dau tu|chuyen gia (dau tu|phan tich|tai chinh)|tin hieu (mua|ban)|ky quy|von toi thieu|da cap|hoi (thao|nghi) dau tu|chung khoan quoc te"""), 30, "Sàn / nhóm đầu tư, ký quỹ, đa cấp", 'L'),
        Rule(Regex("""khong rut (duoc|tien)|(dong|nop) (phi|thue).{0,25}(de )?(rut|nhan)|(phai|can|moi).{0,15}(dong|nop).{0,15}(phi|thue)|xac minh.{0,10}(de )?rut"""), 40, "Đòi phí / thuế mới cho rút tiền (dấu hiệu sàn lừa)", 'M'),
        Rule(Regex("""\bctv\b|lam (tai nha|online)|kiem them thu nhap|viec lam (online|tai nha)|nhiem vu (hang ngay|tren app)|nhan (don|nhiem vu)|danh gia 5 sao|tang (luot|tuong tac)|\d+ ?(k|tr|trieu)/ ?(ngay|gio|thang)"""), 25, "Việc làm online / nhận nhiệm vụ lấy hoa hồng", 'L'),
        Rule(Regex("""\bung (tien|truoc|von)|nap (tien|them) .{0,12}(nhan|lam|mo)|don (hang )?(gia tri cao|vip|lien hoan|dac biet|ket hop)|ket hop don|don lien hoan"""), 40, "Bắt ứng tiền / nạp thêm để làm nhiệm vụ", 'M'),
        Rule(Regex("""nap.{0,30}(von|lam nhiem vu|nhan viec)|bot tu dong.{0,35}(sinh loi|tao loi nhuan)|nap (500|1\.000|2\.000) ?k.{0,40}(von|tham gia)"""), 35, "Yêu cầu nạp vốn để nhận việc / đầu tư", 'M'),
        Rule(Regex("""chuyen nham|nham (tai khoan|so)|vo (tinh|y) chuyen|(tra|hoan) (lai )?(so )?tien (da )?(nham|chuyen)|hoan tra (so )?tien"""), 35, "Nói chuyển nhầm tiền, đòi hoàn trả", 'M'),
        Rule(Regex("""thu hoi no|doi no|no qua han|nhac no|lai (cat co|\d+ ?%/ ?ngay)|truy (thu|no)|khoan vay (cua ban|da (nhan|giai))"""), 35, "Dọa đòi nợ / khoản vay không có thật", 'P'),
        Rule(Regex("""lay lai (tien|facebook|fb|tai khoan)|thu hoi (tien|tai khoan)|ho tro lay lai|mo khoa (facebook|fb|tai khoan)|khoi phuc (tai khoan|facebook)|luat su ho tro|dich vu thu hoi|hoan lai so tien da (mat|bi lua)"""), 35, "Dịch vụ 'lấy lại tiền / tài khoản' (hay là lừa lần hai)", 'L'),
        Rule(Regex("""(xin|gui|doc|nhap|cho) (lai )?(toi |minh |em |anh |chi )?(ma|code)\b|ma (dang nhap|xac nhan|bao mat)|ma \d ?so|login code|code (dang nhap|telegram)"""), 35, "Xin / nhờ đọc mã xác nhận", 'M'),
        Rule(Regex("""(ky su|bac si|si quan|linh|doanh nhan|nguoi (my|anh|duc|nhat|han)).{0,30}(nuoc ngoai|\bmy\b|syria|\buc\b|dubai|singapore|canada|anh quoc)|dinh cu|(sang|ve) viet nam (gap|dinh|thang)"""), 30, "Làm quen người nước ngoài / hứa gặp (lừa tình cảm)", 'L'),
        Rule(Regex("""hai quan|thue (hai quan|nhap khau)|phi (van chuyen|thong quan|luu kho)|tam giu|buu kien.{0,30}(phi|thue)"""), 40, "Đòi phí hải quan / thuế để nhận bưu kiện, quà", 'M'),
        Rule(Regex("""gui (anh|hinh|video) (nong|nhay cam|rieng tu)|phat tan (anh|clip|video)|bi lo (anh|clip)"""), 40, "Đe dọa phát tán ảnh / clip, tống tiền", 'P'),
        Rule(Regex("""(so|con|dan) (de|lo|dep)\b|lo de|bao lo|song thu|bach thu|chot so|cau (lo|de)|nuoi (lo|khung)|\bxien \d|soi cau"""), 35, "Chào bán số đề / soi cầu", 'L'),
        Rule(Regex("""phi (cau|soi|dang ky|tu van|may man|tien tri)|chia (hoa hong|lai|thuong|\d+ ?%)"""), 30, "Đòi phí / chia hoa hồng khi trúng", 'M'),
        Rule(Regex("""flash ?ai|nghe may.{0,25}(mat|tru|hut) tien|(nhan|nghe) cuoc goi.{0,20}(mat|tru|hut) tien|dung (nghe|bat) may|chuyen tiep (cho )?(moi|nguoi than)|chia se (gap|ngay) cho"""), 25, "Tin đồn 'nghe máy bị mất tiền' (tin giả, đừng chia sẻ)", 'N'),
        // ── Quy tắc bổ sung (2024-2025) ──
        Rule(Regex("""ma qr.{0,20}(chuyen|nhan|thanh toan)|quet ma qr.{0,20}(ngay|gap|de nhan)|qr code.{0,20}(tien|thuong|qua)"""), 35, "QR code giả / lừa quét mã QR để nhận tiền", 'M'),
        Rule(Regex("""airdrop|claim (token|coin|nft)|mint (nft|token)|connect wallet|metamask|phantom wallet|approve token|ky xac nhan vi"""), 40, "Lừa đảo crypto airdrop / ký ví / approve token", 'M'),
        Rule(Regex("""ho tro ky thuat|microsoft support|apple support|google support|windows (bi|phat hien) (virus|malware|hack)|may tinh bi nhiem"""), 35, "Giả mạo hỗ trợ kỹ thuật Microsoft/Apple", 'P'),
        Rule(Regex("""(giong|giong noi|cuoc goi) (cua )?(sep|giam doc|truong phong|giam doc dieu hanh)|sep (nho|can|yeu cau).{0,30}(chuyen|ck|mua)"""), 40, "Deepfake giọng sếp / lãnh đạo nhờ chuyển tiền", 'P'),
        Rule(Regex("""shopee.{0,20}(tra hang|hoan tien|khieu nai)|lazada.{0,20}(hoan|tra)|tiki.{0,20}(hoan|khieu)|san tmdt.{0,20}(bao mat|xac minh)|don hang.{0,15}(bi giu|tam giu|khoa)"""), 30, "Giả nhân viên sàn TMĐT (Shopee/Lazada/Tiki)", 'P'),
        Rule(Regex("""nap the nhanh|the cao (200|500|1000|2000)k|mua the thanh toan|the itunes|the google play|the garena"""), 35, "Yêu cầu nạp/mua thẻ cào gấp", 'M'),
        Rule(Regex("""(phan mem|app) (bao mat|chong lua dao|chinh thuc)|tai (ngay|ngay bay gio).{0,20}(an toan|bao mat)|link (tai|download).{0,15}(chinh thuc|bao mat)"""), 30, "Giả app / phần mềm bảo mật chính thức", 'N'),
        // Tiếng Anh phổ biến qua Telegram
        Rule(Regex("""verify.{0,15}(account|wallet|identity)|your account.{0,15}(suspended|blocked|limited)|confirm.{0,10}(otp|pin|password)"""), 30, "Phishing tiếng Anh (xác minh tài khoản)", 'M'),
        Rule(Regex("""investment (opportunity|platform|group)|guaranteed (profit|return)|double your|passive income|financial (advisor|manager)"""), 30, "Lừa đầu tư tiếng Anh", 'L'),
        Rule(Regex("""you (won|have been selected|are the winner)|claim your (prize|reward|gift)|click.{0,15}link.{0,20}(claim|receive)"""), 30, "Lừa trúng thưởng tiếng Anh", 'L'),
    )

    /** Quy tắc đủ đặc trưng để tự cảnh báo dù chỉ khớp một mình. */
    private val SOLO = setOf("Đòi phí / thuế mới cho rút tiền (dấu hiệu sàn lừa)")

    private val stageByLabel = rules.associate { it.label to it.stage }
    fun stageOf(label: String): Char = stageByLabel[label] ?: 'N'

    /** Các quy tắc khớp với văn bản: (nhãn, điểm). Không gồm mô hình TFLite, danh sách số tài khoản hay tên miền. */
    fun hits(text: String): List<Pair<String, Int>> {
        val t = norm(text)
        // Nội dung cảnh báo/phổ biến kiến thức chống lừa đảo thường trích lại từ khóa nguy hiểm.
        // Không coi các câu phủ định rõ ràng là yêu cầu thực hiện hành động.
        val educationalWarning = listOf(
            "canh bao lua dao", "phong tranh lua dao", "ngan hang khong bao gio yeu cau",
            "khong bao gio cung cap otp", "khong cung cap otp", "khong chia se otp",
            "tuyet doi khong chia se ma xac thuc", "tuyet doi khong cung cap ma otp"
        ).any { it in t }
        if (educationalWarning) return emptyList()
        return rules.filter { it.re.containsMatchIn(t) }.map { it.label to it.pts }
    }

    /**
     * Dựng Result từ các quy tắc khớp, áp dụng điều kiện "nhiều dấu hiệu khớp nhau" để giảm báo nhầm (xem Result).
     * extra*: điểm và lý do từ nguồn khác (TFLite, danh sách số tài khoản / tên miền).
     */
    fun fromHits(hs: List<Pair<String, Int>>, extraScore: Int = 0, extraReasons: List<String> = emptyList(),
                 extraStrong: Int = 0, listed: Boolean = false): Result {
        var score = extraScore
        val why = ArrayList<String>()
        var strong = extraStrong
        var n = extraReasons.size
        val st = HashSet<Char>()
        var solo = false
        for ((label, pts) in hs) {
            score += pts; why += label; n++
            if (pts >= 25) strong++
            val g = stageByLabel[label] ?: 'N'
            if (g != 'N') st += g
            if (label in SOLO) solo = true
        }
        why += extraReasons
        val corroborated = listed || solo || (n >= 2 && strong >= 1 && (st.size >= 2 || (score >= 60 && strong >= 2)))
        val solid = listed || strong >= 2 || n >= 4
        return Result(score.coerceAtMost(100), why, corroborated, solid)
    }

    fun analyze(text: String): Result {
        var extra = 0
        var strong = 0
        val ex = ArrayList<String>()
        // ML là tín hiệu hỗ trợ, không được tự mình kích hoạt cảnh báo.
        // Ngưỡng cao hơn giúp tránh để model khởi tạo từ dữ liệu tổng hợp lấn át bộ quy tắc.
        val p = TextModel.predict(text)
        if (p != null && p >= 0.85f) {
            extra += (((p - 0.85f) / 0.15f) * 20f).toInt().coerceIn(0, 20)
            ex += "Mô hình học máy hỗ trợ: ${(p * 100).toInt()}%"
            if (p >= 0.92f) strong++
        }
        val acct = AccountGuard.checkText(text)     // số tài khoản nằm trong danh sách lừa đảo
        val dom = DomainGuard.checkText(text)       // link tới tên miền lừa đảo
        acct?.let { extra += 90; ex += it }
        dom?.let { extra += 85; ex += it }
        return fromHits(hits(text), extra, ex, strong, listed = acct != null || dom != null)
    }
}
