package vn.scamshield

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import org.tensorflow.lite.Interpreter

/**
 * Tự động kiểm tra model mới trên máy chủ.
 * Máy chủ cần cung cấp:
 *   GET /api/model/manifest -> {"version":"7"}
 *   GET /api/model/scam_text.tflite -> file nhị phân TFLite
 *
 * Model mới được tải về file tạm, kiểm tra bằng Interpreter rồi mới thay model đang dùng.
 */
object ModelUpdater {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile var status: String = "Chưa kiểm tra cập nhật"
        private set

    fun check(c: Context, force: Boolean = false, cb: ((Boolean, String) -> Unit)? = null) {
        val ctx = c.applicationContext
        executor.execute {
            var changed = false
            var message = "Đã kiểm tra: model đã mới nhất"
            try {
                val base = Api.server(ctx)
                if (!base.startsWith("https://")) throw Exception("Máy chủ model phải dùng HTTPS")
                val manifest = getJson("$base/api/model/manifest")
                val remoteVersion = manifest.optString("version").trim()
                if (remoteVersion.isEmpty()) throw Exception("manifest thiếu version")
                val localVersion = TextModel.externalModelVersion()
                val shouldDownload = force || localVersion.isEmpty() || compareVersions(remoteVersion, localVersion) > 0
                if (shouldDownload) {
                    val target = TextModel.externalModelFile() ?: throw Exception("Không tạo được thư mục model")
                    val tmp = File(target.parentFile, target.name + ".download")
                    download("$base/api/model/scam_text.tflite", tmp)
                    validate(tmp)
                    if (target.exists()) target.delete()
                    if (!tmp.renameTo(target)) {
                        tmp.copyTo(target, overwrite = true)
                        tmp.delete()
                    }
                    TextModel.setExternalModelVersion(remoteVersion)
                    changed = true
                    message = "Đã cập nhật model AI lên v$remoteVersion"
                }
                status = message
            } catch (e: Exception) {
                message = "Không cập nhật được model: ${e.message ?: "lỗi kết nối"}"
                status = message
            }
            main.post { cb?.invoke(changed, message) }
        }
    }

    private fun getJson(url: String): JSONObject {
        val con = open(url, 20_000)
        val code = con.responseCode
        val body = (if (code in 200..299) con.inputStream else con.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        con.disconnect()
        if (code !in 200..299) throw Exception("HTTP $code")
        return JSONObject(body)
    }

    private fun download(url: String, out: File) {
        out.parentFile?.mkdirs()
        val con = open(url, 60_000)
        try {
            val code = con.responseCode
            if (code !in 200..299) throw Exception("HTTP $code")
            con.inputStream.use { input -> out.outputStream().use { output -> input.copyTo(output) } }
            if (out.length() <= 0) throw Exception("file model rỗng")
        } finally { con.disconnect() }
    }

    private fun open(url: String, timeout: Int): HttpURLConnection {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = "GET"
        con.connectTimeout = 10_000
        con.readTimeout = timeout
        con.setRequestProperty("ngrok-skip-browser-warning", "1")
        con.setRequestProperty("User-Agent", "ScamShieldVN-App/1.0")
        return con
    }

    private fun validate(file: File) {
        val bytes = file.readBytes()
        val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        buf.put(bytes); buf.rewind()
        val test = Interpreter(buf, Interpreter.Options().setNumThreads(2))
        test.close()
    }

    private fun compareVersions(a: String, b: String): Int {
        val aa = a.split('.', '-', '_')
        val bb = b.split('.', '-', '_')
        for (i in 0 until maxOf(aa.size, bb.size)) {
            val x = aa.getOrNull(i)?.toLongOrNull() ?: 0L
            val y = bb.getOrNull(i)?.toLongOrNull() ?: 0L
            if (x != y) return x.compareTo(y)
            if (aa.getOrNull(i) != null && bb.getOrNull(i) != null && aa[i] != bb[i]) return aa[i].compareTo(bb[i])
        }
        return 0
    }
}
