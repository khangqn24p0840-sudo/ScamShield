package vn.scamshield

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

/**
 * Theo dõi hội thoại qua NHIỀU NGÀY, hoàn toàn trong máy.
 *
 * Mỗi nguồn tin (một người gửi SMS, một người/nhóm trên Zalo, Messenger, Telegram…) có một "hồ sơ" gồm: số tin, số ngày có tin,
 * và các loại dấu hiệu lừa đảo đã xuất hiện (nhãn + điểm). KHÔNG lưu nội dung tin nhắn.
 * Điểm cộng dồn dần: một tin riêng lẻ có thể chưa đáng ngờ, nhưng chuỗi "làm quen → dụ dỗ → chuyển kênh → đòi tiền" kéo dài nhiều ngày
 * thì tổng điểm vượt ngưỡng và app cảnh báo, kể cả khi tin cuối cùng nghe vẫn bình thường.
 */
object ThreadGuard {
    private const val KEY = "threads"
    private const val OFF = "thread_off"
    private const val MAX_THREADS = 150
    private const val DAY = 86_400_000L
    private const val EXPIRE_MS = 45L * DAY
    private const val LISTED = "Số tài khoản / tên miền nằm trong danh sách lừa đảo"

    // In-memory cache: tránh parse JSON mỗi tin nhắn đến
    private var cachedList: MutableList<Th>? = null
    private var cacheContext: String = ""   // dùng packageName làm key để detect context change
    private var dirty = false               // chỉ save khi thực sự có thay đổi

    class Th(val key: String, var name: String, var app: String, var first: Long, var last: Long, var n: Int,
             val days: MutableList<Long>, val sig: MutableMap<String, Int>, var lv: Int, val hashes: MutableList<Int>)

    fun enabled(c: Context) = !Store.flag(c, OFF)
    fun setEnabled(c: Context, on: Boolean) = Store.putFlag(c, OFF, !on)

    private fun loadFresh(c: Context): MutableList<Th> {
        val out = ArrayList<Th>()
        try {
            val a = JSONArray(Store.str(c, KEY).ifEmpty { "[]" })
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val days = ArrayList<Long>()
                o.optJSONArray("d")?.let { for (j in 0 until it.length()) days.add(it.getLong(j)) }
                val sig = LinkedHashMap<String, Int>()
                o.optJSONObject("s")?.let { s -> for (k in s.keys()) sig[k] = s.optInt(k) }
                val hs = ArrayList<Int>()
                o.optJSONArray("h")?.let { for (j in 0 until it.length()) hs.add(it.getInt(j)) }
                out.add(Th(o.getString("k"), o.optString("nm"), o.optString("ap"), o.optLong("f"), o.optLong("l"), o.optInt("n"),
                    days, sig, o.optInt("lv"), hs))
            }
        } catch (_: Exception) { }
        return out
    }

    /** Load với cache: tránh parse JSON mỗi lần onMessage() được gọi. */
    private fun load(c: Context): MutableList<Th> {
        val pkg = c.packageName
        var list = cachedList
        if (list == null || cacheContext != pkg) {
            list = loadFresh(c)
            cachedList = list
            cacheContext = pkg
            dirty = false
        }
        return list
    }

    /** Invalidate cache (gọi sau khi remove/clear để UI đọc lại). */
    private fun invalidate() { cachedList = null }

    private fun save(c: Context, list: List<Th>) {
        if (!dirty) return  // không save nếu không có thay đổi
        val a = JSONArray()
        for (t in list.sortedByDescending { it.last }.take(MAX_THREADS)) {
            val s = JSONObject(); for ((k, v) in t.sig) s.put(k, v)
            val d = JSONArray(); for (x in t.days) d.put(x)
            val h = JSONArray(); for (x in t.hashes) h.put(x)
            a.put(JSONObject().put("k", t.key).put("nm", t.name).put("ap", t.app).put("f", t.first).put("l", t.last)
                .put("n", t.n).put("d", d).put("s", s).put("lv", t.lv).put("h", h))
        }
        Store.putStr(c, KEY, a.toString())
        dirty = false
    }

    /** Điểm cộng dồn của một hồ sơ (0..100). */
    fun score(t: Th): Int {
        val strong = t.sig.values.any { it >= 25 }
        val st = t.sig.keys.map { ScamDetector.stageOf(it) }.toSet()
        var bonus = 0
        if (strong) {                                   // thời gian chỉ được cộng khi đã có ít nhất một dấu hiệu đủ mạnh
            bonus += minOf(3, maxOf(0, t.days.size - 1)) * 8
            if (t.n >= 10) bonus += 5
        }
        if ('L' in st && 'M' in st) bonus += 15         // dụ dỗ rồi đòi tiền
        if ('X' in st && ('L' in st || 'M' in st)) bonus += 10   // kéo sang kênh khác rồi dụ/đòi tiền
        if ('P' in st && 'M' in st) bonus += 10         // đe dọa/ép thời gian rồi đòi tiền
        return minOf(100, t.sig.values.sum() + bonus)
    }

    /** Hồ sơ chỉ được tính là đáng ngờ khi có bằng chứng nhiều mặt (xem bên dưới). Tránh báo nhầm khi bạn bè, người bán hàng, nhóm lớp chat bình thường nhiều ngày. */
    fun counts(t: Th): Boolean =
        // cần ít nhất 2 dấu hiệu MẠNH (từ 25 điểm) khác nhau, hoặc đã dính danh sách lừa đảo. Dấu hiệu yếu (chuyển khoản, giao hàng, link...) tích lại nhiều ngày vẫn không đủ.
        t.sig.values.count { it >= 25 } >= 2 || t.sig.containsKey(LISTED)

    fun levelOf(t: Th): Int = if (!counts(t)) 0 else Result(score(t), emptyList()).level

    fun spanDays(t: Th): Int = ((t.last - t.first) / DAY + 1).toInt()

    /**
     * Gọi với mỗi tin nhắn/thông báo đến. Trả về Result (kèm lý do) nếu hội thoại VỪA vượt lên một mức cảnh báo cao hơn mà
     * từng tin riêng lẻ chưa đủ để báo; ngược lại null.
     * app: "SMS" hoặc tên ứng dụng; sender: số điện thoại hoặc tên người/nhóm.
     */
    @Synchronized fun onMessage(c: Context, app: String, sender: String, body: String, msg: Result): Result? {
        if (!enabled(c) || sender.isBlank() || body.isBlank()) return null
        val key = app + "|" + ScamDetector.norm(sender).trim().take(60)
        val now = System.currentTimeMillis()
        val day = now / DAY
        // Dùng cache: không parse JSON lại nếu đã có; lọc expired trong bộ nhớ
        val list = load(c).also { it.removeAll { entry -> now - entry.last >= EXPIRE_MS } }
        val t = list.firstOrNull { it.key == key }   // HashMap thay linear scan nếu list lớn
            ?: Th(key, sender.take(60), app, now, now, 0, ArrayList(), LinkedHashMap(), 0, ArrayList()).also { list.add(it) }
        val h = ScamDetector.norm(body).hashCode()
        if (h in t.hashes) return null                  // thông báo bị đăng lại, không tính hai lần
        t.hashes.add(h); while (t.hashes.size > 8) t.hashes.removeAt(0)
        t.name = sender.take(60); t.last = now; t.n++
        if (day !in t.days) { t.days.add(day); while (t.days.size > 30) t.days.removeAt(0) }
        for ((label, pts) in ScamDetector.hits(body)) if (pts > (t.sig[label] ?: 0)) t.sig[label] = pts
        if (msg.reasons.any { it.startsWith("Số tài khoản") || it.startsWith("Link tới") }) t.sig[LISTED] = 60
        val lv = levelOf(t)
        val alert = lv > t.lv && lv > msg.level
        if (lv > t.lv) t.lv = lv
        dirty = true    // đánh dấu có thay đổi
        save(c, list)   // save() chỉ thực sự ghi khi dirty=true
        if (!alert) return null
        val why = ArrayList<String>()
        why += "Đã theo dõi ${spanDays(t)} ngày, ${t.n} tin nhắn từ \"${t.name}\""
        why.addAll(t.sig.entries.sortedByDescending { it.value }.take(4).map { it.key })
        return Result(score(t), why)
    }

    /** Hiện cảnh báo, ghi nhật ký và rung/hiện lớp phủ như các cảnh báo khác. */
    fun alert(c: Context, app: String, sender: String, r: Result) {
        val high = r.level == 2
        val title = (if (high) "🚨 Hội thoại có dấu hiệu LỪA ĐẢO" else "⚠️ Hội thoại đáng ngờ") + (if (app == "SMS") " qua tin nhắn" else " trên $app")
        Store.log(c, if (high) 2 else 1, "$title từ $sender", r.reasons.joinToString("; "))
        Notifier.show(c, title, "Từ $sender: " + r.reasons.joinToString("; ") + ". Dừng lại, đừng chuyển tiền hay đưa mã OTP, giấy tờ. Hãy gọi người thân hoặc ngân hàng bằng số bạn biết từ trước.")
        Alerter.fire(c, r.level)
    }

    fun all(c: Context): List<Th> = loadFresh(c).also { cachedList = it.toMutableList(); dirty = false }
        .sortedWith(compareByDescending<Th> { if (counts(it)) score(it) else 0 }.thenByDescending { it.last })
    fun remove(c: Context, key: String) { dirty = true; save(c, load(c).filter { it.key != key }); invalidate() }
    fun clear(c: Context) { Store.putStr(c, KEY, "[]"); invalidate() }
}

/** Màn hình xem các hội thoại đang được theo dõi. */
@Composable fun ThreadScreen(c: Context, back: () -> Unit) {
    var rev by remember { mutableIntStateOf(0) }
    var on by remember { mutableStateOf(ThreadGuard.enabled(c)) }
    val list = remember(rev) { ThreadGuard.all(c) }
    Page("Theo dõi hội thoại", back) {
        CardX {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconBadge(Icons.Rounded.Visibility, C.Cyan)
                Column(Modifier.weight(1f)) {
                    Text("Theo dõi nhiều ngày", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = C.Text)
                    Text(if (on) "Đang bật" else "Đang tắt", fontSize = 11.5.sp, color = C.Dim)
                }
                Switch(checked = on, onCheckedChange = { on = it; ThreadGuard.setEnabled(c, it) })
            }
            Text("App ghi nhớ trong máy mỗi người gửi: số tin, số ngày và loại dấu hiệu lừa đảo đã gặp (làm quen, dụ dỗ, chuyển sang Zalo/Telegram, đòi tiền…). " +
                "Điểm cộng dồn dần và app cảnh báo khi cả chuỗi hội thoại đáng ngờ, dù từng tin riêng lẻ nghe bình thường. " +
                "App KHÔNG lưu nội dung tin nhắn và không gửi dữ liệu này đi đâu. Hồ sơ không có tin mới sau 45 ngày sẽ tự xóa.",
                fontSize = 12.sp, color = C.Sub, lineHeight = 17.sp)
        }
        if (list.isEmpty()) Text("Chưa có hội thoại nào được theo dõi.", color = C.Dim, fontSize = 13.sp)
        list.take(40).forEach { t ->
            val counts = ThreadGuard.counts(t)
            val sc = if (counts) ThreadGuard.score(t) else 0
            val lv = Result(sc, emptyList()).level
            val col = listOf(C.Mint, C.Warn, C.Bad)[lv]
            CardX {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.name.ifEmpty { "(không rõ)" }, fontWeight = FontWeight.Bold, color = C.Text, fontSize = 15.sp, maxLines = 1)
                        Text("${t.app} · ${t.days.size} ngày có tin · ${t.n} tin", color = C.Dim, fontSize = 11.5.sp)
                    }
                    Text(listOf("Chưa đủ dấu hiệu", "Đáng ngờ", "Nguy hiểm")[lv], color = col, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                if (counts) { ScoreBar(sc / 100f, col); Text("Điểm cộng dồn $sc/100", color = C.Sub, fontSize = 12.sp) }
                if (t.sig.isEmpty()) Text("Chưa thấy dấu hiệu lừa đảo nào.", color = C.Dim, fontSize = 12.sp)
                t.sig.entries.sortedByDescending { it.value }.take(6).forEach { Text("• " + it.key, color = C.Sub, fontSize = 12.sp, lineHeight = 16.sp) }
                TextButton({ ThreadGuard.remove(c, t.key); rev++ }) { Text("Xóa theo dõi người này", color = C.Rose, fontSize = 12.sp) }
            }
        }
        if (list.isNotEmpty()) GhostButton("Xóa toàn bộ hồ sơ theo dõi", leading = Icons.Rounded.Delete) { ThreadGuard.clear(c); rev++ }
    }
}
