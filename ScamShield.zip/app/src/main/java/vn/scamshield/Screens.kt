package vn.scamshield

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import vn.scamshield.face.FaceBus

/** Cầu nối giữa giao diện và các hành động cần Activity (xin quyền, mở cài đặt...). */
class Hooks(
    val tick: () -> Int,
    val callOn: () -> Boolean, val smsOn: () -> Boolean,
    val enableCalls: () -> Unit, val enableSms: () -> Unit,
    val toggleListen: () -> Unit,
    val pickImage: () -> Unit,
    val startFace: () -> Unit, val stopFace: () -> Unit,
    val pickVideo: () -> Unit, val startCameraScan: () -> Unit,
    val openOverlay: () -> Unit, val openSocial: () -> Unit,
    val aiMsg: () -> String, val setAiMsg: (String) -> Unit
)

fun displayName(c: Context): String {
    val n = Store.str(c, "name")
    if (n.isNotBlank()) return n
    val e = Store.str(c, "email")
    return if (e.isNotBlank()) e.substringBefore("@") else "Khách"
}

@Composable fun ShieldApp(c: Context, h: Hooks) {
    h.tick()
    var loginDone by remember { mutableStateOf(Store.str(c, "token").isNotEmpty() || Store.flag(c, "skip_login")) }
    Box(Modifier.fillMaxSize()) {
        AppBackground()
        if (!loginDone) LoginScreen(c, { loginDone = true }, { Store.putFlag(c, "skip_login", true); loginDone = true })
        else MainShell(c, h) { Store.putFlag(c, "skip_login", false); loginDone = false }
    }
}

// ───────────────────────── Đăng nhập ─────────────────────────

/** Điểm tin cậy nhỏ dưới tên app: icon + chữ ngắn. */
@Composable private fun TrustChip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) =
    Row(Modifier.background(Color.White, RoundedCornerShape(20.dp)).border(1.dp, C.Stroke, RoundedCornerShape(20.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Icon(icon, null, tint = C.Primary, modifier = Modifier.size(14.dp))
        Text(text, color = C.Body, fontSize = 11.5.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }

@Composable fun LoginScreen(c: Context, onDone: () -> Unit, onSkip: () -> Unit) {
    var reg by remember { mutableStateOf(false) }
    var user by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(Store.str(c, "email")) }
    var pass by remember { mutableStateOf("") }
    var server by remember { mutableStateOf(Store.str(c, "server")) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showServer by remember { mutableStateOf(false) }
    var showPass by remember { mutableStateOf(false) }
    val hasDefault = Config.SERVER_URL.isNotBlank()

    fun finish(code: Int, j: JSONObject?) {
        busy = false
        if (j != null && code in 200..299 && j.has("token")) {
            Store.putStr(c, "token", j.getString("token")); Store.putStr(c, "email", email.trim())
            val nm = j.optString("name").ifEmpty { user.trim().ifEmpty { Store.str(c, "name").ifEmpty { email.trim().substringBefore("@") } } }
            Store.putStr(c, "name", nm)
            onDone()
        } else msg = err(j)
    }
    fun submit() {
        if (email.isBlank() || pass.length < 8) { msg = "Nhập email và mật khẩu (từ 8 ký tự)"; return }
        busy = true; msg = if (reg) "Đang tạo tài khoản…" else "Đang đăng nhập…"
        Api.call(c, "POST", if (reg) "/api/register" else "/api/login",
            JSONObject().put("email", email.trim()).put("password", pass).also { if (reg && user.isNotBlank()) it.put("username", user.trim()) }) { code, j -> finish(code, j) }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.align(Alignment.Center).fillMaxWidth().statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            ShieldBadge(C.Primary, 64.dp)
            Spacer(Modifier.height(6.dp))
            Text("ScamShield", color = C.Text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            Text("Người bạn giúp bạn tránh xa lừa đảo", color = C.Sub, fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TrustChip(Icons.Rounded.PhoneMissed, "Chặn cuộc gọi")
                TrustChip(Icons.Rounded.Sms, "Cảnh báo SMS")
                TrustChip(Icons.Rounded.Videocam, "Soi deepfake")
            }
            Spacer(Modifier.height(22.dp))
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(26.dp))
                .border(1.dp, C.Stroke, RoundedCornerShape(26.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(if (reg) "Tạo tài khoản mới" else "Chào mừng bạn quay lại", color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (reg) "Chỉ mất vài giây để bắt đầu được bảo vệ." else "Đăng nhập để dùng trợ lý AI và đồng bộ cảnh báo.",
                    color = C.Dim, fontSize = 13.sp, lineHeight = 18.sp)
                Spacer(Modifier.height(2.dp))
                if (!hasDefault || showServer)
                    PillField(server, { server = it; Store.putStr(c, "server", it.trim()) }, "Máy chủ https://…", leading = Icons.Rounded.Language)
                if (reg) PillField(user, { user = it }, "Tên của bạn", leading = Icons.Rounded.Person)
                PillField(email, { email = it }, "Email", leading = Icons.Rounded.Email,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                PillField(pass, { pass = it }, "Mật khẩu (từ 8 ký tự)", password = true, showText = showPass, leading = Icons.Rounded.Lock,
                    trailing = { Icon(if (showPass) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Hiện/ẩn mật khẩu", tint = C.Dim,
                        modifier = Modifier.size(22.dp).clickable { showPass = !showPass }) })
                if (msg.isNotEmpty()) Text(msg, color = if (busy) C.Sub else Color(0xFF8A5A00), fontSize = 13.sp, textAlign = TextAlign.Center, lineHeight = 17.sp,
                    modifier = Modifier.fillMaxWidth().background(if (busy) C.Fill else Color(0xFFFFF6E0), RoundedCornerShape(12.dp)).padding(10.dp))
                PrimaryButton(if (reg) "Tạo tài khoản" else "Đăng nhập", enabled = !busy, leading = if (reg) Icons.Rounded.PersonAdd else Icons.Rounded.Login) { if (!busy) submit() }
                if (!reg) Text("Quên mật khẩu?", color = C.Primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().clickable { msg = "Chưa có chức năng đặt lại mật khẩu tự động. Hãy liên hệ người quản trị máy chủ." }.padding(vertical = 2.dp))
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f).height(1.dp).background(C.Stroke))
                Text("hoặc", color = C.Dim, fontSize = 12.sp)
                Box(Modifier.weight(1f).height(1.dp).background(C.Stroke))
            }
            Spacer(Modifier.height(14.dp))
            GhostButton("Dùng thử, không cần tài khoản", leading = Icons.Rounded.RocketLaunch) { onSkip() }
            Spacer(Modifier.height(6.dp))
            Text("Chặn cuộc gọi và cảnh báo tin nhắn vẫn hoạt động đầy đủ.", color = C.Dim, fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { reg = !reg; msg = "" }.padding(8.dp)) {
                Text(if (reg) "Đã có tài khoản?" else "Chưa có tài khoản?", color = C.Sub, fontSize = 14.sp)
                Text(if (reg) "Đăng nhập" else "Đăng ký ngay", color = C.Primary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            if (hasDefault) TextButton({ showServer = !showServer }) {
                Text(if (showServer) "Ẩn máy chủ" else "Máy chủ riêng", color = C.Faint, fontSize = 12.sp) }
        }
    }
}

// ───────────────────────── Khung chính + thanh điều hướng ─────────────────────────

@Composable fun MainShell(c: Context, h: Hooks, onLogin: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf("") }
    var openPost by remember { mutableLongStateOf(0L) }
    BackHandler(enabled = sub.isNotEmpty() || tab != 0) { if (sub.isNotEmpty()) sub = "" else tab = 0 }
    val open: (String) -> Unit = { sub = it }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (sub.isNotEmpty()) SubScreen(c, h, sub, { sub = "" }, open)
            else Crossfade(tab, animationSpec = tween(230), label = "tabs") { t ->
                when (t) {
                    0 -> HomeTab(c, h, open, { openPost = it; tab = 4 }, { tab = 4 }) { tab = 5 }
                    1 -> SettingsTab(c, h)
                    2 -> MessageScreen(c, null, open)
                    4 -> CommunityTab(c, onLogin, openPost) { openPost = 0L }
                    else -> AccountTab(c, onLogin, open)
                }
            }
        }
        BottomBar(tab, sub.isNotEmpty()) { tab = it; sub = "" }
    }
}

/** Thanh điều hướng: nền trắng bo tròn, 2 mục | nút Kiểm tra xanh nổi ở giữa | 2 mục. Nhật ký nằm trong Tài khoản. */
@Composable fun BottomBar(tab: Int, inSub: Boolean, onTab: (Int) -> Unit) {
    // (số tab, icon, nhãn) — null là chỗ chừa cho nút Kiểm tra
    val items = listOf(
        Triple(0, Icons.Rounded.Home, "Trang chủ"), Triple(1, Icons.Rounded.Tune, "Cài đặt"), null,
        Triple(4, Icons.Rounded.Forum, "Cộng đồng"), Triple(5, Icons.Rounded.Person, "Tài khoản"))
    val barShape = RoundedCornerShape(28.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp).padding(top = 6.dp, bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth().height(68.dp)
            .shadow(10.dp, barShape, ambientColor = Color(0x330F3D32), spotColor = Color(0x330F3D32))
            .background(Color.White, barShape).border(1.dp, C.Stroke, barShape), verticalAlignment = Alignment.CenterVertically) {
            items.forEach { it ->
                if (it == null) Spacer(Modifier.weight(1f))
                else {
                    val sel = !inSub && tab == it.first
                    val tint by animateColorAsState(if (sel) C.Primary else C.Sub, tween(220), label = "navTint")
                    Column(Modifier.weight(1f).fillMaxHeight().clickable { onTab(it.first) }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(it.second, null, tint = tint, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.height(3.dp))
                        Text(it.third, fontSize = 10.5.sp, color = tint, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
        Column(Modifier.align(Alignment.TopCenter).offset(y = (-16).dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(70.dp)
                // quầng sáng xanh vẽ tay thay cho shadow màu (shadow màu hay bị vẽ thành khối vuông trên một số máy)
                .drawBehind { drawCircle(Brush.radialGradient(listOf(C.Primary.copy(alpha = 0.28f), Color.Transparent), center, size.minDimension * 0.5f), size.minDimension * 0.5f) },
                contentAlignment = Alignment.Center) {
                Box(Modifier.size(54.dp).background(Brush.verticalGradient(listOf(Color(0xFF12A06F), C.PrimaryDeep)), RoundedCornerShape(19.dp))
                    .border(3.dp, Color.White, RoundedCornerShape(19.dp))
                    .clickable { onTab(2) }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.VerifiedUser, null, tint = Color.White, modifier = Modifier.size(27.dp))
                }
            }
            Text("Kiểm tra", color = C.Primary, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.offset(y = (-4).dp))
        }
    }
}

// ───────────────────────── Trang chủ ─────────────────────────

@Composable fun Avatar(c: Context, onClick: () -> Unit) {
    Box(Modifier.size(46.dp).background(Brush.linearGradient(C.goldGrad), CircleShape).padding(2.dp)
        .background(Color.White, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(displayName(c).take(1).uppercase(), color = C.Primary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable fun HomeTab(c: Context, h: Hooks, open: (String) -> Unit, onPost: (Long) -> Unit, onFeed: () -> Unit, toAccount: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val hasAlerts = Store.count(c, "blocked") + Store.count(c, "warned") > 0
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(top = 14.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable(onClick = toAccount)) {
                Text("ScamShield", color = C.Primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Xin chào, ${displayName(c)}", color = C.Text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            }
            Spacer(Modifier.width(10.dp))
            RoundIconButton(Icons.Rounded.NotificationsNone, { open("blocked") }, 46.dp, dot = hasAlerts)
        }
        PillField(q, { q = it }, "Nhập số điện thoại, tin nhắn hoặc link", leading = Icons.Rounded.Search)
        if (q.isNotBlank()) SearchResults(c, q) else HomeBody(c, h, open, onPost, onFeed)
    }
}

private data class Cat(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String, val tint: Color, val key: String)

@Composable private fun HomeBody(c: Context, h: Hooks, open: (String) -> Unit, onPost: (Long) -> Unit, onFeed: () -> Unit) {
    StatusCard(h, open)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard(Store.count(c, "blocked"), "Đã chặn", Icons.Rounded.Block, C.Primary, Modifier.weight(1f))
        StatCard(Store.count(c, "warned"), "Đã cảnh báo", Icons.Rounded.NotificationsNone, C.Primary, Modifier.weight(1f))
        StatCard(Store.blocklist(c).size, "Số bị chặn", Icons.Rounded.Call, C.Primary, Modifier.weight(1f))
    }
    SectionHeader("Bạn muốn kiểm tra gì?")
    val cats = listOf(
        Cat(Icons.Rounded.PhoneMissed, "Số điện thoại", C.Primary, "blocklist"),
        Cat(Icons.Rounded.Sms, "Tin nhắn SMS", Color(0xFFE59A12), "msg"),
        Cat(Icons.Rounded.LinkOff, "Link & mã độc", C.Rose, "malware"),
        Cat(Icons.Rounded.Videocam, "Video Deepfake", C.Violet, "video"),
        Cat(Icons.Rounded.Forum, "Zalo, Messenger", Color(0xFF1C8FC4), "social"),
        Cat(Icons.Rounded.SmartToy, "Trợ lý AI", C.Blue, "ai"),
        Cat(Icons.Rounded.VerifiedUser, "Tất cả tính năng", C.Primary, "features"),
        Cat(Icons.Rounded.MoreHoriz, "Khác", C.Sub, "other"))
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        cats.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { ct ->
                    // Trợ lý AI giữ biểu tượng con chatbot quen thuộc, vẽ lại tròn trịa và thân thiện hơn
                    if (ct.key == "ai") FeatureCard(Modifier.weight(1f), ct.icon, ct.label, ct.tint, { open(ct.key) }, leading = { AiBotBadge(40.dp) })
                    else FeatureCard(Modifier.weight(1f), ct.icon, ct.label, ct.tint, { open(ct.key) })
                }
            }
        }
    }
    SectionHeader("Đề xuất cho bạn")
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        RowCard(Icons.Rounded.GraphicEq, "Nghe cuộc gọi qua loa ngoài",
            if (ListenService.running) "Đang nghe — bảo vệ bạn khi nghe máy" else "Bảo vệ khi nghe máy", Color(0xFFE59A12)) { open("live") }
        RowCard(Icons.Rounded.Videocam, "Kiểm tra Video Deepfake",
            if (FaceBus.running) "Đang chạy — phát hiện giả mạo AI" else "Phát hiện giả mạo AI", C.Violet) { open("video") }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionHeader("Cảnh báo cộng đồng", "Xem tất cả") { feedStartSection = "post"; onFeed() }
        FeedPreview(c, "post", { feedStartSection = "post"; onFeed() }, onPost)
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionHeader("Tin tức & kiến thức", "Xem tất cả") { feedStartSection = "news"; onFeed() }
        FeedPreview(c, "news", { feedStartSection = "news"; onFeed() }, onPost)
    }
    TipBanner("Ngân hàng, công an không bao giờ yêu cầu OTP hay chuyển tiền qua điện thoại.")
}

/** Thẻ trạng thái bảo vệ: nền bạc hà khi an toàn, cam/đỏ nhạt khi còn thiếu. */
@Composable private fun StatusCard(h: Hooks, open: (String) -> Unit) {
    val callOn = h.callOn(); val smsOn = h.smsOn(); val prot = callOn && smsOn
    val accent = when { prot -> C.Primary; callOn || smsOn -> C.GoldDeep; else -> C.Bad }
    val bg = when { prot -> Color(0xFFE8F5EF); callOn || smsOn -> Color(0xFFFFF4DC); else -> Color(0xFFFDECEC) }
    val edge = when { prot -> Color(0xFFCDE6DA); callOn || smsOn -> Color(0xFFF7DDA0); else -> Color(0xFFF6C9C9) }
    Column(Modifier.fillMaxWidth().background(bg, RoundedCornerShape(24.dp)).border(1.dp, edge, RoundedCornerShape(24.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(50.dp).background(accent.copy(alpha = 0.14f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                Icon(if (prot) Icons.Rounded.VerifiedUser else Icons.Rounded.GppMaybe, null, tint = accent, modifier = Modifier.size(28.dp).pulse(0.95f, 1.06f, 1500))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(if (prot) "Bạn đang được bảo vệ" else "Bảo vệ chưa đầy đủ", color = C.Text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(if (prot) "Tất cả tầng bảo vệ đang bật" else "Bật đủ 2 tầng để khiên hoạt động tốt nhất", color = accent, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Text(if (prot) "ScamShield giúp lọc cuộc gọi và SMS lừa đảo." else "Chạm vào nút bên dưới để bật từng tầng bảo vệ còn thiếu.",
            color = C.Sub, fontSize = 13.sp, lineHeight = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            StatusChip2("Chặn cuộc gọi", callOn)
            StatusChip2("Cảnh báo SMS", smsOn)
        }
        AnimatedVisibility(visible = !callOn || !smsOn,
            enter = fadeIn(tween(220)) + expandVertically(tween(220)),
            exit = fadeOut(tween(180)) + shrinkVertically(tween(180))) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!callOn) PrimaryButton("Bật chặn cuộc gọi", leading = Icons.Rounded.PhoneMissed) { h.enableCalls() }
                if (!smsOn) PrimaryButton("Bật cảnh báo tin nhắn", leading = Icons.Rounded.Sms) { h.enableSms() }
            }
        }
        PrimaryButton("Kiểm tra ngay") { open("msg") }
        Row(Modifier.fillMaxWidth().clickable { open("blocked") }.padding(vertical = 2.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Xem nhật ký cảnh báo", color = C.Primary, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
            Icon(Icons.Rounded.ChevronRight, null, tint = C.Primary, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable private fun StatusChip2(label: String, on: Boolean) =
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(if (on) Icons.Rounded.Check else Icons.Rounded.WarningAmber, null,
            tint = if (on) C.Primary else C.Warn, modifier = Modifier.size(16.dp))
        Text(label, color = C.Body, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }

@Composable private fun SearchResults(c: Context, q: String) {
    val n = ScamDetector.norm(q.trim())
    val qd = q.filter { it.isDigit() }
    val nums = Store.blocklist(c).filter { it.contains(q.trim()) || (qd.length >= 3 && it.filter { ch -> ch.isDigit() }.contains(qd)) }
    val hist = Store.history(c).filter { ScamDetector.norm(it[2] + " " + it[3]).contains(n) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (q.trim().length >= 12) { SectionHeader("Phân tích nhanh nội dung đang nhập"); ResultCard(ScamDetector.analyze(q)) }
        if (nums.isNotEmpty()) {
            SectionHeader("Số đã chặn (${nums.size})")
            CardX { nums.forEach { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Block, null, tint = C.Bad, modifier = Modifier.size(16.dp))
                Text(it, color = C.Text, fontSize = 14.sp) } } }
        }
        if (hist.isNotEmpty()) {
            SectionHeader("Trong nhật ký (${hist.size})")
            hist.take(20).forEach { HistoryRow(it) }
        }
        if (nums.isEmpty() && hist.isEmpty() && q.trim().length < 12) Text("Không tìm thấy kết quả khớp.", color = C.Sub)
    }
}
