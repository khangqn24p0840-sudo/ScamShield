package vn.scamshield

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import java.util.concurrent.Executors

/**
 * Xử lý SMS ở worker riêng. goAsync() giữ broadcast sống trong lúc TFLite/ThreadGuard chạy,
 * tránh bỏ lỡ SMS khi lần đầu nạp model hoặc thiết bị đang bận.
 */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val pending = goAsync()
        executor.execute {
            try {
                process(c.applicationContext, i)
            } catch (error: Throwable) {
                // Không để một lỗi phân tích làm crash tiến trình nhận SMS.
                android.util.Log.e("ScamShieldSMS", "SMS processing failed", error)
            } finally {
                pending.finish()
            }
        }
    }

    private fun process(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        msgs.groupBy { it.originatingAddress?.takeIf { address -> address.isNotBlank() } ?: "?" }
            .forEach { (from, parts) ->
                // Một SMS dài có thể được Android chia thành nhiều segment.
                val body = parts.mapNotNull { it.messageBody }.joinToString("").trim()
                if (body.isBlank()) return@forEach

                Habit.onText(c, body)
                if (Habit.senderBurst(c, from)) {
                    Store.log(c, 1, "Nhiều số lạ nhắn tin", "5 số lạ trong 1 giờ")
                    Notifier.show(c, "⚠️ Nhiều số lạ nhắn tin", "5 số lạ nhắn trong 1 giờ – dấu hiệu cần chú ý. Đừng bấm link lạ.")
                }

                val r = ScamDetector.analyze(body)
                // Theo dõi nhiều ngày: cộng dồn dấu hiệu theo từng số gửi (bỏ qua người trong danh bạ).
                val th = if (CallGuard.known(c, from)) null else ThreadGuard.onMessage(c, "SMS", from, body, r)
                if (th != null) {
                    ThreadGuard.alert(c, "SMS", from, th)
                    return@forEach
                }

                val recent = Store.calledRecently(c, from) && r.score > 0
                if (r.level >= 1 || recent || Store.isBlocked(c, from)) {
                    val high = r.level == 2 || recent
                    val title = when {
                        recent -> "🚨 Số lạ vừa gọi đã nhắn tin đáng ngờ"
                        r.level == 2 -> "🚨 Tin nhắn có dấu hiệu LỪA ĐẢO"
                        else -> "⚠️ Tin nhắn đáng ngờ"
                    }
                    Store.log(c, if (high) 2 else 1, "$title từ $from", body)
                    val advice = if (recent) " Số này vừa gọi cho bạn – cân nhắc chặn, không bấm link."
                        else " Không bấm link, không cung cấp OTP hoặc thông tin cá nhân."
                    val reasons = r.reasons.distinct().joinToString(", ").ifBlank { "Có nhiều dấu hiệu cần kiểm tra" }
                    Notifier.show(c, title, "Từ $from: $reasons.$advice", from.takeIf { Store.digits(it).length >= 7 })
                    Alerter.fire(c, if (high) 2 else 1)
                }
            }
    }

    private companion object {
        // Serial executor giữ thứ tự SMS, tránh nhiều broadcast đồng thời tranh chấp model/Store.
        val executor = Executors.newSingleThreadExecutor { r ->
            Thread(r, "ScamShield-SMS").apply { isDaemon = true }
        }
    }
}
