package vn.scamshield

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Danh sách TÊN MIỀN lừa đảo lưu trong máy (mỗi dòng một tên miền, vd "evil.top").
 * Một mục khớp cả tên miền con (a.b.evil.top khớp evil.top). Không cho đưa dịch vụ rút gọn link hay đuôi dùng chung vào danh sách.
 * Đăng ký trong ScamDetector.analyze nên mọi tin nhắn / thông báo / lời thoại chứa link tới tên miền này đều được cảnh báo.
 */
object DomainGuard {
    private const val KEY = "dom_bl"
    private var appCtx: Context? = null
    fun init(c: Context) { appCtx = c.applicationContext }

    /** Dịch vụ rút gọn link (khớp danh sách của máy chủ): không chặn cả dịch vụ, mà phải xem link dẫn tới đâu. */
    val SHORTENERS = setOf("bit.ly", "bitly.com", "tinyurl.com", "cutt.ly", "t.co", "is.gd", "s.id", "goo.gl", "rebrand.ly",
        "shorturl.at", "ow.ly", "t.ly", "tiny.cc", "rb.gy", "lnkd.in", "buff.ly", "qr.ae")
    private val PUBLIC_SUFFIXES = setOf("vn", "com.vn", "net.vn", "org.vn", "gov.vn", "edu.vn", "ac.vn", "biz.vn", "info.vn", "name.vn",
        "pro.vn", "int.vn", "health.vn", "com", "net", "org", "co.uk", "com.au", "co.jp", "com.cn", "co.kr", "com.sg", "com.my")

    private val HOST_RE = Regex("[a-z0-9-]+(\\.[a-z0-9-]+)+")
    private val IPV4 = Regex("\\d{1,3}(\\.\\d{1,3}){3}")

    /** http://User@WWW.Evil.top:8080/x?y -> evil.top ; rỗng nếu không phải tên miền hợp lệ. */
    fun hostOf(raw: String): String {
        var s = raw.trim().lowercase()
        s = s.replace(Regex("^[a-z][a-z0-9+.-]*://"), "")
        s = s.split('/', '?', '#').first().substringAfterLast('@').substringBefore(':').trim('.')
        if (s.startsWith("www.")) s = s.substring(4)
        return if (s.length <= 100 && HOST_RE.matches(s)) s else ""
    }

    fun isShortener(host: String) = host in SHORTENERS

    private fun candidates(host: String): List<String> {
        if (IPV4.matches(host)) return listOf(host)
        val labels = host.split('.')
        return (0 until labels.size - 1).map { labels.drop(it).joinToString(".") }
    }

    fun entries(c: Context): List<String> = Store.str(c, KEY).split('\n').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    private fun save(c: Context, list: List<String>) = Store.putStr(c, KEY, list.joinToString("\n"))

    /** Có được phép đưa vào danh sách không (không phải rút gọn link / đuôi chung). */
    private fun listable(host: String) = host.isNotEmpty() && host !in SHORTENERS && host !in PUBLIC_SUFFIXES

    fun add(c: Context, url: String): Boolean {
        val h = hostOf(url)
        if (!listable(h)) return false
        val cur = entries(c)
        if (h !in cur) save(c, cur + h)
        return true
    }

    fun remove(c: Context, domain: String) = save(c, entries(c).filter { it != domain })

    /** Gỡ mọi mục đang làm cho isListed(url) trả về true. */
    fun removeMatching(c: Context, url: String) {
        val h = hostOf(url)
        if (h.isEmpty()) return
        val cands = candidates(h).toSet()
        save(c, entries(c).filter { it !in cands })
    }

    fun isListed(c: Context, url: String): Boolean {
        val h = hostOf(url)
        if (h.isEmpty()) return false
        val list = entries(c)
        if (list.isEmpty()) return false
        val set = list.toSet()
        return candidates(h).any { it in set }
    }

    // ───────── Tìm link trong văn bản ─────────

    private val URL_RE = Regex(
        "(?<![@\\w.-])(?:https?://[^\\s<>\"'()]+|(?:www\\.)[^\\s<>\"'()]+|" +
        "(?:[a-z0-9-]+\\.)+(?:com|vn|net|org|top|xyz|vip|cc|club|icu|click|shop|site|online|live|me|ly|io|co|info|biz|link|app)(?:/[^\\s<>\"'()]*)?(?![\\w@-]))",
        RegexOption.IGNORE_CASE)

    /** Các đường link tìm thấy trong văn bản (đã bỏ dấu câu ở cuối), không trùng nhau. */
    fun urlsIn(text: String): List<String> =
        URL_RE.findAll(text.take(4000)).map { it.value.trimEnd('.', ',', ';', ':', '!', '?', ')', ']') }
            .filter { hostOf(it).isNotEmpty() }.distinct().toList()

    /** Dòng cảnh báo nếu văn bản chứa link tới tên miền trong danh sách; ngược lại null. */
    fun checkText(text: String): String? {
        val c = appCtx ?: return null
        if (entries(c).isEmpty()) return null
        val hit = urlsIn(text).firstOrNull { isListed(c, it) } ?: return null
        return "Link tới tên miền ${hostOf(hit)} nằm trong danh sách lừa đảo"
    }

    // ───────── Máy chủ ─────────

    /** Tải các tên miền đã xác minh từ máy chủ (cần đăng nhập). */
    fun sync(c: Context, onMsg: (String) -> Unit) {
        onMsg("Đang tải…")
        Api.call(c, "GET", "/api/domains", null) { code, j ->
            if (code == 200 && j != null) {
                val a = j.optJSONArray("domains") ?: JSONArray()
                var n = 0
                for (i in 0 until a.length()) if (add(c, a.optString(i))) n++
                onMsg("Đã cập nhật $n tên miền lừa đảo từ cộng đồng")
            } else onMsg(err(j))
        }
    }

    /** cb(mã HTTP, JSON {verified, reports}). */
    fun check(c: Context, url: String, cb: (Int, JSONObject?) -> Unit) =
        Api.call(c, "GET", "/api/domains/check?host=" + URLEncoder.encode(hostOf(url), "UTF-8"), null, cb)

    fun report(c: Context, url: String, cb: (Int, JSONObject?) -> Unit) =
        Api.call(c, "POST", "/api/domains/report", JSONObject().put("host", hostOf(url)), cb)

    /** Nhờ máy chủ đi theo các chuyển hướng của link: cb(mã HTTP, JSON {final, hops, note, verified, reports}). */
    fun expand(c: Context, url: String, cb: (Int, JSONObject?) -> Unit) =
        Api.call(c, "POST", "/api/links/expand", JSONObject().put("url", url), cb)
}
