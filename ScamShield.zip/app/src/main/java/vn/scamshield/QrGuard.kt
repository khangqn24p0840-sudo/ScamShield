package vn.scamshield

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.Locale

/** Kết quả phân tích một mã QR: loại, điểm rủi ro, các dòng thông tin đọc được và lời khuyên. */
data class QrInfo(
    val kind: String,                       // pay | url | wifi | sms | tel | text | other
    val title: String,
    val result: Result,
    val rows: List<Pair<String, String>> = emptyList(),
    val tips: List<String> = emptyList(),
    val acct: String? = null,               // số tài khoản nhận (chỉ với mã chuyển tiền VietQR tới tài khoản)
    val bin: String = "",
    val link: String? = null                // đường link trong mã (để hiện khối kiểm tra link)
)

/**
 * Phân tích nội dung mã QR NGAY TRÊN MÁY, không mở link, không gửi nội dung đi đâu.
 * Mã chuyển tiền VietQR (chuẩn EMVCo/NAPAS) được đọc ra: ngân hàng, số tài khoản, số tiền, nội dung, và kiểm tra mã CRC.
 */
object QrGuard {
    private val PAY_TIPS = listOf(
        "Trước khi xác nhận, đối chiếu TÊN chủ tài khoản hiển thị trong app ngân hàng với người bạn định trả tiền.",
        "Mã QR bị dán đè lên mã thật (quán ăn, cửa hàng, xe, nhà trọ) là thủ đoạn phổ biến: kiểm tra mã có bị dán chồng không.",
        "Người lạ đưa mã QR bắt chuyển tiền gấp để nhận thưởng, nộp phạt, hoàn tiền thì đó là lừa đảo.")
    private val URL_TIPS = listOf(
        "App không mở link giúp bạn.",
        "Đừng nhập mật khẩu, OTP hay số thẻ ở trang mở ra từ mã QR lạ.",
        "Cần dùng dịch vụ nào, hãy tự mở app hoặc trang chính thức thay vì đi theo mã QR.")

    /** Từ khóa thương hiệu -> các tên miền chính thức mà app biết. Danh sách chưa đầy đủ, có thể thiếu tên miền hợp lệ. */
    private val BRANDS = listOf(
        "vietcombank" to listOf("vietcombank.com.vn"),
        "techcombank" to listOf("techcombank.com.vn", "techcombank.com"),
        "mbbank" to listOf("mbbank.com.vn"),
        "vietinbank" to listOf("vietinbank.vn", "vietinbank.com.vn"),
        "agribank" to listOf("agribank.com.vn"),
        "sacombank" to listOf("sacombank.com.vn"),
        "vpbank" to listOf("vpbank.com.vn"),
        "tpbank" to listOf("tpb.vn", "tpbank.com.vn"),
        "bidv" to listOf("bidv.com.vn", "bidv.vn"),
        "momo" to listOf("momo.vn"),
        "zalopay" to listOf("zalopay.vn"),
        "vneid" to listOf("gov.vn"),
        "dichvucong" to listOf("gov.vn"))

    private val DANGEROUS_SCHEMES = setOf("javascript", "data", "intent", "file", "content", "vbscript")
    private val SCHEME = Regex("^([a-z][a-z0-9+.-]{1,15}):", RegexOption.IGNORE_CASE)
    private val DOMAIN = Regex("^(?:www\\.)?[a-z0-9-]+(?:\\.[a-z0-9-]+)*\\.([a-z]{2,})(?:[/?#]\\S*)?$", RegexOption.IGNORE_CASE)
    private val COMMON_TLD = setOf("com", "vn", "net", "org", "top", "xyz", "vip", "cc", "club", "icu", "click", "shop",
        "site", "online", "live", "me", "ly", "io", "co", "info", "biz", "link", "app", "id", "gov", "edu")

    fun analyze(c: Context, raw0: String): QrInfo {
        val raw = raw0.trim().take(4000)
        val low = raw.lowercase()
        val scheme = SCHEME.find(raw)?.groupValues?.get(1)?.lowercase()
        return when {
            raw.startsWith("000201") -> pay(c, raw)
            low.startsWith("wifi:") -> wifi(raw)
            low.startsWith("smsto:") || low.startsWith("sms:") -> sms(c, raw)
            low.startsWith("tel:") -> tel(c, raw)
            low.startsWith("http://") || low.startsWith("https://") -> url(c, raw)
            scheme != null && (scheme in DANGEROUS_SCHEMES || scheme == "market") -> odd(raw)
            looksLikeDomain(raw) -> url(c, raw)
            else -> text(raw)
        }
    }

    private fun looksLikeDomain(s: String): Boolean {
        if (s.contains(' ') || s.contains('\n')) return false
        val m = DOMAIN.find(s) ?: return false
        val tld = m.groupValues[1].lowercase()
        return s.lowercase().startsWith("www.") || s.contains('/') || tld in COMMON_TLD
    }

    /** Tình huống nhận mã do người dùng chọn: 0 chưa rõ, 1 quét ở cửa hàng/quán, 2 người lạ gửi qua tin nhắn, 3 bị bảo trả tiền để nhận thưởng/hoàn tiền/nộp phạt. */
    fun withContext(q: QrInfo, ctx: Int): QrInfo {
        if (ctx == 0) return q
        val money = q.kind == "pay"; val link = q.kind == "url"
        var add = 0
        val why = ArrayList<String>(q.result.reasons)
        val tips = ArrayList<String>(q.tips)
        when (ctx) {
            1 -> if (money) tips.add("Đang ở cửa hàng: nhờ nhân viên đọc tên cửa hàng, so với tên người nhận hiện trong app ngân hàng, và xem mã có bị dán chồng lên không.")
            2 -> if (money) { add += 40; why += "Người lạ gửi mã chuyển tiền qua tin nhắn: rất hay là lừa đảo" }
                 else if (link) { add += 25; why += "Link do người lạ gửi qua tin nhắn/mạng xã hội thường là link lừa đảo" }
            3 -> if (money || link) { add += 60; why += "Phải trả tiền hoặc quét mã để nhận thưởng, hoàn tiền, giải ngân, nộp phạt chính là THỦ ĐOẠN lừa đảo kinh điển" }
        }
        return q.copy(result = Result((q.result.score + add).coerceAtMost(100), why.distinct()), tips = tips)
    }

    // ───────── Mã chuyển tiền VietQR (EMVCo) ─────────

    /** CRC-16/CCITT-FALSE (đa thức 0x1021, khởi tạo 0xFFFF), đúng chuẩn dùng cho mã QR thanh toán. */
    fun crc16(s: String): Int {
        var crc = 0xFFFF
        for (b in s.toByteArray(Charsets.UTF_8)) {
            crc = crc xor ((b.toInt() and 0xFF) shl 8)
            repeat(8) { crc = if ((crc and 0x8000) != 0) ((crc shl 1) xor 0x1021) and 0xFFFF else (crc shl 1) and 0xFFFF }
        }
        return crc
    }

    /** Tách chuỗi TLV: mỗi mục = 2 ký tự mã + 2 chữ số độ dài + giá trị. Sai cấu trúc thì trả null. */
    fun tlv(s: String): List<Pair<String, String>>? {
        val out = ArrayList<Pair<String, String>>()
        var i = 0
        while (i < s.length) {
            if (i + 4 > s.length) return null
            val lenStr = s.substring(i + 2, i + 4)
            if (!lenStr.all { it.isDigit() }) return null
            val len = lenStr.toInt()
            if (i + 4 + len > s.length) return null
            out.add(s.substring(i, i + 2) to s.substring(i + 4, i + 4 + len))
            i += 4 + len
        }
        return out
    }

    private fun toMap(l: List<Pair<String, String>>): Map<String, String> {
        val m = HashMap<String, String>()
        for ((k, v) in l) if (!m.containsKey(k)) m[k] = v
        return m
    }

    private fun money(v: String): String {
        val n = v.substringBefore('.').toLongOrNull() ?: return v
        return "%,d".format(Locale.US, n).replace(',', '.') + " VND"
    }

    private fun pay(c: Context, raw: String): QrInfo {
        val top = tlv(raw) ?: return QrInfo("pay", "Mã chuyển tiền bị lỗi",
            Result(60, listOf("Không đọc được cấu trúc mã chuyển tiền: mã bị hỏng hoặc đã bị chỉnh sửa")), tips = PAY_TIPS)
        val m = toMap(top)
        val rows = ArrayList<Pair<String, String>>()
        val why = ArrayList<String>()
        var score = 0

        val crcOk = raw.length > 8 && raw.substring(raw.length - 8, raw.length - 4) == "6304" &&
            "%04X".format(Locale.US, crc16(raw.substring(0, raw.length - 4))) == raw.takeLast(4).uppercase()
        if (!crcOk) { score += 45; why += "Mã kiểm tra (CRC) sai: nội dung mã có thể đã bị chỉnh sửa hoặc làm giả" }

        // Tìm khối thông tin tài khoản VietQR của NAPAS (mã 26..51, GUID A000000727)
        var bin = ""; var acct = ""; var service = ""; var provider = ""
        for ((tag, v) in top) {
            val t = tag.toIntOrNull() ?: continue
            if (t !in 26..51) continue
            val sub = toMap(tlv(v) ?: continue)
            val guid = sub["00"] ?: ""
            if (provider.isEmpty()) provider = guid
            if (guid.equals("A000000727", ignoreCase = true)) {
                val bene = toMap(tlv(sub["01"] ?: "") ?: emptyList())
                bin = bene["00"] ?: ""; acct = bene["01"] ?: ""; service = sub["02"] ?: ""
                break
            }
        }
        val found = acct.isNotEmpty()
        val isCard = service.equals("QRIBFTTC", ignoreCase = true)

        val currency = m["53"]; val country = m["58"]
        if (currency != null && currency != "704") { score += 25; why += "Đơn vị tiền không phải VND ($currency)" }
        if (country != null && !country.equals("VN", ignoreCase = true)) { score += 25; why += "Quốc gia nhận tiền không phải Việt Nam ($country)" }

        if (found) {
            rows.add("Ngân hàng nhận" to Banks.name(bin))
            rows.add((if (isCard) "Số thẻ nhận" else "Số tài khoản nhận") to acct)
        } else {
            rows.add("Nhà cung cấp" to provider.ifEmpty { "không rõ" })
            why += "Mã thanh toán của ví hoặc ngân hàng khác: app chưa đọc được tài khoản nhận"
        }
        m["59"]?.let { rows.add("Tên hiển thị trên mã" to it) }
        m["54"]?.let { rows.add("Số tiền cố định" to money(it)) }
        when (m["01"]) {
            "11" -> rows.add("Loại mã" to "Mã tĩnh (dùng đi dùng lại, người trả tự nhập số tiền)")
            "12" -> rows.add("Loại mã" to "Mã động (tạo riêng cho một giao dịch)")
        }
        m["52"]?.takeIf { it != "0000" }?.let { rows.add("Mã ngành (MCC)" to it) }
        val amount = m["54"]?.substringBefore('.')?.toLongOrNull()
        if (amount != null && amount >= 5_000_000L) rows.add("Lưu ý" to "Số tiền lớn: dừng lại, gọi xác nhận với người nhận bằng số điện thoại bạn đã biết từ trước")
        val purpose = top.firstOrNull { it.first == "62" }?.second?.let { tlv(it) }?.firstOrNull { it.first == "08" }?.second
        if (purpose != null) {
            rows.add("Nội dung chuyển" to purpose)
            val pr = ScamDetector.analyze(purpose)
            if (pr.score >= 30) { score += pr.score / 2; why.addAll(pr.reasons) }
        }

        val account = if (found && !isCard) acct else null
        if (account != null && AccountGuard.isListed(c, account, bin)) { score += 90; why += "Số tài khoản nhận nằm trong danh sách lừa đảo trên máy bạn" }
        if (found && isCard) why += "Mã chuyển tới SỐ THẺ: app không đối chiếu được với danh sách số tài khoản"
        return QrInfo("pay", "Mã QR chuyển tiền (VietQR)", Result(score.coerceAtMost(100), why.distinct()), rows, PAY_TIPS, account, bin)
    }

    // ───────── Link ─────────

    private fun url(c: Context, raw: String): QrInfo {
        val base = linkCheck(raw)                       // dùng lại bộ chấm điểm link có sẵn (Features.kt)
        var score = base.score
        val why = ArrayList<String>(base.reasons)
        val rest = raw.lowercase().let { it.substringAfter("://", it) }
        val authority = rest.substringBefore('/').substringBefore('?').substringBefore('#')
        if (authority.contains('@')) { score += 40; why += "Link có ký tự @ trước tên miền (thủ thuật giả mạo tên miền)" }
        val host = authority.substringAfterLast('@').substringBefore(':')
        if (DomainGuard.isListed(c, host)) { score += 85; why += "Tên miền nằm trong danh sách lừa đảo (cộng đồng hoặc trên máy bạn)" }
        if (why.none { it.startsWith("Tên miền nhái") }) {
            for ((kw, doms) in BRANDS) {
                if (host.contains(kw) && doms.none { host == it || host.endsWith(".$it") }) {
                    score += 35; why += "Tên miền có chữ \"$kw\" nhưng không thuộc tên miền chính thức mà app biết"; break
                }
            }
        }
        return QrInfo("url", "Mã QR chứa đường link", Result(score.coerceAtMost(100), why.distinct()),
            listOf("Đường link" to raw.take(300), "Tên miền" to host), URL_TIPS, link = raw)
    }

    private fun odd(raw: String) = QrInfo("other", "Mã QR chứa lệnh lạ",
        Result(70, listOf("Mã không phải trang web thông thường (${raw.substringBefore(':')}:), có thể kích hoạt hành động ngầm")),
        listOf("Nội dung" to raw.take(300)), listOf("Đừng làm theo, hãy bỏ qua mã này."))

    // ───────── Wi-Fi / SMS / điện thoại / văn bản ─────────

    private fun wifi(raw: String): QrInfo {
        val body = raw.substring(5)
        fun field(k: String) = Regex("(?:^|;)" + k + ":([^;]*)", RegexOption.IGNORE_CASE).find(body)?.groupValues?.get(1) ?: ""
        val type = field("T")
        var score = 0; val why = ArrayList<String>()
        if (type.isBlank() || type.equals("nopass", ignoreCase = true)) { score += 15; why += "Wi-Fi không có mật khẩu: dễ bị theo dõi, đừng đăng nhập ngân hàng qua mạng này" }
        return QrInfo("wifi", "Mã QR kết nối Wi-Fi", Result(score, why),
            listOf("Tên mạng" to field("S"), "Bảo mật" to type.ifBlank { "không có" }))
    }

    private fun sms(c: Context, raw: String): QrInfo {
        val rest = raw.substringAfter(':')
        val num: String; val body: String
        if (raw.lowercase().startsWith("smsto:")) { num = rest.substringBefore(':'); body = rest.substringAfter(':', "") }
        else { num = rest.substringBefore('?').substringBefore(';'); body = Uri.decode(Regex("body=([^&]*)", RegexOption.IGNORE_CASE).find(rest)?.groupValues?.get(1) ?: "") }
        var score = 0; val why = ArrayList<String>()
        if (Store.isBlocked(c, num)) { score += 60; why += "Số nhận tin nằm trong danh sách chặn của bạn" }
        if (num.filter { it.isDigit() }.length in 3..5) { score += 30; why += "Nhắn tới đầu số ngắn: có thể bị tính phí cao" }
        val r = ScamDetector.analyze(body)
        score += r.score; why.addAll(r.reasons)
        return QrInfo("sms", "Mã QR soạn sẵn tin nhắn", Result(score.coerceAtMost(100), why.distinct()),
            listOf("Gửi tới" to num, "Nội dung" to body.take(300)), listOf("Đừng gửi tin nhắn theo mã QR của người lạ."))
    }

    private fun tel(c: Context, raw: String): QrInfo {
        val num = raw.substringAfter(':')
        val bad = Store.isBlocked(c, num)
        return QrInfo("tel", "Mã QR gọi điện", Result(if (bad) 70 else 0, if (bad) listOf("Số điện thoại nằm trong danh sách chặn của bạn") else emptyList()),
            listOf("Số điện thoại" to num))
    }

    private fun text(raw: String) = QrInfo("text", "Mã QR chứa văn bản", ScamDetector.analyze(raw), listOf("Nội dung" to raw.take(300)))
}

/** Đọc mã QR từ camera (Google code scanner, không cần xin quyền camera) hoặc từ ảnh trong máy. cb(nội dung, lỗi). */
object QrScan {
    fun camera(c: Context, cb: (String?, String?) -> Unit) {
        try {
            val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(c, opts).startScan()
                .addOnSuccessListener { b -> cb(b.rawValue, if (b.rawValue == null) "Mã QR không có nội dung văn bản" else null) }
                .addOnFailureListener { e -> cb(null, "Không mở được máy quét: ${e.message}") }
        } catch (e: Exception) { cb(null, "Không mở được máy quét: ${e.message}") }
    }

    fun fromImage(c: Context, uri: Uri, cb: (String?, String?) -> Unit) {
        try {
            val img = InputImage.fromFilePath(c, uri)
            val sc = BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
            sc.process(img)
                .addOnSuccessListener { list ->
                    val v = list.firstOrNull { it.rawValue != null }?.rawValue
                    cb(v, if (v == null) "Không tìm thấy mã QR trong ảnh" else null); sc.close()
                }
                .addOnFailureListener { e -> cb(null, "Không đọc được ảnh: ${e.message}"); sc.close() }
        } catch (e: Exception) { cb(null, "Không đọc được ảnh: ${e.message}") }
    }
}
