package vn.scamshield.face

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/**
 * Nạp mô hình khuôn mặt do bạn huấn luyện bên ngoài (ml/face/) vào app, không cần ADB, không cần build lại APK.
 * Người dùng chọn đúng HAI tệp: deepfake.tflite và deepfake_meta.json. Cả hai được kiểm tra rồi mới thay bản đang dùng;
 * lỗi ở đâu thì giữ nguyên bản cũ. Mô hình mới có hiệu lực ở lần "Bắt đầu kiểm tra" kế tiếp.
 */
object FaceModelImport {
    private const val MAX_MODEL = 60L * 1024 * 1024
    private const val MAX_META = 64L * 1024

    fun import(ctx: Context, uris: List<Uri>): String {
        var model: ByteArray? = null
        var meta: String? = null
        for (u in uris) {
            val name = displayName(ctx, u).lowercase()
            val limit = if (name.endsWith(".tflite")) MAX_MODEL else if (name.endsWith(".json")) MAX_META else continue
            val bytes = runCatching {
                ctx.contentResolver.openInputStream(u)?.use { it.readBytes() }
            }.getOrNull() ?: return "Không đọc được tệp $name."
            if (bytes.size > limit) return "Tệp $name quá lớn."
            if (name.endsWith(".tflite")) model = bytes else meta = bytes.toString(Charsets.UTF_8)
        }
        if (model == null || meta == null)
            return "Cần chọn cả hai tệp: deepfake.tflite và deepfake_meta.json (giữ phím chọn nhiều tệp)."
        TfliteDeepfakeClassifier.validate(model, meta)?.let { return it }

        val dir = ctx.getExternalFilesDir("models") ?: return "Không truy cập được bộ nhớ ứng dụng."
        if (!dir.exists() && !dir.mkdirs()) return "Không tạo được thư mục lưu mô hình."
        return try {
            val tm = File(dir, TfliteDeepfakeClassifier.MODEL + ".tmp").also { it.writeBytes(model) }
            val tj = File(dir, TfliteDeepfakeClassifier.META + ".tmp").also { it.writeText(meta) }
            val fm = File(dir, TfliteDeepfakeClassifier.MODEL)
            val fj = File(dir, TfliteDeepfakeClassifier.META)
            fm.delete(); fj.delete()
            if (!tm.renameTo(fm) || !tj.renameTo(fj)) return "Không ghi được tệp. Hãy thử lại."
            "Đã nạp mô hình mới (${model.size / 1024} KB). Bấm Dừng rồi Bắt đầu kiểm tra lại để áp dụng."
        } catch (e: Exception) { "Lỗi khi lưu mô hình: ${e.message}" }
    }

    /** Xóa mô hình đã nạp, quay về bản trong APK (hoặc chỉ chỉ báo kỹ thuật nếu APK không có). */
    fun reset(ctx: Context): String {
        val dir = ctx.getExternalFilesDir("models") ?: return "Không truy cập được bộ nhớ ứng dụng."
        File(dir, TfliteDeepfakeClassifier.MODEL).delete(); File(dir, TfliteDeepfakeClassifier.META).delete()
        return "Đã xóa mô hình đã nạp. Bắt đầu kiểm tra lại để dùng bản trong APK."
    }

    private fun displayName(ctx: Context, u: Uri): String =
        runCatching {
            ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: (u.lastPathSegment ?: "")
}
