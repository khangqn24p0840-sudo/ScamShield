package vn.scamshield.face

import android.content.Context
import org.json.JSONObject

/**
 * Nạp trọng số/ngưỡng đã hiệu chỉnh từ assets/face_calib.json (do ml/face_calibrate.py tạo ra).
 * Không có file, file hỏng hoặc giá trị vô lý -> dùng cấu hình mặc định, app vẫn chạy như cũ.
 */
object FaceCalibration {
    private const val MAX_W = 12.0     // phải khớp MAX_W trong ml/face_calibrate.py
    private const val MAX_B = 15.0
    fun load(c: Context): FaceLivenessAnalyzer.Config {
        val d = FaceLivenessAnalyzer.Config()
        return try {
            val text = c.assets.open("face_calib.json").use { it.readBytes().toString(Charsets.UTF_8) }
            val j = JSONObject(text)
            val w = d.weights.toMutableMap()
            j.optJSONObject("weights")?.let { o ->
                for (k in w.keys.toList()) if (o.has(k)) w[k] = o.getDouble(k).coerceIn(0.0, MAX_W)
            }
            val sus = j.optDouble("suspiciousAt", d.suspiciousAt)
            val high = j.optDouble("highAt", d.highAt)
            val bias = j.optDouble("bias", d.bias)
            if (sus.isNaN() || high.isNaN() || bias.isNaN() || sus < 0.05 || sus > 0.95 || high < sus || high > 0.99 || bias < -MAX_B || bias > 2.0) d
            else d.copy(weights = w, bias = bias, suspiciousAt = sus, highAt = high)
        } catch (_: Exception) { d }
    }
}
