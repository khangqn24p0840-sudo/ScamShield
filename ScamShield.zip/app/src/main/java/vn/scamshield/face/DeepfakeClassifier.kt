package vn.scamshield.face

import android.graphics.Bitmap

/**
 * Điểm cắm cho mô hình học sâu phát hiện deepfake (TFLite, ONNX...).
 * Chưa có mô hình thì dùng NoopClassifier, analyzer vẫn chạy bằng các chỉ báo heuristic.
 * Bản TFLite: TfliteDeepfakeClassifier (mô hình huấn luyện bằng ml/face/).
 */
interface DeepfakeClassifier {
    val isAvailable: Boolean

    /** Viền nới thêm quanh khung mặt (tỉ lệ theo kích thước khung, mỗi cạnh). PHẢI bằng MARGIN lúc huấn luyện. */
    val cropMargin: Float get() = 0f

    /** @return xác suất khuôn mặt là giả (0..1), hoặc null nếu không đánh giá được. */
    fun fakeProbability(face: Bitmap): Float?
}

object NoopClassifier : DeepfakeClassifier {
    override val isAvailable: Boolean = false
    override fun fakeProbability(face: Bitmap): Float? = null
}
