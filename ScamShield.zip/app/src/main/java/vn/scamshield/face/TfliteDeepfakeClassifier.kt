package vn.scamshield.face

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONObject
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Nạp assets/deepfake_model.tflite + assets/deepfake_config.json.
 * Theo config: đầu vào 224x224 RGB, chuẩn hoá về [-1, 1]; đầu ra là XÁC SUẤT THẬT (class 1 = "Real").
 * Interface của app cần xác suất GIẢ nên trả về 1 - p_real.
 * Thiếu file / nạp lỗi / sai shape -> isAvailable = false, app tự quay về heuristic như cũ.
 */
class TfliteDeepfakeClassifier(context: Context) : DeepfakeClassifier {

    @Volatile var status = "chưa nạp"
        private set

    /** Ngưỡng trong config (áp cho xác suất THẬT). Chỉ để tham khảo/gỡ lỗi, analyzer có cách quy đổi riêng. */
    val realThreshold: Float

    private val size: Int
    private val normalizeMinus1To1: Boolean
    private val interpreter: Interpreter?
    private val inputBuf: ByteBuffer
    private val pixels: IntArray

    init {
        var sz = 224
        var neg = true
        var thr = 0.4f
        var interp: Interpreter? = null
        try {
            val cfg = JSONObject(context.assets.open(CONFIG).use { String(it.readBytes(), Charsets.UTF_8) })
            sz = cfg.optInt("input_size", 224)
            neg = cfg.optString("normalization", "[-1, 1]").replace(" ", "") == "[-1,1]"
            thr = cfg.optDouble("threshold", 0.4).toFloat()
            check(cfg.optInt("input_channels", 3) == 3) { "mô hình cần 3 kênh màu" }
            check(cfg.optString("output", "probability_of_real") == "probability_of_real") { "config đầu ra không phải probability_of_real" }

            val bytes = context.assets.open(MODEL).use { it.readBytes() }
            val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            buf.put(bytes); buf.rewind()
            val it = Interpreter(buf, Interpreter.Options().setNumThreads(2))

            // Kiểm tra shape thực tế khớp config trước khi dùng.
            val inShape = it.getInputTensor(0).shape()          // kỳ vọng [1, size, size, 3]
            check(inShape.size == 4 && inShape[1] == sz && inShape[2] == sz && inShape[3] == 3) {
                "shape đầu vào ${inShape.toList()} không khớp config"
            }
            val outShape = it.getOutputTensor(0).shape()        // kỳ vọng [1, 1]
            check(outShape.last() == 1) { "shape đầu ra ${outShape.toList()} không phải 1 giá trị" }
            interp = it
            status = "đã nạp"
        } catch (e: Throwable) {
            interp = null
            status = "lỗi: ${e.message}"
        }
        size = sz; normalizeMinus1To1 = neg; realThreshold = thr; interpreter = interp
        inputBuf = ByteBuffer.allocateDirect(4 * size * size * 3).order(ByteOrder.nativeOrder())
        pixels = IntArray(size * size)
    }

    override val isAvailable: Boolean get() = interpreter != null

    @Synchronized
    override fun fakeProbability(face: Bitmap): Float? {
        val it = interpreter ?: return null
        return try {
            val scaled = Bitmap.createScaledBitmap(face, size, size, true)
            scaled.getPixels(pixels, 0, size, 0, 0, size, size)
            if (scaled !== face) scaled.recycle()
            inputBuf.rewind()
            for (p in pixels) {                                   // thứ tự RGB
                put(((p shr 16) and 0xFF)); put(((p shr 8) and 0xFF)); put((p and 0xFF))
            }
            inputBuf.rewind()
            val out = Array(1) { FloatArray(1) }
            it.run(inputBuf, out)
            val real = out[0][0]
            if (!real.isFinite()) null else (1f - real).coerceIn(0f, 1f)
        } catch (e: Throwable) {
            status = "lỗi: ${e.message}"; null
        }
    }

    private fun put(v: Int) {
        inputBuf.putFloat(if (normalizeMinus1To1) v / 127.5f - 1f else v / 255f)
    }

    override fun close() { interpreter?.close() }

    companion object {
        private const val MODEL = "deepfake_model.tflite"
        private const val CONFIG = "deepfake_config.json"
    }
}
