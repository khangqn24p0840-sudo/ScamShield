package vn.scamshield.face

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONObject
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.exp
import kotlin.math.ln

/**
 * Mô hình phân loại khuôn mặt thật/giả chạy trong máy, huấn luyện bằng ml/face/ (xem ml/face/README_FACE.md).
 *
 * Nạp theo thứ tự ưu tiên (mô hình + file meta đi cùng nhau, lấy từ CÙNG một nơi):
 *   1) <externalFilesDir>/models/deepfake.tflite + deepfake_meta.json   (thay không cần build lại APK)
 *   2) assets/deepfake.tflite + assets/deepfake_meta.json
 * Không có mô hình, mô hình lỗi hoặc sai định dạng -> isAvailable = false, app chạy bằng các chỉ báo kỹ thuật như cũ.
 *
 * Hợp đồng với mô hình: đầu vào [1,H,W,3] float32, RGB, giá trị 0..1; đầu ra [1,1] (xác suất giả) hoặc [1,2].
 * Meta (do evaluate_face.py ghi): cropMargin, fakeIndex, platt = [a, b] để hiệu chỉnh xác suất:
 *   p' = sigmoid(a * logit(p) + b)   (ngưỡng vận hành đã được dời về p' = 0.5)
 */
class TfliteDeepfakeClassifier(context: Context) : DeepfakeClassifier {

    private class Loaded(
        val interp: Interpreter, val size: Int, val outN: Int, val fakeIndex: Int,
        val a: Float, val b: Float, val margin: Float, val source: String
    ) {
        val input: ByteBuffer = ByteBuffer.allocateDirect(4 * size * size * 3).order(ByteOrder.nativeOrder())
        val pixels = IntArray(size * size)
        val out = Array(1) { FloatArray(outN) }
    }

    private val ctx = context.applicationContext
    private val m: Loaded? = load()

    /** Mô tả ngắn để hiển thị/gỡ lỗi. */
    val status: String = m?.let { "Mô hình AI khuôn mặt: đang dùng (${it.source}, ${it.size}px)" }
        ?: "Chưa có mô hình AI khuôn mặt: chỉ dùng chỉ báo kỹ thuật"

    override val isAvailable: Boolean get() = m != null
    override val cropMargin: Float get() = m?.margin ?: 0f

    @Synchronized
    override fun fakeProbability(face: Bitmap): Float? {
        val l = m ?: return null
        return try {
            val s = Bitmap.createScaledBitmap(face, l.size, l.size, true)
            s.getPixels(l.pixels, 0, l.size, 0, 0, l.size, l.size)
            if (s !== face) s.recycle()
            l.input.rewind()
            for (p in l.pixels) {
                l.input.putFloat(((p shr 16) and 0xFF) / 255f)
                l.input.putFloat(((p shr 8) and 0xFF) / 255f)
                l.input.putFloat((p and 0xFF) / 255f)
            }
            l.input.rewind()
            l.interp.run(l.input, l.out)
            val raw = (if (l.outN == 1) l.out[0][0] else l.out[0][l.fakeIndex]).toDouble()
            if (raw.isNaN()) return null
            val z = ln(raw.coerceIn(1e-6, 1 - 1e-6) / (1 - raw.coerceIn(1e-6, 1 - 1e-6)))
            (1.0 / (1.0 + exp(-(l.a * z + l.b)))).toFloat()
        } catch (_: Exception) { null }
    }

    private fun load(): Loaded? {
        val dir = ctx.getExternalFilesDir("models")
        val extModel = dir?.let { File(it, MODEL) }
        if (extModel != null && extModel.isFile && extModel.length() > 0L) {
            val metaText = runCatching { File(dir, META).readText() }.getOrNull()
            build(runCatching { extModel.readBytes() }.getOrNull(), metaText, "ngoài APK")?.let { return it }
        }
        val bytes = runCatching { ctx.assets.open(MODEL).use { it.readBytes() } }.getOrNull()
        val metaText = runCatching { ctx.assets.open(META).use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull()
        return build(bytes, metaText, "trong APK")
    }

    companion object {
        const val MODEL = "deepfake.tflite"
        const val META = "deepfake_meta.json"

        /** Kiểm tra mô hình + meta có dùng được không (không lưu gì). Trả về null nếu hợp lệ, hoặc câu báo lỗi. */
        fun validate(bytes: ByteArray?, metaText: String?): String? {
            val l = build(bytes, metaText, "") ?: return "Tệp không phải mô hình khuôn mặt hợp lệ " +
                "(cần đầu vào [1,H,W,3] float32 và đầu ra 1 hoặc 2 giá trị, và TFLite trong app phải đủ mới để đọc được)."
            l.interp.close()
            return null
        }

        private fun build(bytes: ByteArray?, metaText: String?, source: String): Loaded? {
            if (bytes == null || bytes.isEmpty()) return null
            return try {
                val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
                buf.put(bytes); buf.rewind()
                val it = Interpreter(buf, Interpreter.Options().setNumThreads(2))
                val inT = it.getInputTensor(0)
                val shape = inT.shape()
                if (inT.dataType() != DataType.FLOAT32 || shape.size != 4 || shape[3] != 3 || shape[1] != shape[2] || shape[1] !in 32..512) {
                    it.close(); return null
                }
                val outN = it.getOutputTensor(0).shape().last()
                if (outN != 1 && outN != 2) { it.close(); return null }
                val j = metaText?.let { t -> runCatching { JSONObject(t) }.getOrNull() }
                val platt = j?.optJSONArray("platt")
                var a = platt?.optDouble(0, 1.0)?.toFloat() ?: 1f
                var b = platt?.optDouble(1, 0.0)?.toFloat() ?: 0f
                // Giá trị vô lý (NaN, đảo dấu, quá lớn) -> bỏ hiệu chỉnh, dùng xác suất thô
                if (a.isNaN() || b.isNaN() || a <= 0f || a > 20f || b < -20f || b > 20f) { a = 1f; b = 0f }
                val margin = (j?.optDouble("cropMargin", 0.25) ?: 0.25).toFloat().coerceIn(0f, 0.6f)
                val fi = (j?.optInt("fakeIndex", 1) ?: 1).coerceIn(0, outN - 1)
                Loaded(it, shape[1], outN, fi, a, b, margin, source)
            } catch (_: Throwable) { null }
        }
    }
}
