package vn.scamshield

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.draw.shadow
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Bảng màu "Xanh bảo vệ": nền trắng ngà hơi xanh, thẻ trắng viền mảnh, điểm nhấn xanh lá đậm — sáng, sạch, dễ đọc. */
object C {
    // Nền
    val Bg = Color(0xFFF4F8F6)
    val BgHi = Color(0xFFEAF4EF)
    val Bar = Color(0xFFFFFFFF)
    // Thẻ
    val Card = Color(0xFFFFFFFF)
    val CardHi = Color(0xFFE9F5EF)              // thẻ nhấn nhẹ (xanh bạc hà)
    val Field = Color(0xFFFFFFFF)
    val Fill = Color(0xFFEEF4F1)                // nền nhạt cho chip, nút tròn
    val Stroke = Color(0xFFDDE9E3)              // viền mảnh
    // Điểm nhấn
    val Primary = Color(0xFF0A8A66)             // xanh lá đậm — nút chính, liên kết
    val PrimaryDeep = Color(0xFF077355)
    val Gold = Color(0xFFF2A91B)                // vàng hổ phách: mẹo, cảnh báo nhẹ
    val GoldDeep = Color(0xFFD98A0B)
    val Ink = Color(0xFFFFFFFF)                 // chữ trên nền xanh đậm
    val Mint = Color(0xFF12A06F)
    val Cyan = Color(0xFF0E8A7D)                // teal — dùng cho Cộng đồng
    val Violet = Color(0xFF7C5CE0)
    val Blue = Color(0xFF4F6BDB)
    val Rose = Color(0xFFE0566B)
    // Trạng thái
    val Ok = Color(0xFF12A06F)
    val Warn = Color(0xFFD98A0B)
    val Bad = Color(0xFFDC4B4B)
    // Chữ
    val Text = Color(0xFF0F3D32)                // xanh rêu đậm — tiêu đề, nội dung chính
    val Body = Color(0xFF2B4A41)
    val Sub = Color(0xFF4D6860)
    val Dim = Color(0xFF6F847C)
    val Faint = Color(0xFFA3B4AD)
    // Tương thích tên màu cũ
    val Brown get() = Card
    val Tile get() = Mint
    val Label get() = Mint
    val Teal get() = Cyan
    val LoginBg get() = BgHi
    val Blob get() = CardHi

    val goldGrad = listOf(Primary, PrimaryDeep)
}

/** Co nhẹ khi nhấn — cảm giác bấm mượt cho thẻ, ô danh mục. */
@Composable fun Pressable(onClick: () -> Unit, modifier: Modifier = Modifier, scale: Float = 0.97f, content: @Composable () -> Unit) {
    val itn = remember { MutableInteractionSource() }
    val pressed by itn.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) scale else 1f, tween(120), label = "press")
    Box(modifier.graphicsLayer { scaleX = s; scaleY = s }.clickable(interactionSource = itn, indication = null, onClick = onClick)) { content() }
}

/** Phồng/xẹp nhẹ lặp lại — dùng cho khiên đang hoạt động. */
@Composable fun Modifier.pulse(min: Float = 1f, max: Float = 1.07f, dur: Int = 1100): Modifier {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(min, max, infiniteRepeatable(tween(dur), RepeatMode.Reverse), label = "pulseS")
    return this.graphicsLayer { scaleX = s; scaleY = s }
}

/** Khiên bo tròn mềm trên nền bạc hà, dùng ở trang đăng nhập (kích thước lớn). */
@Composable fun ShieldBadge(tint: Color = C.Primary, size: Dp = 56.dp, pulseOn: Boolean = true) {
    val m = if (pulseOn) Modifier.pulse(0.96f, 1.04f, 1600) else Modifier
    Box(m.size(size * 1.5f), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(tint.copy(alpha = 0.20f), Color.Transparent))))
        Box(Modifier.size(size).background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.92f), tint)), RoundedCornerShape(size * 0.32f))
            .border(3.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(size * 0.32f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Shield, null, tint = Color.White, modifier = Modifier.size(size * 0.52f))
        }
    }
}

/**
 * Biểu tượng Trợ lý AI — vẫn là con chatbot (robot) quen thuộc, nhưng tròn trịa, có gradient tím-xanh,
 * tia sáng nhỏ ở góc và nhấp nhô nhẹ nhàng nên trông thân thiện, như đang vẫy chào người dùng.
 */
@Composable fun AiBotBadge(size: Dp = 42.dp, animate: Boolean = true) {
    val t = rememberInfiniteTransition(label = "bot")
    val bob by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "bobY")
    val y = if (animate) (-1.5f + 3f * bob).dp else 0.dp
    Box(Modifier.size(size)) {
        Box(Modifier.align(Alignment.Center).offset(y = y).size(size * 0.92f)
            .background(Brush.linearGradient(listOf(Color(0xFF8B7CF6), Color(0xFF4F8DF7))), RoundedCornerShape(size * 0.34f)),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.SmartToy, null, tint = Color.White, modifier = Modifier.size(size * 0.54f))
        }
        Box(Modifier.align(Alignment.TopEnd).size(size * 0.36f).background(Color.White, CircleShape)
            .border(1.dp, Color(0xFFFFE3A3), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = Color(0xFFF2A91B), modifier = Modifier.size(size * 0.22f))
        }
    }
}

/** Thẻ nội dung chuẩn: nền trắng, viền mảnh, bo 20dp. */
@Composable fun CardX(modifier: Modifier = Modifier, bg: Color = C.Card, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.fillMaxWidth().background(bg, RoundedCornerShape(20.dp)).border(1.dp, C.Stroke, RoundedCornerShape(20.dp)).padding(16.dp),
        Arrangement.spacedBy(10.dp), content = content)

/** Biểu tượng bo vuông mềm nền màu nhạt — dùng làm đầu đề mục, hàng cài đặt, ô tính năng. */
@Composable fun IconBadge(icon: ImageVector, tint: Color, size: Dp = 42.dp, iconSize: Dp = 21.dp) =
    Box(Modifier.size(size).background(tint.copy(alpha = 0.13f), RoundedCornerShape(size * 0.32f)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(iconSize))
    }

/** Nút chính xanh lá đậm, bo 16dp, cao 52dp. */
@Composable fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, leading: ImageVector? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Button(onClick, modifier.fillMaxWidth().height(52.dp), enabled = enabled, shape = shape, contentPadding = PaddingValues(horizontal = 16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = C.Primary, contentColor = Color.White,
            disabledContainerColor = C.Primary.copy(alpha = 0.35f), disabledContentColor = Color.White.copy(alpha = 0.85f))) {
        if (leading != null) { Icon(leading, null, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
    }
}
/** Tên cũ — giữ lại để các màn khác vẫn dùng được. */
@Composable fun GoldButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, leading: ImageVector? = null, onClick: () -> Unit) =
    PrimaryButton(text, modifier, enabled, leading, onClick)

/** Nút phụ viền mảnh nền trắng. */
@Composable fun GhostButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, leading: ImageVector? = null, onClick: () -> Unit) =
    OutlinedButton(onClick, modifier.fillMaxWidth().height(48.dp), enabled = enabled, shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (enabled) Color(0xFFC9DDD3) else C.Stroke),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White, contentColor = C.Primary, disabledContentColor = C.Faint)) {
        if (leading != null) { Icon(leading, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }

/** Nút dừng/hành động nguy (đỏ). */
@Composable fun DangerButton(text: String, modifier: Modifier = Modifier, leading: ImageVector? = null, onClick: () -> Unit) =
    Button(onClick, modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = C.Bad, contentColor = Color.White)) {
        if (leading != null) { Icon(leading, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }

/** Ô nhập sáng, viền xanh khi focus, icon đầu dòng, có thể thêm nút cuối dòng (ví dụ hiện/ẩn mật khẩu). */
@Composable fun PillField(
    value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier,
    password: Boolean = false, leading: ImageVector? = null, keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    trailing: (@Composable () -> Unit)? = null, showText: Boolean = false
) {
    val itn = remember { MutableInteractionSource() }
    val focused by itn.collectIsFocusedAsState()
    val shape = RoundedCornerShape(16.dp)
    BasicTextField(value, onChange, modifier, singleLine = true,
        textStyle = TextStyle(color = C.Text, fontSize = 15.sp),
        keyboardOptions = keyboardOptions,
        visualTransformation = if (password && !showText) PasswordVisualTransformation() else VisualTransformation.None,
        cursorBrush = SolidColor(C.Primary),
        interactionSource = itn,
        decorationBox = { inner ->
            Row(Modifier.fillMaxWidth().height(52.dp).background(C.Field, shape)
                .border(if (focused) 1.6.dp else 1.dp, if (focused) C.Primary else C.Stroke, shape).padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (leading != null) Icon(leading, null, tint = if (focused) C.Primary else C.Dim, modifier = Modifier.size(20.dp))
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(hint, color = C.Dim, fontSize = 14.sp, maxLines = 1)
                    inner()
                }
                if (trailing != null) trailing()
            }
        })
}

/** Tiêu đề khối + nút hành động "Xem tất cả". */
@Composable fun SectionHeader(title: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) =
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(title, color = C.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        if (actionLabel != null && onAction != null)
            Text(actionLabel, color = C.Primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(onClick = onAction).padding(start = 8.dp, top = 4.dp, bottom = 4.dp))
    }

/** Chip lọc (Tất cả / Cảnh báo / Đã chặn…). */
@Composable fun SelChip(label: String, on: Boolean, onClick: () -> Unit) =
    Box(Modifier.background(if (on) C.Primary else Color.White, RoundedCornerShape(20.dp))
        .border(1.dp, if (on) Color.Transparent else C.Stroke, RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(label, color = if (on) Color.White else C.Sub, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
    }

/** Chip trạng thái Bật/Tắt. */
@Composable fun StatusPill(on: Boolean, onText: String = "Bật", offText: String = "Tắt") =
    Box(Modifier.background(if (on) C.Mint.copy(alpha = 0.14f) else C.Fill, RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(if (on) onText else offText, color = if (on) C.Primary else C.Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }

/** Ô tính năng ở Trang chủ: thẻ trắng, biểu tượng bo vuông mềm phía trên, tên bên dưới. `leading` cho phép thay biểu tượng (ví dụ con chatbot AI). */
@Composable fun FeatureCard(modifier: Modifier = Modifier, icon: ImageVector, label: String, tint: Color, onClick: () -> Unit, leading: (@Composable () -> Unit)? = null) {
    Pressable(onClick, modifier) {
        Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).border(1.dp, C.Stroke, RoundedCornerShape(18.dp))
            .padding(horizontal = 14.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (leading != null) leading() else IconBadge(icon, tint, 40.dp, 21.dp)
            Text(label, color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 18.sp)
        }
    }
}

/** Hàng đề xuất: biểu tượng, tiêu đề, dòng phụ, mũi tên. */
@Composable fun RowCard(icon: ImageVector, title: String, sub: String, tint: Color, onClick: () -> Unit) {
    Pressable(onClick) {
        Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).border(1.dp, C.Stroke, RoundedCornerShape(18.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            IconBadge(icon, tint, 48.dp, 24.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = C.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, lineHeight = 19.sp)
                Text(sub, color = C.Dim, fontSize = 12.5.sp, maxLines = 1)
            }
            Icon(Icons.Rounded.ArrowForward, null, tint = C.Primary, modifier = Modifier.size(20.dp))
        }
    }
}

/** Ô số liệu nhanh: icon + số đếm cạnh nhau, nhãn bên dưới. */
@Composable fun StatCard(value: Int, label: String, icon: ImageVector, tint: Color, modifier: Modifier = Modifier) =
    Column(modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp))
        .border(1.dp, C.Stroke, RoundedCornerShape(18.dp)).padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
            Text("$value", color = C.Text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        }
        Text(label, color = C.Dim, fontSize = 12.sp, maxLines = 1)
    }

/** Banner mẹo an toàn nền vàng nhạt. */
@Composable fun TipBanner(text: String) =
    Row(Modifier.fillMaxWidth().background(Color(0xFFFFF6E0), RoundedCornerShape(18.dp))
        .border(1.dp, Color(0xFFFBE2A6), RoundedCornerShape(18.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        IconBadge(Icons.Rounded.Lightbulb, C.GoldDeep, 38.dp, 19.dp)
        Text(text, color = Color(0xFF5E4A14), fontSize = 12.5.sp, lineHeight = 17.sp)
    }

/** Thanh điểm rủi ro có animation chạy tới giá trị. */
@Composable fun ScoreBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(650), label = "score")
    Box(modifier.fillMaxWidth().height(8.dp).background(C.Fill, RoundedCornerShape(4.dp))) {
        if (f > 0.005f) Box(Modifier.fillMaxHeight().fillMaxWidth(f)
            .background(Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.72f))), RoundedCornerShape(4.dp)))
    }
}

/** Nút tròn trắng viền mảnh (quay lại, chuông thông báo). */
@Composable fun RoundIconButton(icon: ImageVector, onClick: () -> Unit, size: Dp = 44.dp, dot: Boolean = false) {
    Box(Modifier.size(size)) {
        Box(Modifier.fillMaxSize().background(Color.White, RoundedCornerShape(size * 0.34f)).border(1.dp, C.Stroke, RoundedCornerShape(size * 0.34f))
            .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = C.Text, modifier = Modifier.size(size * 0.48f))
        }
        if (dot) Box(Modifier.align(Alignment.TopEnd).padding(top = 9.dp, end = 9.dp).size(9.dp).background(Color(0xFFF59E0B), CircleShape).border(1.5.dp, Color.White, CircleShape))
    }
}


// ───────────────────────── Hình nền ─────────────────────────

/** Nền app: sáng, nhẹ nhàng — gradient trắng ngà xanh + quầng bạc hà mờ ở góc trên. Vẽ tĩnh một lần nên rất nhẹ máy. */
@Composable fun AppBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFFEFF7F3), C.Bg, Color(0xFFF7FAF8))))
        val r = 320.dp.toPx()
        val c1 = androidx.compose.ui.geometry.Offset(size.width * 0.95f, size.height * 0.02f)
        drawCircle(Brush.radialGradient(listOf(Color(0xFFBFE8D6).copy(alpha = 0.55f), Color.Transparent), c1, r), r, c1)
        val c2 = androidx.compose.ui.geometry.Offset(size.width * 0.02f, size.height * 0.55f)
        drawCircle(Brush.radialGradient(listOf(Color(0xFFD6EFE3).copy(alpha = 0.45f), Color.Transparent), c2, r * 0.9f), r * 0.9f, c2)
    }
}


// ───────────────────────── Theme dùng chung cho mọi Activity ─────────────────────────

/** Bộ màu Material sáng của app — dùng cho MainActivity và các màn quét camera để giao diện đồng bộ. */
@Composable fun ShieldTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = lightColorScheme(
    primary = C.Primary, onPrimary = Color.White,
    primaryContainer = C.CardHi, onPrimaryContainer = C.Text,
    secondary = C.Mint, onSecondary = Color.White,
    tertiary = C.Cyan,
    background = C.Bg, onBackground = C.Text,
    surface = C.Card, onSurface = C.Text,
    surfaceVariant = C.Fill, onSurfaceVariant = C.Sub,
    outline = Color(0xFFC9DDD3),
    outlineVariant = C.Stroke,
    error = C.Bad, onError = Color.White
), content = content)

/** Thanh trạng thái/điều hướng cùng màu nền app, icon hệ thống màu tối. */
fun android.app.Activity.applyShieldWindow() {
    window.statusBarColor = C.Bg.toArgb()
    window.navigationBarColor = C.Bg.toArgb()
    window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(C.Bg.toArgb()))
    WindowCompat.getInsetsController(window, window.decorView).apply { isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true }
}

/** Nút Trợ lý AI nổi ở góc phải dưới: con chatbot duy nhất của app, chạm để hỏi AI. */
@Composable fun FloatingBot(modifier: Modifier = Modifier, onClick: () -> Unit) {
    Pressable(onClick, modifier, 0.92f) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(60.dp)
                .shadow(10.dp, CircleShape, ambientColor = Color(0x40403C9E), spotColor = Color(0x40403C9E))
                .background(Color.White, CircleShape).border(1.dp, Color(0xFFE3E0FA), CircleShape), contentAlignment = Alignment.Center) {
                AiBotBadge(46.dp)
            }
            Text("Hỏi AI", color = C.Blue, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
        }
    }
}
