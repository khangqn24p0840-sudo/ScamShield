package vn.scamshield
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import vn.scamshield.face.FaceBus
import vn.scamshield.face.FaceLevel

/** Thẻ kính tối chuẩn dùng cho các panel. */
@Composable fun Glass(content: @Composable ColumnScope.() -> Unit) = CardX(content = content)

/** Ảnh người dùng vừa chọn để kiểm tra (bản thu nhỏ chỉ để hiển thị; ảnh gốc mới được gửi đi). */
object AiPreview { var bmp by mutableStateOf<android.graphics.Bitmap?>(null) }

fun err(j: JSONObject?) = j?.optString("error")?.takeIf { it.isNotEmpty() } ?: "Không kết nối được máy chủ"

fun errMsg(code: Int, j: JSONObject?) = "Lỗi" + (if (code > 0) " (mã $code)" else "") + ": " + err(j)

fun fmtText(code: Int, j: JSONObject?): String {
    if (code !in 200..299 || j == null) return errMsg(code, j)
    val r = j.optJSONArray("reasons") ?: JSONArray()
    val rs = (0 until r.length()).joinToString("\n") { "• " + r.getString(it) }
    val lbl = when (j.optString("label")) { "scam" -> "Rất có thể là lừa đảo"; "safe" -> "Có vẻ an toàn"; else -> "Đáng ngờ" }
    return "$lbl (${j.optInt("risk")}/100)\n$rs\n${j.optString("advice")}"
}

fun fmtMedia(code: Int, j: JSONObject?): String {
    if (code !in 200..299 || j == null) return errMsg(code, j)
    // Máy chủ trả 200 nhưng thiếu trường 'verdict' (sai phiên bản?) -> nói rõ thay vì hiện nhầm "ảnh thật (0%)"
    if (!j.has("verdict")) return "Máy chủ trả về kết quả không đúng định dạng: " + j.toString().take(200)
    val v = when (j.optString("verdict")) { "likely_fake" -> "Nhiều khả năng ảnh bị làm giả"; "uncertain" -> "Chưa chắc chắn"; else -> "Nhiều khả năng ảnh thật" }
    return "$v (${(j.optDouble("score") * 100).toInt()}%)\n${j.optString("note")}"
}


@Composable fun PersonalizationOnboarding(c: Context, onDone: () -> Unit) {
    val qs = listOf(
        "Bạn nhận cuộc gọi từ số lạ thường xuyên không?" to listOf("Hiếm", "Thỉnh thoảng", "Hằng ngày"),
        "Bạn thường quét mã QR hoặc thanh toán trực tuyến không?" to listOf("Hiếm", "Thỉnh thoảng", "Thường xuyên"),
        "Bạn từng gặp tình huống lừa đảo chưa?" to listOf("Chưa", "Suýt bị", "Đã gặp"),
        "Kênh bạn dễ bị tiếp cận nhất" to listOf("Cuộc gọi", "SMS", "Zalo/Messenger", "Mạng xã hội khác"),
        "Mức tự tin nhận biết lừa đảo" to listOf("Thấp", "Vừa", "Cao")
    )
    val sel = remember { mutableStateListOf("", "", "", "", "") }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ShieldBadge(C.Primary, 64.dp)
        Text("Thiết lập ScamShield cho bạn", color = C.Text, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text("Khảo sát nhanh khoảng 1 phút. Kết quả được lưu trên thiết bị để ưu tiên các lớp bảo vệ phù hợp với thói quen của bạn.", color = C.Sub, fontSize = 13.sp, lineHeight = 18.sp)
        Text("Bạn có thể thay đổi lại trong Cài đặt bất cứ lúc nào.", color = C.Dim, fontSize = 12.sp)
        qs.forEachIndexed { i, (q, opts) ->
            CardX(bg = C.CardHi) {
                Text(q, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = C.Text)
                opts.forEach { o ->
                    Row(Modifier.fillMaxWidth().clickable { sel[i] = o }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sel[i] == o, onClick = { sel[i] = o })
                        Text(o, fontSize = 13.5.sp, color = C.Sub)
                    }
                }
            }
        }
        GoldButton("Hoàn tất thiết lập", leading = Icons.Rounded.CheckCircle, enabled = sel.all { it.isNotEmpty() }) {
            Personalization.save(c, sel.toList())
            onDone()
        }
        GhostButton("Bỏ qua lúc này", leading = Icons.Rounded.SkipNext) {
            // Không tạo hồ sơ cá nhân hóa; người dùng có thể làm lại trong Cài đặt.
            Store.putFlag(c, "personalization_done", true)
            onDone()
        }
        if (msg.isNotEmpty()) Text(msg, color = C.Warn, fontSize = 12.sp)
    }
}

@Composable fun SurveyPanel(c: Context) {
    val qs = listOf("Nhóm tuổi của bạn" to listOf("Dưới 18", "18–30", "31–50", "Trên 50"),
        "Bạn nhận cuộc gọi từ số lạ thường xuyên không?" to listOf("Hiếm", "Thỉnh thoảng", "Hằng ngày"),
        "Bạn từng bị lừa chưa?" to listOf("Chưa", "Suýt bị", "Đã mất tiền"),
        "Kênh bạn dễ bị tiếp cận nhất" to listOf("Cuộc gọi", "SMS", "Zalo/Messenger", "Mạng xã hội khác"),
        "Mức tự tin nhận biết lừa đảo" to listOf("Thấp", "Vừa", "Cao"))
    val sel = remember { mutableStateListOf("", "", "", "", "") }
    var msg by remember { mutableStateOf("") }
    Glass {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconBadge(Icons.Rounded.FactCheck, C.Primary)
            Text("Khảo sát nhanh (5 câu)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = C.Text)
        }
        qs.forEachIndexed { i, (q, opts) ->
            Text(q, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = C.Text)
            opts.forEach { o -> Row(Modifier.fillMaxWidth().clickable { sel[i] = o }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(sel[i] == o, { sel[i] = o }); Text(o, fontSize = 14.sp, color = C.Sub) } }
        }
        GoldButton("Gửi khảo sát", leading = Icons.Rounded.Send, enabled = sel.all { it.isNotEmpty() }) {
            Api.call(c, "POST", "/api/survey", JSONObject().put("answers", JSONArray(sel.toList()))) { code, j ->
                msg = if (code in 200..299) "Cảm ơn bạn đã tham gia!" else err(j) + " (cần đăng nhập trước)" }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.Warn)
    }
}

@Composable fun AiPanel(c: Context, aiMsg: String, onPick: () -> Unit, onMsg: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    Glass {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AiBotBadge(44.dp)
            Text("Trợ lý AI — phân tích giúp bạn", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = C.Text)
        }
        Text("Cần đăng nhập. Chỉ nội dung bạn bấm phân tích mới được gửi lên máy chủ của bạn để AI đánh giá.", fontSize = 12.sp, color = C.Sub, lineHeight = 16.sp)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = { Text("Dán tin nhắn / lời thoại nghi ngờ…") }, minLines = 3)
        GoldButton("Phân tích nội dung bằng AI", enabled = text.isNotBlank(), leading = Icons.Rounded.Bolt) {
            onMsg("Đang phân tích…"); Api.call(c, "POST", "/api/analyze/text", JSONObject().put("text", text)) { code, j -> onMsg(fmtText(code, j)) }
        }
        GhostButton("Kiểm tra ảnh có bị làm giả (qua máy chủ)", leading = Icons.Rounded.Image, onClick = onPick)
        AiPreview.bmp?.let { b ->
            androidx.compose.foundation.Image(b.asImageBitmap(), null,
                Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(12.dp)),
                contentScale = androidx.compose.ui.layout.ContentScale.Fit)
        }
        if (aiMsg.startsWith("Đang")) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (aiMsg.isNotEmpty()) Text(aiMsg, fontSize = 14.sp, color = C.Text, lineHeight = 19.sp)
    }
}

@Composable fun FacePanel(onStart: () -> Unit, onStop: () -> Unit, onPickVideo: () -> Unit, onCamera: () -> Unit) {
    val v = FaceBus.verdict
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var logOn by remember { mutableStateOf(Store.flag(ctx, "face_log")) }
    var importMsg by remember { mutableStateOf("") }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) importMsg = vn.scamshield.face.FaceModelImport.import(ctx, uris) }
    Glass {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconBadge(Icons.Rounded.Videocam, C.Violet)
            Column {
                Text("Kiểm tra video call giả mạo", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = C.Text)
                Text("Tính năng thử nghiệm", color = C.Dim, fontSize = 11.sp)
            }
        }
        Text("Khi đang video call, bật chế độ này: app quan sát màn hình, đo các chỉ báo trên khuôn mặt và cảnh báo nếu nghi giả mạo. Chỉ xử lý trong máy, không lưu hình. Kết quả chỉ là chỉ báo, không phải kết luận.",
            fontSize = 12.sp, color = C.Sub, lineHeight = 17.sp)
        PrimaryButton("Quét trực tiếp bằng camera", leading = Icons.Rounded.CameraAlt, onClick = onCamera)
        GhostButton("Chọn video trong điện thoại", leading = Icons.Rounded.VideoLibrary, onClick = onPickVideo)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Ghi số liệu để hiệu chỉnh", fontSize = 13.sp, color = C.Text)
                Text("Chỉ lưu điểm các chỉ báo (con số) trong máy, không có hình. Có hiệu lực từ lần kiểm tra kế tiếp.", fontSize = 11.sp, color = C.Dim, lineHeight = 15.sp)
            }
            Switch(logOn, { logOn = it; Store.putFlag(ctx, "face_log", it) })
        }
        GhostButton("Nạp mô hình khuôn mặt từ tệp", leading = Icons.Rounded.Download) { picker.launch(arrayOf("*/*")) }
        if (importMsg.isNotEmpty()) Text(importMsg, fontSize = 12.sp, color = C.Sub, lineHeight = 16.sp)
        if (FaceBus.running && FaceBus.modelStatus.isNotEmpty()) Text(FaceBus.modelStatus, fontSize = 11.sp, color = C.Dim, lineHeight = 15.sp)
        if (FaceBus.running) DangerButton("Dừng kiểm tra", leading = Icons.Rounded.Stop, onClick = onStop)
        else GoldButton("Bắt đầu kiểm tra video call", leading = Icons.Rounded.PlayArrow, onClick = onStart)
        if (FaceBus.running && v != null) {
            val col = when (v.level) { FaceLevel.HIGH -> C.Bad; FaceLevel.SUSPICIOUS -> C.Warn; FaceLevel.OK -> C.Mint; else -> C.Text }
            Text(v.headline, color = col, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (v.progress < 1f) {
                Text("Tiến độ thu thập: ${(v.progress * 100).toInt()}%", fontSize = 12.sp, color = C.Sub)
                ScoreBar(v.progress, C.Primary)
            } else {
                Text("Điểm rủi ro: ${(v.probability * 100).toInt()}% • ${"%.0f".format(v.fps)} khung/giây", fontSize = 12.sp, color = C.Sub)
                ScoreBar(v.probability.toFloat(), col)
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                v.indicators.forEach { ind ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.size(4.dp).background(col, CircleShape))
                        Text("${ind.label}: ${ind.detail}", fontSize = 12.sp, color = C.Sub)
                    }
                }
            }
            if (v.advice.isNotEmpty()) Text(v.advice, fontSize = 12.sp, color = C.Dim, lineHeight = 16.sp)
        }
    }
}

/** Tải danh sách số lừa đảo cộng đồng từ máy chủ (app tự thêm dấu + trước mỗi số). */
fun syncCommunity(c: Context, onMsg: (String) -> Unit) {
    onMsg("Đang tải…")
    Api.call(c, "GET", "/api/blocklist", null) { code, j ->
        if (code == 200 && j != null) {
            val a = j.optJSONArray("numbers") ?: JSONArray()
            for (i in 0 until a.length()) Store.addBlock(c, "+" + a.getString(i))
            onMsg("Đã thêm ${a.length()} số lừa đảo từ cộng đồng")
        } else onMsg(err(j))
    }
}