package vn.scamshield

import android.content.Context
import java.io.File
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Mô hình học máy TFLite đọc tin nhắn/lời thoại và trả xác suất "giống lừa đảo" (0..1).
 * Model ưu tiên: <externalFilesDir>/models/scam_text.tflite.
 * Nếu không có model ngoài hoặc model ngoài lỗi, dùng assets/scam_text.tflite làm dự phòng.
 * Cách tính đặc trưng PHẢI giống ml/features.py.
 */
object TextModel {
    private const val DIM = 4096
    private const val ASSET = "scam_text.tflite"
    private const val EXTERNAL_DIR = "models"
    private const val EXTERNAL_FILE = "scam_text.tflite"
    private const val EXTERNAL_VERSION = "scam_text.version"
    private val TOKEN = Regex("[a-z0-9]+")
    private var appCtx: Context? = null
    private var interp: Interpreter? = null
    private var tried = false
    private var loadedExternalStamp: Long = Long.MIN_VALUE
    private var loadedExternalSize: Long = -1L

    /** Trạng thái để kiểm tra khi gỡ lỗi: "chưa nạp" | "đã nạp" | "lỗi: ..." */
    @Volatile var status = "chưa nạp"
        private set

    fun init(c: Context) {
        appCtx = c.applicationContext
        // Warm-up trên background thread: nạp model sẵn để lần gọi predict() đầu tiên không bị delay
        Thread {
            load()
        }.also { it.isDaemon = true; it.start() }
    }

    /**
     * Nạp model theo thứ tự ưu tiên:
     * 1) model bên ngoài APK: <externalFilesDir>/models/scam_text.tflite
     * 2) model dự phòng trong assets/scam_text.tflite
     *
     * Model bên ngoài có thể được thay thế mà không cần build lại APK.
     * Nếu file bên ngoài thay đổi trong lúc app đang chạy, lần predict() tiếp theo
     * sẽ tự nạp lại model mới.
     */
    @Synchronized private fun load(): Interpreter? {
        val c = appCtx ?: return null
        val externalDir = c.getExternalFilesDir(EXTERNAL_DIR)
        val external = externalDir?.let { File(it, EXTERNAL_FILE) }

        // Nếu đã có model ngoài và chưa thay đổi, dùng interpreter hiện tại.
        if (external != null && external.isFile && external.length() > 0L) {
            val stamp = external.lastModified()
            val size = external.length()
            if (interp != null && loadedExternalStamp == stamp && loadedExternalSize == size) {
                return interp
            }

            try {
                val bytes = external.readBytes()
                val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
                buf.put(bytes); buf.rewind()
                interp?.close()
                interp = Interpreter(buf, Interpreter.Options().setNumThreads(2))
                loadedExternalStamp = stamp
                loadedExternalSize = size
                tried = true
                status = "đã nạp model bên ngoài"
                return interp
            } catch (e: Throwable) {
                interp?.close()
                interp = null
                status = "model bên ngoài lỗi: ${e.message}; thử model trong app"
                // Tiếp tục xuống fallback assets.
            }
        }

        if (tried && interp != null && loadedExternalStamp == Long.MIN_VALUE) return interp
        tried = true
        try {
            val bytes = c.assets.open(ASSET).use { it.readBytes() }
            val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            buf.put(bytes); buf.rewind()
            interp?.close()
            interp = Interpreter(buf, Interpreter.Options().setNumThreads(2))
            loadedExternalStamp = Long.MIN_VALUE
            loadedExternalSize = -1L
            status = "đã nạp model trong app (dự phòng)"
        } catch (e: Throwable) {
            interp = null; status = "lỗi: ${e.message}"
        }
        return interp
    }

    private fun hash(s: String): Int {
        var h = 0x811C9DC5L
        for (b in s.toByteArray(Charsets.UTF_8)) { h = h xor (b.toLong() and 0xFF); h = (h * 0x01000193L) and 0xFFFFFFFFL }
        return (h % DIM).toInt()
    }

    // features() là pure function — không mutate shared state, an toàn khi gọi song song
    fun features(text: String): FloatArray {
        val words = TOKEN.findAll(ScamDetector.norm(text.take(2000))).map { it.value }.toList()
        // Dùng local map tránh race condition nếu nhiều luồng gọi song song
        val counts = HashMap<Int, Int>(words.size * 2)
        fun add(f: String) { val i = hash(f); counts[i] = (counts[i] ?: 0) + 1 }
        for (i in words.indices) {
            add("u:" + words[i])
            if (i + 1 < words.size) add("b:" + words[i] + " " + words[i + 1])
        }
        val x = FloatArray(DIM)
        var ss = 0.0
        for ((i, cnt) in counts) { val v = ln(1.0 + cnt).toFloat(); x[i] = v; ss += v.toDouble() * v }
        val n = sqrt(ss).toFloat()
        if (n > 0f) for (i in counts.keys) x[i] /= n
        return x
    }


    /** Import a user-selected TFLite model into the app-specific external model folder. */
    @Synchronized fun importExternalModel(source: java.io.InputStream): Boolean {
        val c = appCtx ?: return false
        return try {
            val dir = c.getExternalFilesDir(EXTERNAL_DIR) ?: throw IllegalStateException("Không tạo được thư mục model")
            if (!dir.exists()) dir.mkdirs()
            val target = File(dir, EXTERNAL_FILE)
            val temp = File(dir, EXTERNAL_FILE + ".tmp")
            source.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
            if (temp.length() <= 0L) throw IllegalStateException("File model rỗng")

            // Validate by opening the model before replacing the active model.
            val bytes = temp.readBytes()
            val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            buf.put(bytes); buf.rewind()
            val test = Interpreter(buf, Interpreter.Options().setNumThreads(2))
            test.close()

            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            // Force reload on the next prediction.
            interp?.close()
            interp = null
            loadedExternalStamp = Long.MIN_VALUE
            loadedExternalSize = -1L
            tried = false
            setExternalModelVersion("0")
            status = "đã cập nhật model bên ngoài"
            true
        } catch (e: Throwable) {
            status = "cập nhật model lỗi: ${e.message}"
            false
        }
    }

    fun externalModelFile(): File? = appCtx?.getExternalFilesDir(EXTERNAL_DIR)?.let { File(it, EXTERNAL_FILE) }

    fun externalModelVersion(): String = appCtx?.getExternalFilesDir(EXTERNAL_DIR)
        ?.let { File(it, EXTERNAL_VERSION) }?.takeIf { it.isFile }?.readText()?.trim().orEmpty()

    fun setExternalModelVersion(version: String) {
        appCtx?.getExternalFilesDir(EXTERNAL_DIR)?.let { dir ->
            if (!dir.exists()) dir.mkdirs()
            File(dir, EXTERNAL_VERSION).writeText(version)
        }
    }

    /** Xác suất lừa đảo 0..1, hoặc null nếu chưa có mô hình / lỗi. */
    @Synchronized fun predict(text: String): Float? {
        if (text.isBlank()) return null
        val m = load() ?: return null
        return try {
            val out = Array(1) { FloatArray(1) }
            m.run(arrayOf(features(text)), out)
            out[0][0]
        } catch (e: Throwable) { status = "lỗi: ${e.message}"; null }
    }
}
