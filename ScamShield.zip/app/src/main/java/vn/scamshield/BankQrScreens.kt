package vn.scamshield

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── Kiểm tra số tài khoản ─────────────────────────

@Composable fun AccountScreen(c: Context, back: () -> Unit) {
    var acct by remember { mutableStateOf("") }
    var bank by remember { mutableStateOf<Banks.Bank?>(null) }
    var checked by remember { mutableStateOf<Pair<String, String>?>(null) }
    var rev by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    Page("STK lừa đảo", back) {
        CardX {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconBadge(Icons.Rounded.AccountBalance, C.Gold)
                Text("Kiểm tra số tài khoản", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
            Text("Nhập số tài khoản mà người lạ bảo bạn chuyển tiền vào. App đối chiếu với danh sách trên máy, và với cộng đồng khi bạn bấm hỏi.",
                fontSize = 12.sp, color = C.Sub, lineHeight = 17.sp)
            PillField(acct, { acct = it.filter { ch -> ch.isDigit() || ch == ' ' }.take(30) }, "Số tài khoản", Modifier.fillMaxWidth(),
                leading = Icons.Rounded.AccountBalance, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            BankPicker(bank) { bank = it }
            GhostButton("Dán từ bộ nhớ tạm (tự tìm số tài khoản)", leading = Icons.Rounded.ContentPaste) {
                val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(c)?.toString() ?: ""
                val f = AccountGuard.extract(t).firstOrNull()
                if (f != null) { acct = f.first; if (f.second.isNotEmpty()) bank = Banks.byBin(f.second) }
                else acct = AccountGuard.digits(t).take(19)
            }
            GoldButton("Kiểm tra", enabled = AccountGuard.digits(acct).isNotEmpty(), leading = Icons.Rounded.Search) {
                checked = AccountGuard.digits(acct) to (bank?.bin ?: "")
            }
        }
        checked?.let { (a, b) ->
            if (!AccountGuard.valid(a)) Text("Số tài khoản phải có từ 6 đến 19 chữ số.", color = C.Warn, fontSize = 13.sp)
            else AccountCheckBlock(c, a, b) { rev++ }
        }
        CardX {
            val list = remember(rev) { AccountGuard.entries(c) }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconBadge(Icons.Rounded.Block, C.Bad)
                Text("Danh sách trên máy (${list.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
            Text("Tin nhắn, thông báo hoặc cuộc gọi nhắc tới số trong danh sách này sẽ được cảnh báo ngay.", fontSize = 12.sp, color = C.Sub, lineHeight = 17.sp)
            if (list.isEmpty()) Text("Chưa có số nào.", color = C.Dim, fontSize = 13.sp)
            list.forEach { e ->
                val i = e.indexOf(':')
                Row(Modifier.fillMaxWidth().background(C.Field, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
                    Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(e.substring(i + 1), color = Color.White, fontSize = 14.sp)
                        Text(Banks.name(e.substring(0, i)), color = C.Dim, fontSize = 11.sp)
                    }
                    TextButton({ AccountGuard.remove(c, e); rev++ }) { Text("Bỏ", color = C.Rose, fontSize = 12.sp) }
                }
            }
            GhostButton("Tải danh sách STK lừa đảo từ cộng đồng", leading = Icons.Rounded.Download) {
                AccountGuard.sync(c) { m -> msg = m; rev++ }
            }
            if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.Warn)
        }
    }
}

@Composable private fun BankPicker(sel: Banks.Bank?, onSel: (Banks.Bank?) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        GhostButton(sel?.name ?: "Chọn ngân hàng (không bắt buộc)", Modifier.fillMaxWidth(), leading = Icons.Rounded.AccountBalance) { open = true }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem(text = { Text("Không rõ ngân hàng") }, onClick = { onSel(null); open = false })
            Banks.all.forEach { b -> DropdownMenuItem(text = { Text(b.name) }, onClick = { onSel(b); open = false }) }
        }
    }
}

/** Khối kết quả cho một số tài khoản: danh sách trên máy, hỏi cộng đồng, chặn/bỏ chặn, báo cáo. Dùng cả khi quét QR và khi dán tin nhắn. */
@Composable fun AccountCheckBlock(c: Context, acct: String, bin: String, onChange: () -> Unit = {}) {
    var rev by remember(acct, bin) { mutableIntStateOf(0) }
    var busy by remember(acct, bin) { mutableStateOf(false) }
    var srv by remember(acct, bin) { mutableStateOf<Pair<Int, String>?>(null) }
    var rmsg by remember(acct, bin) { mutableStateOf("") }
    val listed = remember(acct, bin, rev) { AccountGuard.isListed(c, acct, bin) }
    val card = remember(acct) { AccountGuard.looksLikeCard(acct) }
    val phoneHit = remember(acct) { acct.length in 9..11 && Store.isBlocked(c, acct) }
    CardX {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconBadge(Icons.Rounded.AccountBalance, if (listed) C.Bad else C.Gold)
            Column {
                Text(acct, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                Text(Banks.name(bin), fontSize = 12.sp, color = C.Dim)
            }
        }
        if (listed) ResultCard(Result(90, listOf("Số này nằm trong danh sách lừa đảo trên máy bạn")))
        else Text("Chưa có trong danh sách lừa đảo trên máy bạn. Điều này chưa có nghĩa là an toàn.", color = C.Sub, fontSize = 13.sp, lineHeight = 18.sp)
        if (phoneHit) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Rounded.Warning, null, tint = C.Bad, modifier = Modifier.size(18.dp))
            Text("Dãy số này trùng với một số điện thoại bạn đã chặn. Nhiều kẻ lừa đảo dùng số điện thoại làm số tài khoản.",
                color = C.Bad, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
        }

        if (card) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.CreditCard, null, tint = C.Warn, modifier = Modifier.size(18.dp))
                Text("Dãy số này giống SỐ THẺ. Để an toàn, app không lưu và không gửi số thẻ lên máy chủ. Đừng cung cấp số thẻ, CVV hay OTP cho bất kỳ ai.",
                    color = C.Warn, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
            }
        } else {
            GhostButton(if (busy) "Đang hỏi…" else "Hỏi cộng đồng (gửi số này tới máy chủ)", enabled = !busy, leading = Icons.Rounded.Group) {
                busy = true
                AccountGuard.check(c, acct, bin) { code, j ->
                    busy = false
                    srv = if (code == 200 && j != null) {
                        val n = j.optInt("reports")
                        when {
                            j.optBoolean("verified") -> 2 to "Đã xác minh là tài khoản lừa đảo ($n báo cáo)."
                            n > 0 -> 1 to "Có $n người báo cáo, CHƯA xác minh. Hãy cẩn trọng."
                            else -> 0 to "Cộng đồng chưa có báo cáo nào về số này. Điều đó không bảo đảm an toàn."
                        }
                    } else 1 to err(j)
                }
            }
            srv?.let { (lv, t) ->
                val col = listOf(C.Mint, C.Warn, C.Bad)[lv]
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(if (lv == 2) Icons.Rounded.Error else if (lv == 1) Icons.Rounded.Warning else Icons.Rounded.CheckCircle, null,
                        tint = col, modifier = Modifier.size(18.dp))
                    Text(t, color = col, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
                }
            }
            if (!listed) GhostButton("Chặn số này trên máy", leading = Icons.Rounded.Block) { AccountGuard.add(c, acct, bin); rev++; onChange() }
            else GhostButton("Bỏ khỏi danh sách trên máy") { AccountGuard.removeMatching(c, acct, bin); rev++; onChange() }

            DangerButton("Báo cáo tài khoản này là lừa đảo", leading = Icons.Rounded.Flag) {
                if (Store.str(c, "token").isEmpty()) rmsg = "Cần đăng nhập (tab Tài khoản) để báo cáo."
                else {
                    rmsg = "Đang gửi…"
                    AccountGuard.report(c, acct, bin) { code, j -> rmsg = if (code == 200) "Đã gửi báo cáo. Cảm ơn bạn!" else err(j) }
                }
            }
            if (rmsg.isNotEmpty()) Text(rmsg, color = C.Warn, fontSize = 13.sp)
            Text("Báo cáo sai sự thật có thể gây hại cho người vô tội. Chỉ báo cáo khi bạn bị yêu cầu chuyển tiền vào số này và nghi là lừa đảo.",
                fontSize = 11.sp, color = C.Dim, lineHeight = 15.sp)
        }
    }
}

// ───────────────────────── Kiểm tra link / tên miền ─────────────────────────

private data class Exp(val finalUrl: String, val hops: List<String>, val note: String?, val verified: Boolean, val reports: Int)

/** Khối kiểm tra một đường link: chấm điểm trên máy, xem link rút gọn dẫn tới đâu, hỏi cộng đồng, chặn/báo cáo tên miền. */
@Composable fun LinkCheckBlock(c: Context, url: String, showScore: Boolean = true) {
    val host = remember(url) { DomainGuard.hostOf(url) }
    var rev by remember(url) { mutableIntStateOf(0) }
    var commBusy by remember(url) { mutableStateOf(false) }
    var comm by remember(url) { mutableStateOf<Pair<Int, String>?>(null) }
    var expBusy by remember(url) { mutableStateOf(false) }
    var exp by remember(url) { mutableStateOf<Exp?>(null) }
    var expMsg by remember(url) { mutableStateOf("") }
    var rmsg by remember(url) { mutableStateOf("") }
    val listed = remember(url, rev) { DomainGuard.isListed(c, url) }
    val lc = remember(url) { linkCheck(url) }
    if (host.isEmpty()) return
    val short = DomainGuard.isShortener(host)
    CardX {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconBadge(Icons.Rounded.Link, if (listed) C.Bad else C.Blue)
            Column(Modifier.weight(1f)) {
                Text(host, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                Text(url.take(90), fontSize = 11.sp, color = C.Dim, maxLines = 2)
            }
        }
        if (showScore) ResultCard(lc)
        if (listed) Text("Tên miền này nằm trong danh sách lừa đảo trên máy bạn.", color = C.Bad, fontSize = 13.sp, lineHeight = 18.sp)

        GhostButton(if (expBusy) "Đang kiểm tra…" else "Xem link dẫn tới đâu (gửi link tới máy chủ)", enabled = !expBusy, leading = Icons.Rounded.Route) {
            if (Store.str(c, "token").isEmpty()) { expMsg = "Cần đăng nhập (tab Tài khoản) để dùng tính năng này." }
            else {
                expBusy = true; expMsg = ""
                DomainGuard.expand(c, url) { code, j ->
                    expBusy = false
                    if (code == 200 && j != null) {
                        val a = j.optJSONArray("hops")
                        val hops = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }
                        exp = Exp(j.optString("final"), hops, if (j.isNull("note")) null else j.optString("note"),
                            j.optBoolean("verified"), j.optInt("reports"))
                    } else expMsg = err(j)
                }
            }
        }
        if (expMsg.isNotEmpty()) Text(expMsg, color = C.Warn, fontSize = 13.sp)
        exp?.let { e ->
            val n = e.hops.size - 1
            Text(if (n <= 0) "Link không chuyển hướng đi đâu." else "Qua $n lần chuyển hướng, đích đến cuối cùng là:", color = C.Sub, fontSize = 12.sp)
            Text(e.finalUrl.take(300), color = Color.White, fontSize = 13.sp, lineHeight = 18.sp)
            if (e.hops.size > 2) e.hops.forEach { Text("→ " + it.take(100), color = C.Dim, fontSize = 11.sp) }
            e.note?.let { Text(it, color = C.Warn, fontSize = 12.sp) }
            val bad = e.verified || DomainGuard.isListed(c, e.finalUrl)
            if (bad) Text("Tên miền đích đã bị xác minh là lừa đảo.", color = C.Bad, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            else if (e.reports > 0) Text("Có ${e.reports} người báo cáo tên miền đích (chưa xác minh).", color = C.Warn, fontSize = 13.sp)
            if (n > 0) { val fr = remember(e.finalUrl) { linkCheck(e.finalUrl) }; ResultCard(fr) }
            if (n > 0) LinkCheckBlockActions(c, e.finalUrl)
        }

        if (short) {
            Text("Đây là dịch vụ rút gọn link nên không thể chặn cả tên miền. Hãy xem link dẫn tới đâu rồi chặn hoặc báo cáo tên miền đích.",
                color = C.Dim, fontSize = 11.5.sp, lineHeight = 16.sp)
        } else {
            GhostButton(if (commBusy) "Đang hỏi…" else "Hỏi cộng đồng về tên miền này", enabled = !commBusy, leading = Icons.Rounded.Group) {
                commBusy = true
                DomainGuard.check(c, url) { code, j ->
                    commBusy = false
                    comm = if (code == 200 && j != null) {
                        val n = j.optInt("reports")
                        when {
                            j.optBoolean("verified") -> 2 to "Tên miền đã được xác minh là lừa đảo ($n báo cáo)."
                            n > 0 -> 1 to "Có $n người báo cáo tên miền này, CHƯA xác minh."
                            else -> 0 to "Cộng đồng chưa có báo cáo nào về tên miền này. Điều đó không bảo đảm an toàn."
                        }
                    } else 1 to err(j)
                }
            }
            comm?.let { (lv, t) -> Text(t, color = listOf(C.Mint, C.Warn, C.Bad)[lv], fontSize = 13.sp, lineHeight = 18.sp) }
            if (!listed) GhostButton("Chặn tên miền này trên máy", leading = Icons.Rounded.Block) { DomainGuard.add(c, url); rev++ }
            else GhostButton("Bỏ chặn tên miền này") { DomainGuard.removeMatching(c, url); rev++ }
            DangerButton("Báo cáo tên miền này là lừa đảo", leading = Icons.Rounded.Flag) {
                if (Store.str(c, "token").isEmpty()) rmsg = "Cần đăng nhập (tab Tài khoản) để báo cáo."
                else { rmsg = "Đang gửi…"; DomainGuard.report(c, url) { code, j -> rmsg = if (code == 200) "Đã gửi báo cáo. Cảm ơn bạn!" else err(j) } }
            }
            if (rmsg.isNotEmpty()) Text(rmsg, color = C.Warn, fontSize = 13.sp)
        }
    }
}

/** Nút chặn/báo cáo cho tên miền ĐÍCH sau khi mở link rút gọn. */
@Composable private fun LinkCheckBlockActions(c: Context, finalUrl: String) {
    var rev by remember(finalUrl) { mutableIntStateOf(0) }
    var rmsg by remember(finalUrl) { mutableStateOf("") }
    val listed = remember(finalUrl, rev) { DomainGuard.isListed(c, finalUrl) }
    if (DomainGuard.hostOf(finalUrl).isEmpty() || DomainGuard.isShortener(DomainGuard.hostOf(finalUrl))) return
    if (!listed) GhostButton("Chặn tên miền đích trên máy", leading = Icons.Rounded.Block) { DomainGuard.add(c, finalUrl); rev++ }
    else GhostButton("Bỏ chặn tên miền đích") { DomainGuard.removeMatching(c, finalUrl); rev++ }
    DangerButton("Báo cáo tên miền đích là lừa đảo", leading = Icons.Rounded.Flag) {
        if (Store.str(c, "token").isEmpty()) rmsg = "Cần đăng nhập (tab Tài khoản) để báo cáo."
        else { rmsg = "Đang gửi…"; DomainGuard.report(c, finalUrl) { code, j -> rmsg = if (code == 200) "Đã gửi báo cáo. Cảm ơn bạn!" else err(j) } }
    }
    if (rmsg.isNotEmpty()) Text(rmsg, color = C.Warn, fontSize = 13.sp)
}

/** Tự tìm số tài khoản và link trong một đoạn văn bản (tin nhắn người dùng dán vào) và hiện khối kiểm tra cho từng cái. */
@Composable fun FoundInText(c: Context, text: String) {
    val accts = remember(text) { AccountGuard.extract(text).take(3) }
    val links = remember(text) { DomainGuard.urlsIn(text).take(3) }
    if (accts.isNotEmpty() || links.isNotEmpty()) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SectionHeader("Tìm thấy trong nội dung")
            accts.forEach { (a, b) -> AccountCheckBlock(c, a, b) }
            links.forEach { LinkCheckBlock(c, it, showScore = true) }
        }
    }
}

// ───────────────────────── Quét mã QR ─────────────────────────

private val QR_CONTEXTS = listOf(
    "Chưa rõ",
    "Quét ở cửa hàng, quán, nơi mình đang đứng",
    "Người lạ gửi qua tin nhắn, Zalo, mạng xã hội",
    "Bị bảo trả tiền để nhận thưởng, hoàn tiền, giải ngân, nộp phạt")

@Composable private fun ChoicePill(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(Modifier.fillMaxWidth().background(if (selected) C.Gold.copy(alpha = 0.14f) else C.Field, shape)
        .border(1.dp, if (selected) C.Gold else C.Stroke, shape).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text(label, color = if (selected) C.Gold else Color.White, fontSize = 13.sp)
    }
}

@Composable fun QrScreen(c: Context, back: () -> Unit) {
    var base by remember { mutableStateOf<QrInfo?>(null) }
    var ctx by remember { mutableIntStateOf(0) }
    var errMsg by remember { mutableStateOf("") }
    val onRaw: (String?, String?) -> Unit = { raw, e ->
        if (raw != null) {
            val q = QrGuard.analyze(c, raw)
            base = q; ctx = 0; errMsg = ""
            if (q.result.level >= 1) Store.log(c, if (q.result.level == 2) 2 else 1, "Mã QR đáng ngờ: ${q.title}", q.result.reasons.firstOrNull() ?: q.title)
        } else { errMsg = e ?: "Không đọc được mã QR" }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) QrScan.fromImage(c, uri, onRaw)
    }
    Page("Quét mã QR", back) {
        CardX {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconBadge(Icons.Rounded.QrCodeScanner, C.Mint)
                Text("Kiểm tra mã QR trước khi dùng", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
            Text("App đọc nội dung mã ngay trên máy và KHÔNG mở link. Với mã chuyển tiền VietQR, app cho bạn thấy ngân hàng, số tài khoản và số tiền trước khi bạn trả.",
                fontSize = 12.sp, color = C.Sub, lineHeight = 17.sp)
            GoldButton("Quét bằng camera", leading = Icons.Rounded.QrCodeScanner) { QrScan.camera(c, onRaw) }
            GhostButton("Chọn ảnh có mã QR", leading = Icons.Rounded.Image) { pick.launch("image/*") }
        }
        if (errMsg.isNotEmpty()) Text(errMsg, color = C.Warn, fontSize = 13.sp)
        base?.let { b ->
            CardX {
                Text("Bạn nhận mã này trong tình huống nào?", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                QR_CONTEXTS.forEachIndexed { i, label -> ChoicePill(label, ctx == i) { ctx = i } }
            }
            QrResultView(c, QrGuard.withContext(b, ctx))
        }
        DomainListCard(c)
    }
}

@Composable private fun QrResultView(c: Context, q: QrInfo) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(q.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        ResultCard(q.result)
        if (q.rows.isNotEmpty()) CardX {
            q.rows.forEach { (k, v) ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(k, color = C.Dim, fontSize = 11.sp)
                    Text(v, color = Color.White, fontSize = 14.sp, lineHeight = 19.sp)
                }
            }
        }
        if (q.acct != null) AccountCheckBlock(c, q.acct, q.bin)
        if (q.link != null) LinkCheckBlock(c, q.link, showScore = false)
        if (q.tips.isNotEmpty()) CardX {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconBadge(Icons.Rounded.Lightbulb, C.Gold)
                Text("Lưu ý", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
            q.tips.forEach {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(5.dp).background(C.Gold, CircleShape))
                    Text(it, fontSize = 13.sp, color = C.Sub, lineHeight = 17.sp)
                }
            }
        }
    }
}

/** Danh sách tên miền lừa đảo trên máy + nút tải từ cộng đồng. */
@Composable private fun DomainListCard(c: Context) {
    var rev by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    CardX {
        val list = remember(rev) { DomainGuard.entries(c) }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconBadge(Icons.Rounded.Link, C.Rose)
            Text("Tên miền lừa đảo trên máy (${list.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
        }
        Text("Tin nhắn, thông báo và mã QR chứa link tới các tên miền này sẽ được cảnh báo.", fontSize = 12.sp, color = C.Sub, lineHeight = 17.sp)
        if (list.isEmpty()) Text("Chưa có tên miền nào.", color = C.Dim, fontSize = 13.sp)
        list.take(50).forEach { d ->
            Row(Modifier.fillMaxWidth().background(C.Field, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(d, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                TextButton({ DomainGuard.remove(c, d); rev++ }) { Text("Bỏ", color = C.Rose, fontSize = 12.sp) }
            }
        }
        if (list.size > 50) Text("… và ${list.size - 50} tên miền khác.", color = C.Dim, fontSize = 12.sp)
        GhostButton("Tải danh sách tên miền lừa đảo từ cộng đồng", leading = Icons.Rounded.Download) { DomainGuard.sync(c) { m -> msg = m; rev++ } }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp, color = C.Warn)
    }
}
