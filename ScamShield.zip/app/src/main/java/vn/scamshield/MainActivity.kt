package vn.scamshield
import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.WindowCompat
import org.json.JSONObject
import vn.scamshield.face.FaceBus

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    var modelMsg by mutableStateOf("")
    private val roleL = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    private val permL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    var aiMsg by mutableStateOf("")
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            // Ảnh xem trước (thu nhỏ). Ảnh GỐC mới được gửi đi: nén lại sẽ làm mất dấu vết công cụ AI trong metadata.
            AiPreview.bmp = try {
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
                    android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 })
            } catch (_: Throwable) { null }
            if (bytes.size > 5_000_000) aiMsg = "Ảnh quá lớn (tối đa 5MB)" else {
                aiMsg = "Đang kiểm tra ảnh…"
                Api.call(this, "POST", "/api/analyze/media", JSONObject().put("mime", contentResolver.getType(uri) ?: "image/jpeg")
                    .put("data", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))) { code, j -> aiMsg = fmtMedia(code, j) }
            }
        } catch (e: Exception) { aiMsg = "Không đọc được ảnh: ${e.message ?: ""}" }
    }
    private val modelPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val ok = contentResolver.openInputStream(uri)?.let { TextModel.importExternalModel(it) } == true
            aiMsg = if (ok) "Đã cập nhật mô hình AI. Model mới sẽ được ưu tiên khi phân tích."
                    else "Không thể cập nhật mô hình. Hãy chọn file .tflite hợp lệ."
            tick++
        } catch (e: Exception) {
            aiMsg = "Không thể đọc file mô hình"
            tick++
        }
    }

    private val videoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) startActivity(Intent(this, CameraVideoScanActivity::class.java).setData(uri))
    }
    private val captureL = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null)
            androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, ScreenFaceService::class.java).putExtra("code", r.resultCode).putExtra("data", r.data))
    }

    private val hooks by lazy {
        Hooks(
            tick = { tick },
            callOn = { callOn() }, smsOn = { smsOn() },
            enableCalls = { callPermL.launch(PhoneStateReceiver.perms()) },
            enableSms = { requestSmsProtection() },
            toggleListen = {
                if (ListenService.running) { ListenService.running = false; stopService(Intent(this, ListenService::class.java)); tick++ }
                else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListen()
                else recL.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
            },
            pickImage = { picker.launch("image/*") },
            startFace = { captureL.launch(getSystemService(android.media.projection.MediaProjectionManager::class.java).createScreenCaptureIntent()) },
            stopFace = { stopService(Intent(this, ScreenFaceService::class.java)); FaceBus.running = false },
            pickVideo = { videoPicker.launch("video/*") },
            startCameraScan = { startActivity(Intent(this, CameraVideoScanActivity::class.java).putExtra("camera", true)) },
            startLiveScan = { startActivity(Intent(this, LiveScanActivity::class.java)) },
            openOverlay = { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))) },
            openSocial = { startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            importModel = { modelPicker.launch("*/*") },
            checkModel = { ModelUpdater.check(this, force = true) { _, m -> modelMsg = m; tick++ } },
            modelMsg = { modelMsg },
            aiMsg = { aiMsg }, setAiMsg = { aiMsg = it }
        )
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        applyShieldWindow()
        setContent { ShieldTheme { ShieldApp(this@MainActivity, hooks) } }
    }
    override fun onResume() { super.onResume(); tick++; ModelUpdater.check(this) { _, m -> modelMsg = m; tick++ } }

    private val recL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++; if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListen()
    }
    private fun startListen() { ListenService.running = true; androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java)); tick++ }
    private val callPermL = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
        if (Build.VERSION.SDK_INT >= 29 && !roleOn()) roleL.launch(getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
    }
    private fun roleOn() = Build.VERSION.SDK_INT >= 29 && getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
    private fun permsOn() = PhoneStateReceiver.perms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    private fun callOn() = roleOn() || permsOn()
    private fun smsOn(): Boolean {
        val receiveGranted = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        val notificationPermissionGranted = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val appNotificationsEnabled = androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled()
        val channelEnabled = if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(android.app.NotificationManager::class.java)
                .getNotificationChannel("scam")?.importance != android.app.NotificationManager.IMPORTANCE_NONE
        } else true
        return receiveGranted && notificationPermissionGranted && appNotificationsEnabled && channelEnabled
    }

    private fun requestSmsProtection() {
        val receiveGranted = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        val notificationPermissionGranted = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (!receiveGranted || !notificationPermissionGranted) {
            permL.launch(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS))
        } else {
            // Quyền đã cấp nhưng người dùng tắt thông báo trong Android Settings.
            val intent = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(intent)
        }
    }
}
