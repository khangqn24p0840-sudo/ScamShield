package vn.scamshield

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.MediaMetadataRetriever
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import vn.scamshield.face.FaceLivenessAnalyzer
import vn.scamshield.face.FaceObserver
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * Quét video đã chọn hoặc camera trực tiếp.
 * Hiện tại dùng ML Kit face detection + chỉ báo hình ảnh/chuyển động; chưa phải mô hình Deepfake đã huấn luyện.
 */
class CameraVideoScanActivity : ComponentActivity() {
    private var statusText by mutableStateOf("Đang chuẩn bị phân tích…")
    private var camMode by mutableStateOf(false)
    private var scanPct by mutableStateOf(-1)          // -1 = chưa có tiến độ
    private var previewView: PreviewView? = null
    private var camGranted = false
    private var started = false
    private val executor = Executors.newSingleThreadExecutor()
    private val analyzer = FaceLivenessAnalyzer(FaceLivenessAnalyzer.Config(minObserveMs = 5_000))
    private var observer: FaceObserver? = null
    private var lastFrameAt = 0L
    private var closed = false

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        camGranted = granted
        if (granted) tryStartCamera() else statusText = "Bạn chưa cấp quyền camera. Không thể quét trực tiếp."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyShieldWindow()
        observer = FaceObserver(this, vn.scamshield.face.TfliteDeepfakeClassifier(this))
        setContent { ShieldTheme { Screen() } }
        val uri = intent.data
        if (uri != null) {
            Thread({ scanVideo(uri) }, "video-scan").start()
        } else if (intent.getBooleanExtra("camera", false)) {
            camMode = true
            camGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            if (!camGranted) cameraPermission.launch(Manifest.permission.CAMERA)
        } else {
            statusText = "Không có video được chọn."
        }
    }

    private fun tryStartCamera() {
        if (camGranted && previewView != null && !started) { started = true; startCamera() }
    }

    @Composable private fun Screen() {
        Box(Modifier.fillMaxSize()) {
            AppBackground()
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ScanTopBar("Quét video Deepfake",
                    if (camMode) "Camera trước: giữ khuôn mặt trong khung khoảng 5–10 giây" else "Phân tích khuôn mặt trong video đã chọn") { finish() }
                if (camMode) CameraBox(Modifier.fillMaxWidth().weight(1f), live = true) { previewView = it; tryStartCamera() }
                else Box(Modifier.fillMaxWidth().weight(1f).background(Color.White, RoundedCornerShape(26.dp)).border(1.dp, C.Stroke, RoundedCornerShape(26.dp)),
                    contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        IconBadge(Icons.Rounded.VideoLibrary, C.Violet, 76.dp, 38.dp)
                        if (scanPct in 0..100) {
                            ScoreBar(scanPct / 100f, C.Primary, Modifier.width(220.dp))
                            Text("$scanPct%", color = C.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        } else Text("Đang chuẩn bị…", color = C.Sub, fontSize = 14.sp)
                    }
                }
                CardX {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Kết quả", color = C.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Box(Modifier.background(Color(0xFFFFF1D6), RoundedCornerShape(10.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
                            Text("Thử nghiệm", color = Color(0xFF8A5A00), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                    Text(statusText, color = C.Body, fontSize = 14.sp, lineHeight = 20.sp)
                    Text("Chỉ là chỉ báo, không khẳng định video thật hay giả. Xử lý trong máy, không lưu hình.", color = C.Dim, fontSize = 11.5.sp, lineHeight = 16.sp)
                }
                GhostButton("Đóng", leading = Icons.Rounded.Close) { finish() }
            }
        }
    }

    private fun startCamera() {
        statusText = "Camera đang hoạt động. Giữ khuôn mặt trong khung hình khoảng 5–10 giây."
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            if (isFinishing || isDestroyed) return@addListener
            val provider = providerFuture.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(previewView!!.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(executor) { image ->
                try {
                    val now = System.currentTimeMillis()
                    if (now - lastFrameAt >= 350) {
                        lastFrameAt = now
                        val bitmap = image.toBitmapNv21()
                        analyzer.add(observer!!.observe(bitmap, now))
                        val verdict = analyzer.evaluate()
                        runOnUiThread {
                            statusText = verdict.headline + "\n" +
                                "Điểm chỉ báo: " + (verdict.probability * 100).toInt() + "%\n" +
                                verdict.advice
                        }
                        bitmap.recycle()
                    }
                } catch (_: Exception) {
                    runOnUiThread { statusText = "Không phân tích được khung hình camera." }
                } finally { image.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, previewUseCase, analysis)
            } catch (e: Exception) {
                statusText = "Không mở được camera: " + (e.message ?: "lỗi không xác định")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scanVideo(uri: android.net.Uri) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (durationMs <= 0L) {
                runOnUiThread { statusText = "Không đọc được video này." }
                return
            }
            var t = 0L
            var lastHeadline = "Đang phân tích video…"
            while (t < durationMs && !closed) {
                val frame = retriever.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (frame != null) {
                    analyzer.add(observer!!.observe(frame, t))
                    val v = analyzer.evaluate()
                    lastHeadline = v.headline
                    runOnUiThread {
                        scanPct = (t * 100 / max(1L, durationMs)).toInt().coerceIn(0, 100)
                        statusText = "Đang quét video\n" +
                            v.headline + "\nĐiểm chỉ báo: " + (v.probability * 100).toInt() + "%\n" + v.advice
                    }
                    frame.recycle()
                }
                t += 500L
            }
            runOnUiThread { scanPct = 100; statusText = "Đã quét xong video.\n$lastHeadline\n" +
                "Kết quả chỉ là chỉ báo thử nghiệm, không xác nhận video thật hay giả." }
        } catch (_: Exception) {
            runOnUiThread { statusText = "Không thể đọc hoặc phân tích video này." }
        } finally { retriever.release() }
    }

    private fun ImageProxy.toBitmapNv21(): Bitmap {
        val w = width
        val h = height
        val y = planes[0].buffer
        val u = planes[1].buffer
        val v = planes[2].buffer
        val nv21 = ByteArray(w * h + w * h / 2)
        y.rewind()
        val yRow = planes[0].rowStride
        for (row in 0 until h) {
            val rowStart = row * yRow
            for (col in 0 until w) nv21[row * w + col] = y.get(rowStart + col)
        }
        val uvRow = planes[1].rowStride
        val uvPixel = planes[1].pixelStride
        var out = w * h
        for (row in 0 until h / 2) {
            for (col in 0 until w / 2) {
                val ui = row * uvRow + col * uvPixel
                val vi = row * planes[2].rowStride + col * planes[2].pixelStride
                nv21[out++] = v.get(vi)
                nv21[out++] = u.get(ui)
            }
        }
        val jpeg = ByteArrayOutputStream()
        YuvImage(nv21, ImageFormat.NV21, w, h, null).compressToJpeg(Rect(0, 0, w, h), 75, jpeg)
        return android.graphics.BitmapFactory.decodeByteArray(jpeg.toByteArray(), 0, jpeg.size())
    }

    override fun onDestroy() {
        closed = true
        executor.shutdown()
        observer?.close()
        super.onDestroy()
    }
}
