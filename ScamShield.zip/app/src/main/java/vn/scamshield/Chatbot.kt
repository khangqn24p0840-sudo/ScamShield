package vn.scamshield

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.text.Normalizer

private data class ChatLine(
    val fromUser: Boolean,
    val text: String,
    val pending: Boolean = false
)

private val ChatGreen = Color(0xFF118465)
private val ChatGreenDeep = Color(0xFF0D6D53)
private val ChatGreenDark = Color(0xFF174B3D)
private val ChatMint = Color(0xFFEAF6F0)
private val ChatCanvas = Color(0xFFF4FAF7)
private val ChatBorder = Color(0xFFD6E9DF)
private val ChatMuted = Color(0xFF698579)
private val ChatBubbleUser = Color(0xFFDDF2E8)
private val ChatChip = Color(0xFFE6F4ED)


/** One entry point for the AI assistant. The packaged project keeps its original FloatingBot button. */
@Composable
fun ChatbotLauncher(c: Context, h: Hooks) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        if (!expanded) {
            FloatingChatbotButton(onClick = { expanded = true }, modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 7.dp, bottom = 77.dp))
        }
        ChatbotOverlay(c, h, visible = expanded, onClose = { expanded = false })
    }
}

/** Conversation overlay opened by the existing purple FloatingBot in the packaged ZIP source. */
@Composable
fun ChatbotOverlay(c: Context, h: Hooks, visible: Boolean, onClose: () -> Unit) {
    BackHandler(enabled = visible) { onClose() }
    if (visible) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier.fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.28f))
                    .clickable { onClose() }
            )
            ChatbotPanel(
                c = c,
                onPickImage = h.pickImage,
                onClose = onClose,
                modifier = Modifier.align(Alignment.BottomEnd)
                    .padding(end = 12.dp, bottom = 88.dp)
                    .widthIn(max = 390.dp)
                    .fillMaxWidth(0.94f)
                    .heightIn(max = 520.dp)
                    .fillMaxHeight(0.84f)
            )
        }
    }
}

/** Nút trợ lý nổi: lơ lửng nhẹ, sóng lan tỏa, vòng sáng quay, robot nghiêng đầu, tia sáng lấp lánh. */
@Composable
private fun FloatingChatbotButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "bot")
    val bob by t.animateFloat(-5f, 5f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "spin")
    val ripple by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearOutSlowInEasing)), label = "ripple")
    val tilt by t.animateFloat(-8f, 8f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "tilt")
    val twinkle by t.animateFloat(0.85f, 1.2f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "twinkle")
    val sparkSpin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "sparkSpin")

    Box(
        modifier.size(84.dp).graphicsLayer { translationY = bob.dp.toPx() },
        contentAlignment = Alignment.Center
    ) {
        // Sóng lan tỏa ra ngoài
        Box(
            Modifier.size(62.dp)
                .graphicsLayer {
                    val sc = 1f + 0.55f * ripple
                    scaleX = sc; scaleY = sc; alpha = 0.35f * (1f - ripple)
                }
                .background(Color(0xFF776BFA), CircleShape)
        )
        // Vòng sáng quay quanh nút
        Canvas(Modifier.size(76.dp).graphicsLayer { rotationZ = spin }) {
            drawCircle(
                brush = Brush.sweepGradient(listOf(Color(0x00776BFA), Color(0xFF9D8CFF), Color(0xFF4FD1C5), Color(0x00776BFA))),
                style = Stroke(width = 4.dp.toPx())
            )
        }
        // Thân nút
        Box(
            Modifier.size(62.dp)
                .shadow(18.dp, CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF8E83FF), Color(0xFF5B4DF0))), CircleShape)
                .border(3.dp, Color.White.copy(alpha = 0.96f), CircleShape)
                .clip(CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.SmartToy,
                contentDescription = "Mở trợ lý AI ScamShield",
                tint = Color.White,
                modifier = Modifier.size(32.dp).graphicsLayer { rotationZ = tilt }
            )
        }
        // Huy hiệu tia sáng lấp lánh
        Box(
            Modifier.align(Alignment.TopEnd)
                .padding(top = 5.dp, end = 5.dp)
                .size(21.dp)
                .graphicsLayer { scaleX = twinkle; scaleY = twinkle }
                .background(Color.White, CircleShape)
                .border(1.dp, Color(0xFFFFC86A), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.AutoAwesome, null, tint = Color(0xFFFFA51F),
                modifier = Modifier.size(13.dp).graphicsLayer { rotationZ = sparkSpin }
            )
        }
    }
}

@Composable
private fun ChatbotPanel(c: Context, onPickImage: () -> Unit, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val welcome = "Chào bạn! Mình là trợ lý ScamShield. Hãy gửi nội dung tin nhắn, lời thoại hoặc đường link đáng ngờ để mình phân tích dấu hiệu lừa đảo và gợi ý cách xử lý.\n\nKhông gửi OTP, mật khẩu hoặc thông tin cá nhân nhé."
    val lines = remember { mutableStateListOf(ChatLine(fromUser = false, text = welcome)) }
    val listState = rememberLazyListState()
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }

    fun sendMessage() {
        val message = draft.trim()
        if (message.isEmpty() || busy) return

        lines.add(ChatLine(fromUser = true, text = message))
        draft = ""

        // Chào hỏi / xã giao: trả lời tự nhiên ngay trên máy, không cần đăng nhập, không chấm điểm.
        val chatReply = ChatIntent.localReply(message)
        if (chatReply != null) {
            lines.add(ChatLine(fromUser = false, text = chatReply))
            return
        }

        // Phân tích bằng bộ luật trên máy (luôn chạy), sau đó kết hợp với kết quả từ máy chủ nếu có đăng nhập.
        val content = ChatIntent.defang(message)
        val local = ChatVerdict.local(content)

        if (Store.str(c, "token").isBlank()) {
            lines.add(
                ChatLine(
                    fromUser = false,
                    text = ChatVerdict.render(
                        local.first, local.second,
                        "Đăng nhập tài khoản ScamShield để mình phân tích sâu hơn bằng AI trên máy chủ nhé."
                    )
                )
            )
            return
        }

        busy = true
        lines.add(ChatLine(fromUser = false, text = "Mình đang phân tích nội dung…", pending = true))
        Api.call(c, "POST", "/api/analyze/text", JSONObject().put("text", content)) { code, result ->
            val reply = if (code in 200..299 && result != null) {
                val serverReasons = mutableListOf<String>()
                val arr = result.optJSONArray("reasons")
                if (arr != null) for (i in 0 until arr.length()) serverReasons.add(arr.optString(i))
                ChatVerdict.render(
                    maxOf(local.first, result.optInt("risk")),
                    ChatVerdict.mergeReasons(local.second, serverReasons),
                    null
                )
            } else {
                ChatVerdict.render(
                    local.first, local.second,
                    "Chưa kết nối được máy chủ nên mình đánh giá bằng bộ luật ngay trên máy."
                )
            }
            val pendingIndex = lines.indexOfLast { it.pending }
            if (pendingIndex >= 0) {
                lines[pendingIndex] = ChatLine(fromUser = false, text = reply)
            } else {
                lines.add(ChatLine(fromUser = false, text = reply))
            }
            busy = false
        }
    }

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.lastIndex)
    }

    Column(
        modifier = modifier
            .shadow(24.dp, RoundedCornerShape(26.dp))
            .clip(RoundedCornerShape(26.dp))
            .background(Color.White)
            .border(1.dp, ChatBorder, RoundedCornerShape(26.dp))
    ) {
        Row(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(ChatGreenDeep, ChatGreen)))
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Box(
                Modifier.size(42.dp)
                    .background(Brush.linearGradient(listOf(ChatGreen, ChatGreenDeep)), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.SmartToy, null, tint = Color.White, modifier = Modifier.size(25.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Trợ lý AI ScamShield", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Hỗ trợ nhận diện lừa đảo", color = Color(0xFFD9F6E8), fontSize = 11.sp)
            }
            IconButton(onClick = { showTools = !showTools }) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = "Mở tính năng AI", tint = Color.White)
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Đóng chatbot", tint = Color.White)
            }
        }

        HorizontalDivider(color = ChatBorder)

        if (showTools) {
            Column(
                Modifier.fillMaxWidth()
                    .background(ChatMint)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = ChatGreen, modifier = Modifier.size(16.dp))
                    Text("TÍNH NĂNG AI", color = ChatGreenDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ChatToolChip("Phân tích tin nhắn") {
                        draft = "Hãy phân tích tin nhắn sau và chỉ ra dấu hiệu lừa đảo: "
                        showTools = false
                    }
                    ChatToolChip("Kiểm tra đường link") {
                        draft = "Hãy đánh giá đường link sau có dấu hiệu lừa đảo hay không: "
                        showTools = false
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ChatToolChip("Dấu hiệu cuộc gọi") {
                        draft = "Hãy giúp tôi nhận diện các dấu hiệu lừa đảo trong cuộc gọi có nội dung: "
                        showTools = false
                    }
                    ChatToolChip("Kiểm tra ảnh") {
                        showTools = false
                        onPickImage()
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth()
                .background(ChatCanvas)
                .padding(horizontal = 12.dp, vertical = 12.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(lines) { _, line -> ChatBubble(line) }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { if (it.length <= 4000) draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Dán tin nhắn hoặc đường link…", color = ChatMuted, fontSize = 12.sp) },
                maxLines = 3,
                textStyle = TextStyle(color = ChatGreenDark, fontSize = 13.sp, lineHeight = 18.sp),
                shape = RoundedCornerShape(17.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = ChatGreenDark,
                    unfocusedTextColor = ChatGreenDark,
                    disabledTextColor = ChatMuted,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    disabledContainerColor = ChatCanvas,
                    cursorColor = ChatGreen,
                    focusedBorderColor = ChatGreen,
                    unfocusedBorderColor = ChatBorder,
                    focusedPlaceholderColor = ChatMuted,
                    unfocusedPlaceholderColor = ChatMuted
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { sendMessage() })
            )
            IconButton(
                onClick = { sendMessage() },
                enabled = draft.isNotBlank() && !busy,
                modifier = Modifier.size(46.dp)
                    .background(
                        if (draft.isNotBlank() && !busy) Brush.linearGradient(listOf(ChatGreen, ChatGreenDeep))
                        else Brush.linearGradient(listOf(ChatBorder, ChatBorder)),
                        CircleShape
                    )
            ) {
                Icon(
                    Icons.Rounded.Send,
                    contentDescription = "Gửi nội dung để phân tích",
                    tint = if (draft.isNotBlank() && !busy) Color.White else ChatMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Text(
            "Nội dung gửi sẽ được chuyển lên máy chủ để phân tích.",
            color = ChatMuted,
            fontSize = 10.sp,
            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp)
        )
    }
}

@Composable
private fun ChatBubble(line: ChatLine) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            Modifier.widthIn(max = 310.dp)
                .background(
                    if (line.fromUser) ChatBubbleUser else Color.White,
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (line.fromUser) 18.dp else 5.dp,
                        bottomEnd = if (line.fromUser) 5.dp else 18.dp
                    )
                )
                .border(
                    1.dp,
                    ChatBorder,
                    RoundedCornerShape(18.dp)
                )
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            if (!line.fromUser) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(Icons.Rounded.SmartToy, null, tint = ChatGreen, modifier = Modifier.size(13.dp))
                    Text("SCAMSHIELD AI", color = ChatGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(4.dp))
            }
            Text(
                line.text,
                color = ChatGreenDark,
                fontSize = 12.5.sp,
                lineHeight = 18.sp
            )
        }
    }
}


@Composable
private fun ChatToolChip(label: String, onClick: () -> Unit) {
    Text(
        label,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(ChatChip, RoundedCornerShape(12.dp))
            .border(1.dp, ChatBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        color = ChatGreenDark,
        fontSize = 10.5.sp,
        fontWeight = FontWeight.SemiBold
    )
}

/**
 * Phân loại tin nhắn người dùng gõ vào chatbot.
 * - Xã giao (chào, cảm ơn, hỏi bot là ai...) -> trả lời tự nhiên ngay trên máy, KHÔNG gửi lên server.
 * - Nội dung cần kiểm tra (link, số điện thoại/tài khoản, tin nhắn dài, có từ khóa lừa đảo) -> trả null để gọi phân tích AI.
 */
internal object ChatIntent {

    private val diacritics = Regex("\\p{Mn}+")
    private val nonWord = Regex("[^a-z0-9 ]")
    private val spaces = Regex("\\s+")
    private val urlLike = Regex(
        "(https?://|www\\.|\\b[a-z0-9-]+\\.(com|vn|net|org|info|xyz|top|click|club|online|site|link|cc|me|co|app|shop|icu|live|vip)\\b)",
        RegexOption.IGNORE_CASE
    )
    private val longNumber = Regex("\\d[\\d .\\-]{6,}\\d")

    private val toolPrefixes = listOf(
        "hay phan tich tin nhan sau",
        "hay danh gia duong link sau",
        "hay giup toi nhan dien cac dau hieu lua dao trong cuoc goi"
    )

    private val scamKeywords = listOf(
        "otp", "chuyen khoan", "so tai khoan", "ngan hang", "trung thuong", "nhan qua", "cong an", "vien kiem sat",
        "toa an", "khoa tai khoan", "xac minh", "mat khau", "dat coc", "dau tu", "viec nhe luong cao", "cong tac vien",
        "vay tien", "giai ngan", "hoan tien", "tien dien", "shipper", "buu dien", "thue bao", "mat sim", "click",
        "bam vao", "nhap ma", "ma xac thuc", "can cuoc", "cccd", "lenh bat", "truy na"
    )

    private fun norm(s: String): String {
        val d = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(diacritics, "")
            .replace('đ', 'd')
        return d.replace(nonWord, " ").replace(spaces, " ").trim()
    }

    private fun pick(vararg options: String) = options.random()

    private val greetWords = setOf("hi", "hii", "hello", "helo", "hey", "alo", "chao", "yo", "hallo", "hola", "e", "oi")

    /** @return câu trả lời xã giao, hoặc null nếu nên gọi phân tích AI. */
    /** Khôi phục link bị ngắt dấu chấm kiểu "abc[.]com" hoặc "hxxp". */
    fun defang(s: String): String = s.replace("[.]", ".").replace("(.)", ".").replace("[:]", ":")
        .replace("hxxp", "http", ignoreCase = true)

    fun localReply(raw: String): String? {
        val text = defang(raw.trim())
        val n = norm(text)
        val words = if (n.isEmpty()) emptyList() else n.split(" ")

        // Chỉ có emoji/ký hiệu
        if (n.isEmpty()) return pick(
            "Mình đây! 😊 Bạn cần mình giúp kiểm tra tin nhắn hay đường link nào không?",
            "Chào bạn! Bạn cứ dán nội dung đáng ngờ vào đây, mình xem giúp nhé."
        )

        // Link / số dài => chắc chắn là nội dung cần kiểm tra
        if (urlLike.containsMatchIn(text) || longNumber.containsMatchIn(text)) return null

        // Các nút gợi ý (tool chip) đã điền sẵn câu mở đầu
        toolPrefixes.firstOrNull { n.startsWith(it) }?.let { p ->
            val rest = n.removePrefix(p).trim()
            return if (rest.length < 6) {
                "Bạn dán nội dung cần kiểm tra vào sau câu đó giúp mình nhé, mình xem ngay! 🔍"
            } else null
        }

        // ---- Xã giao ----
        val first = words.first()
        if (words.size <= 5 && (first in greetWords || n.startsWith("xin chao"))) {
            return pick(
                "Chào bạn! 👋 Mình là trợ lý ScamShield. Bạn cần mình kiểm tra tin nhắn, cuộc gọi hay đường link nào không?",
                "Hello bạn! Hôm nay có tin nhắn hay cuộc gọi nào làm bạn thấy lấn cấn không? Cứ gửi mình xem giúp nhé.",
                "Xin chào! Mình sẵn sàng hỗ trợ bạn rồi. Bạn muốn hỏi gì về lừa đảo hay muốn mình kiểm tra nội dung nào?"
            )
        }
        if (n.startsWith("chao buoi") || n.startsWith("good morning") || n.startsWith("good evening")) {
            return "Chào bạn! Chúc bạn một ngày an toàn nhé 😊 Bạn cần mình giúp gì không?"
        }
        if (words.size <= 6 && ("cam on" in n || n.startsWith("thanks") || n.startsWith("thank") || n == "tks" || n == "ty")) {
            return pick(
                "Không có gì đâu bạn! Có gì đáng ngờ cứ gửi mình nhé 💚",
                "Rất vui được giúp bạn! Cẩn thận với tin nhắn lạ nha."
            )
        }
        if (words.size <= 4 && (n.contains("tam biet") || n == "bye" || n.startsWith("bye ") || n == "bb" || n.contains("hen gap lai"))) {
            return "Tạm biệt bạn! Nhớ là đừng bao giờ chia sẻ OTP cho ai nhé. Hẹn gặp lại 👋"
        }
        if (n.contains("ban la ai") || n.contains("ten ban la gi") || n.contains("may la ai") || n.contains("who are you") ||
            n.contains("ban ten gi")
        ) {
            return "Mình là trợ lý AI của ScamShield 🤖 — chuyên giúp bạn nhận diện tin nhắn, cuộc gọi, đường link và ảnh có dấu hiệu lừa đảo, rồi gợi ý cách xử lý."
        }
        if (n.contains("ban lam duoc gi") || n.contains("ban giup duoc gi") || n.contains("giup gi") ||
            n.contains("lam duoc gi") || n.contains("huong dan") || n == "help" || n.contains("cach dung") || n.contains("su dung the nao")
        ) {
            return "Mình có thể giúp bạn:\n• Phân tích tin nhắn/lời thoại nghi lừa đảo\n• Đánh giá đường link\n• Nhận diện dấu hiệu qua cuộc gọi\n• Kiểm tra ảnh có bị làm giả không (bấm biểu tượng ✨ ở trên)\n\nBạn chỉ cần dán nội dung vào đây là được."
        }
        if (n.contains("khoe khong") || n.contains("khoe ko") || n.contains("how are you") || n.contains("dang lam gi") ||
            n.contains("an com chua")
        ) {
            return pick(
                "Mình khỏe, cảm ơn bạn đã hỏi! 😄 Còn bạn thì sao, có tin nhắn lạ nào cần mình xem không?",
                "Mình ổn lắm, lúc nào cũng sẵn sàng canh chừng giúp bạn đây! Bạn cần hỗ trợ gì nào?"
            )
        }
        if (words.size <= 2 && n in setOf("ok", "oke", "okie", "uh", "u", "da", "vang", "um", "uhm", "duoc", "roi", "hay", "tot", "good")) {
            return pick("Ok bạn! Cần gì cứ nhắn mình nhé 😊", "Vâng! Có gì cần kiểm tra bạn cứ gửi nhé.")
        }
        if (n.contains("xin loi") && words.size <= 5) {
            return "Bạn đừng ngại, cứ hỏi thoải mái nhé! 😊"
        }

        // Hỏi chung chung về lừa đảo nhưng chưa gửi nội dung
        val hasKeyword = scamKeywords.any { it in n } || "lua dao" in n || "scam" in n
        if (words.size <= 8 && hasKeyword && (n.contains("khong") || words.contains("ko") || text.endsWith("?")) &&
            !n.contains("http")
        ) {
            return "Bạn dán nguyên văn tin nhắn, lời thoại hoặc đường link vào đây giúp mình nhé, mình sẽ phân tích dấu hiệu lừa đảo cho bạn. Đừng gửi OTP hay mật khẩu nha."
        }

        // ---- Nội dung cần phân tích ----
        if (n.length >= 40) return null
        if (hasKeyword && words.size >= 4) return null

        // Câu ngắn không rõ ý: trả lời thân thiện thay vì chấm điểm
        return pick(
            "Mình chưa rõ ý bạn lắm 😅 Nếu bạn có tin nhắn, lời thoại hay đường link đáng ngờ thì dán vào đây, mình sẽ phân tích giúp nhé.",
            "Bạn nói rõ hơn một chút được không? Hoặc cứ gửi nội dung đáng ngờ, mình sẽ kiểm tra ngay."
        )
    }
}

/** Đánh giá nội dung trên máy: bộ luật ScamDetector + luật bổ sung cho tin nhắn giả mạo ngân hàng/dịch vụ. */
internal object ChatVerdict {
    private class Rule(val re: Regex, val pts: Int, val reason: String, val compact: Boolean = false, val needsLink: Boolean = false)

    private val linkRe = Regex("https?://|www\\.|\\b[a-z0-9-]+\\.(com|vn|net|org|info|xyz|top|click|club|online|site|link|cc|me|co|app|shop|icu|live|vip)\\b")
    private val hostRe = Regex("(?:https?://)?((?:[a-z0-9-]+\\.)+[a-z]{2,})")
    private val lureHost = listOf(
        "nganhang", "capnhat", "chinhsach", "xacminh", "xacthuc", "kichhoat", "baomat", "khoataikhoan", "bidongbang",
        "hotro", "chamsoc", "tichdiem", "nhanqua", "trungthuong", "vneid", "dichvucong", "bhxh", "otp"
    )

    private val extra = listOf(
        Rule(Regex("taikhoan.{0,60}(khoa|dongbang|tamngung|hanche|vohieu)|(khoa|dongbang|tamngung|vohieu).{0,20}taikhoan"), 30, "Dọa khóa/đóng băng tài khoản", compact = true),
        Rule(Regex("xac minh|xac nhan|kich hoat|cap nhat (thong tin|chinh sach|tai khoan)|dang nhap lai|mo khoa"), 25, "Yêu cầu xác minh / kích hoạt lại tài khoản qua đường link", needsLink = true),
        Rule(Regex("(trong|truoc|sau|con) ?\\d{1,3} ?(h|gio|tieng|phut|ngay)\\b"), 15, "Tạo áp lực thời gian"),
        Rule(Regex("vi pham|quy dinh|bi han che"), 10, "Dọa vi phạm quy định"),
        Rule(Regex("truy cap|bam vao|nhan vao|click|an vao|vao link|dang nhap tai"), 15, "Bắt bạn bấm vào đường link lạ", needsLink = true),
        Rule(Regex("(tro giup|lien he|hotline|tong dai|goi)[^\\d]{0,15}(1900|1800|0\\d{8,9})"), 10, "Có số hotline / số liên hệ lạ trong tin nhắn")
    )

    /** @return Pair(điểm 0..100, danh sách dấu hiệu) */
    fun local(text: String): Pair<Int, List<String>> {
        val base = ScamDetector.analyze(text)
        val n = ScamDetector.norm(text)
        val compact = n.replace(Regex("[^a-z0-9]"), "")
        val hasLink = linkRe.containsMatchIn(n)
        var score = base.score
        val reasons = base.reasons.toMutableList()

        for (r in extra) {
            if (r.reason in reasons) continue
            if (r.needsLink && !hasLink) continue
            if (r.re.containsMatchIn(if (r.compact) compact else n)) { score += r.pts; reasons += r.reason }
        }

        val fakeHost = hostRe.findAll(n).map { it.groupValues[1] }.any { h ->
            !h.endsWith(".gov.vn") && lureHost.any { h.replace("-", "").contains(it) }
        }
        if (fakeHost) {
            score += 30
            reasons += "Tên miền giả danh ngân hàng/dịch vụ, không phải trang chính thức"
        }
        return score.coerceAtMost(100) to reasons
    }

    fun mergeReasons(local: List<String>, server: List<String>): List<String> {
        val out = local.toMutableList()
        for (r in server) if (r.isNotBlank() && out.none { it.equals(r, ignoreCase = true) }) out += r
        return out
    }

    private fun adviceFor(level: Int, reasons: List<String>): List<String> {
        if (level == 0) return listOf(
            "Chưa thấy dấu hiệu rõ ràng, nhưng vẫn không bấm link lạ và không chia sẻ OTP, mật khẩu.",
            "Nếu còn nghi ngờ, hãy hỏi lại trực tiếp tổ chức liên quan hoặc gửi thêm nội dung/link để mình xem kỹ hơn."
        )
        val all = reasons.joinToString(" | ").lowercase()
        val tips = mutableListOf<String>()
        if ("link" in all || "tên miền" in all || "đường link" in all) tips += "Không bấm vào link và không gọi số trong tin nhắn."
        if ("khóa" in all || "ngân hàng" in all || "xác minh" in all) tips += "Tự mở app ngân hàng chính thức hoặc gọi số hotline in trên mặt sau thẻ để kiểm tra. Ngân hàng không yêu cầu xác minh qua link lạ."
        if ("otp" in all || "nhạy cảm" in all) tips += "Tuyệt đối không cung cấp OTP, mật khẩu, số thẻ, CVV cho bất kỳ ai."
        if ("cơ quan" in all || "vụ án" in all || "danh tính" in all) tips += "Công an, viện kiểm sát, tòa án không làm việc qua điện thoại hay tin nhắn và không yêu cầu chuyển tiền vào \"tài khoản an toàn\". Hãy cúp máy và đến trực tiếp cơ quan chức năng."
        if ("trúng thưởng" in all || "việc làm" in all || "đầu tư" in all || "vay" in all || "chuyển tiền" in all) tips += "Không chuyển tiền hay nộp phí trước để \"nhận thưởng, nhận việc, vay vốn, đầu tư\"."
        if ("cài app" in all || "màn hình" in all) tips += "Không cài app lạ và không chia sẻ màn hình điện thoại."
        tips += "Chặn số, xóa tin nhắn và báo cho nhà mạng hoặc ngân hàng nếu cần."
        tips += "Nếu lỡ bấm link hoặc nhập thông tin: đổi mật khẩu ngay, gọi ngân hàng khóa tạm thẻ/tài khoản rồi trình báo công an."
        return tips
    }

    fun render(score: Int, reasons: List<String>, note: String?): String {
        val level = when { score >= 60 -> 2; score >= 30 -> 1; else -> 0 }
        val head = when (level) {
            2 -> "🚨 Rất có thể là lừa đảo"
            1 -> "⚠️ Đáng ngờ, bạn nên cẩn thận"
            else -> "🤔 Chưa thấy dấu hiệu lừa đảo rõ ràng"
        } + " ($score/100)"
        val sb = StringBuilder(head)
        if (reasons.isNotEmpty()) {
            sb.append("\n\n🔎 Dấu hiệu:")
            reasons.take(8).forEach { sb.append("\n• ").append(it) }
        }
        sb.append("\n\n✅ Cách xử lý:")
        adviceFor(level, reasons).forEach { sb.append("\n• ").append(it) }
        if (!note.isNullOrBlank()) sb.append("\n\n").append(note)
        return sb.toString()
    }
}
