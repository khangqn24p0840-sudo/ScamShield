package vn.scamshield
import android.app.Notification
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat

/** Đọc thông báo của Zalo, Messenger, Telegram... để cảnh báo tin nhắn lừa đảo. */
class SocialListener : NotificationListenerService() {
    companion object {
        val apps = mapOf("com.zing.zalo" to "Zalo", "com.facebook.orca" to "Messenger", "com.facebook.mlite" to "Messenger Lite",
            "com.facebook.katana" to "Facebook", "org.telegram.messenger" to "Telegram", "com.viber.voip" to "Viber",
            "com.instagram.android" to "Instagram", "com.whatsapp" to "WhatsApp", "com.zhiliaoapp.musically" to "TikTok",
            "com.ss.android.ugc.trill" to "TikTok", "com.google.android.apps.messaging" to "Tin nhắn Google")
        fun enabled(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    }

    // LRU cache nhỏ: tránh xử lý trùng lặp notification (trước đây chỉ lưu 1 key, 2 người nhắn cùng lúc bỏ sót 1)
    private val recentKeys = ArrayDeque<String>(64)
    private val MAX_RECENT = 60

    private fun isDuplicate(key: String): Boolean {
        if (key in recentKeys) return true
        recentKeys.addLast(key)
        if (recentKeys.size > MAX_RECENT) recentKeys.removeFirst()
        return false
    }

    @Suppress("DEPRECATION")
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName in Habit.bankApps) {
            val x = sbn.notification.extras ?: return
            Habit.onText(this, (x.getCharSequence(Notification.EXTRA_TEXT) ?: "").toString() + " " + (x.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ""))
            return
        }
        val app = apps[sbn.packageName] ?: return
        val e = sbn.notification.extras ?: return
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val flagGroup = (Build.VERSION.SDK_INT >= 28 && e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION)) ||
            e.getCharSequence("android.conversationTitle") != null

        // Tách TỪNG TIN riêng (kèm người gửi nếu có). Trước đây mọi tin chưa đọc bị nối thành một chuỗi rồi chấm điểm một lần,
        // nên các từ khóa rời rạc của nhiều người, nhiều tin cộng dồn lại và gây báo nhầm.
        val msgs = ArrayList<Pair<String, String>>()   // (người gửi hoặc "", nội dung)
        e.getParcelableArray(Notification.EXTRA_MESSAGES)?.forEach { p ->
            val b = p as? Bundle ?: return@forEach
            val tx = b.getCharSequence("text")?.toString().orEmpty()
            if (tx.isNotBlank()) msgs += (b.getCharSequence("sender")?.toString().orEmpty() to tx)
        }
        var group = flagGroup
        if (msgs.isEmpty()) {
            val lines = ArrayList<String>()
            e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { lines += it.toString() }
            if (lines.isEmpty()) {
                val one = e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT)
                if (one != null) lines += one.toString()
            }
            val named = lines.map { NAME_RE.find(it) }
            // Dạng "Tên người: nội dung" cho biết đây là chat nhóm (Zalo, Messenger... không luôn gắn cờ nhóm)
            if (named.isNotEmpty() && named.all { it != null }) group = true
            for ((i, l) in lines.withIndex()) {
                val m = named[i]
                if (group && m != null) msgs += (m.groupValues[1] to m.groupValues[2]) else msgs += ("" to l)
            }
        }
        for ((member, text) in msgs.takeLast(5)) handle(sbn.packageName, app, title, member, text, group)
    }

    private val NAME_RE = Regex("^([\\p{L}][\\p{L} .'\\-]{0,28}):\\s+(.+)$", RegexOption.DOT_MATCHES_ALL)

    private fun handle(pkg: String, app: String, title: String, member: String, text: String, group: Boolean) {
        if (text.isBlank()) return
        val who = if (group && member.isNotBlank() && member != title) "$member (nhóm $title)" else title
        if (isDuplicate(pkg + title + member + text.hashCode())) return
        val r = ScamDetector.analyze(text)
        // Theo dõi nhiều ngày theo TỪNG NGƯỜI gửi. Trong nhóm không gộp cả nhóm vào một hồ sơ (nhiều người, nhiều chuyện khác nhau).
        val trackKey = when { !group -> title; member.isNotBlank() -> "$title / $member"; else -> null }
        if (trackKey != null) {
            val th = ThreadGuard.onMessage(this, app, trackKey, text, r)
            if (th != null) { ThreadGuard.alert(this, app, who, th); return }
        }
        val lv = r.levelIn(group)      // nhóm: ngưỡng cao hơn 10 điểm
        if (lv < 1) return
        val t = (if (lv == 2) "🚨 Tin nhắn lừa đảo trên " else "⚠️ Tin nhắn đáng ngờ trên ") + app
        Store.log(this, lv, "$t từ $who", text)
        Notifier.show(this, t, "Từ $who: " + r.reasons.joinToString(", ") + ". Không bấm link, không chuyển tiền, không đọc OTP.")
        Alerter.fire(this, lv)
    }
}
