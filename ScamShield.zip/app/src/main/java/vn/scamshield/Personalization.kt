package vn.scamshield

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Hồ sơ thói quen cục bộ dùng để cá nhân hóa giao diện và ưu tiên cảnh báo. */
object Personalization {
    const val KEY = "personalization_answers"

    fun save(c: Context, answers: List<String>) {
        Store.putStr(c, KEY, JSONArray(answers).toString())
        Store.putFlag(c, "personalization_done", true)
        // Chỉ gửi bản khảo sát nếu người dùng đã đăng nhập và chủ động đồng ý thống kê.
        if (Store.str(c, "token").isNotEmpty() && Store.flag(c, "consent")) {
            Api.call(c, "POST", "/api/survey", JSONObject().put("answers", JSONArray(answers))) { _, _ -> }
        }
    }

    fun answers(c: Context): List<String> {
        return try {
            val a = JSONArray(Store.str(c, KEY).ifEmpty { "[]" })
            (0 until a.length()).map { a.optString(it) }
        } catch (_: Exception) { emptyList() }
    }

    fun primaryChannel(c: Context): String {
        return answers(c).getOrNull(3).orEmpty()
    }

    fun confidence(c: Context): String = answers(c).getOrNull(4).orEmpty()

    fun intro(c: Context): String = when (primaryChannel(c)) {
        "Cuộc gọi" -> "Bạn thường gặp cuộc gọi lạ — ScamShield sẽ ưu tiên lớp bảo vệ cuộc gọi."
        "SMS" -> "Bạn thường nhận SMS — ScamShield sẽ ưu tiên kiểm tra tin nhắn."
        "Zalo/Messenger" -> "Bạn thường dùng Zalo/Messenger — ScamShield sẽ ưu tiên theo dõi cảnh báo từ kênh này."
        "Mạng xã hội khác" -> "Bạn thường dùng mạng xã hội — ScamShield sẽ ưu tiên các cảnh báo liên quan đến liên kết và nội dung đáng ngờ."
        else -> "ScamShield sẽ điều chỉnh trải nghiệm dựa trên thói quen bạn đã chọn."
    }
}
