package vn.scamshield

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import kotlin.math.max

// ───────────────────────── Thành phần dùng chung cho các màn quét camera ─────────────────────────

/** Thanh tiêu đề: nút quay lại + tiêu đề + dòng phụ. */
@Composable fun ScanTopBar(title: String, subtitle: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        RoundIconButton(Icons.Rounded.ArrowBack, onBack, 42.dp)
        Column(Modifier.weight(1f)) {
            Text(title, color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(subtitle, color = C.Dim, fontSize = 12.sp, maxLines = 2, lineHeight = 15.sp)
        }
    }
}

/** Khung ngắm 4 góc phủ lên hình camera. */
@Composable fun ScanFrame(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val inset = 26.dp.toPx(); val len = 34.dp.toPx(); val sw = 4.dp.toPx()
        val col = Color(0xFF4BE3A8)
        fun corner(x: Float, y: Float, dx: Float, dy: Float) {
            drawLine(col, Offset(x, y), Offset(x + dx * len, y), sw, StrokeCap.Round)
            drawLine(col, Offset(x, y), Offset(x, y + dy * len), sw, StrokeCap.Round)
        }
        corner(inset, inset, 1f, 1f); corner(size.width - inset, inset, -1f, 1f)
        corner(inset, size.height - inset, 1f, -1f); corner(size.width - inset, size.height - inset, -1f, -1f)
    }
}

/** Nhãn "Đang quét trực tiếp" có chấm đỏ nhấp nháy. */
@Composable fun LiveChip(modifier: Modifier = Modifier, text: String = "Đang quét trực tiếp") {
    Row(modifier.background(Color.White.copy(alpha = 0.94f), RoundedCornerShape(20.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(8.dp).pulse(0.7f, 1.3f, 700).background(C.Bad, CircleShape))
        Text(text, color = C.Text, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Ô xem trước camera bo tròn + khung ngắm. `onView` được gọi khi PreviewView đã sẵn sàng. */
@Composable fun CameraBox(modifier: Modifier, live: Boolean, onView: (PreviewView) -> Unit) {
    Box(modifier.clip(RoundedCornerShape(26.dp)).background(Color(0xFF14201B))) {
        AndroidView({ ctx ->
            PreviewView(ctx).apply {
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE   // để bo góc được
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }.also(onView)
        }, Modifier.fillMaxSize())
        ScanFrame(Modifier.fillMaxSize())
        if (live) LiveChip(Modifier.align(Alignment.TopStart).padding(14.dp))
    }
}

// ───────────────────────── Quét camera / ảnh theo thời gian thực ─────────────────────────

/**
 * Đưa camera tới tin nhắn, thư, màn hình hoặc mã QR: app đọc chữ (ML Kit OCR) và mã QR ngay trong máy,
 * rồi chạy bộ phát hiện lừa đảo ScamDetector trên nội dung đọc được. Có thể chọn ảnh trong máy để quét tương tự.
 * Không lưu hình, không gửi gì lên máy chủ.
 */
class LiveScanActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val codeScanner by lazy { BarcodeScanning.getClient() }
    private var previewView: PreviewView? = null
    private var camGranted = false
    private var started = false
    private var lastAt = 0L
    private var lastGoodAt = 0L

    private var paused by mutableStateOf(false)
    private var camDenied by mutableStateOf(false)
    private var result by mutableStateOf<Result?>(null)
    private var seen by mutableStateOf("")
    private var fromQr by mutableStateOf(false)
    private var hint by mutableStateOf(HINT_IDLE)

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        camGranted = ok; camDenied = !ok
        if (ok) tryStart()
    }
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) scanPicked(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyShieldWindow()
        camGranted = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        setContent { ShieldTheme { Screen() } }
        if (!camGranted) camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun tryStart() {
        if (camGranted && previewView != null && !started) { started = true; startCamera() }
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun startCamera() {
        val pv = previewView ?: return
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            if (isFinishing || isDestroyed) return@addListener
            val provider = fut.get()
            val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy ->
                val media = proxy.image
                val now = System.currentTimeMillis()
                if (media == null || paused || now - lastAt < 800) { proxy.close(); return@setAnalyzer }
                lastAt = now
                try { process(InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees), false) }
                catch (_: Exception) { } finally { proxy.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, prev, analysis)
            } catch (e: Exception) { hint = "Không mở được camera: " + (e.message ?: "lỗi không xác định") }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Ưu tiên mã QR; không có QR thì đọc chữ (chạy ở luồng nền). */
    private fun process(img: InputImage, force: Boolean) {
        val qr = Tasks.await(codeScanner.process(img)).firstNotNullOfOrNull { it.rawValue }
        if (qr != null) { publish(qr, true, force); return }
        publish(Tasks.await(recognizer.process(img)).text, false, force)
    }

    private fun publish(raw: String, qr: Boolean, force: Boolean) {
        val t = raw.trim()
        val now = System.currentTimeMillis()
        if (!qr && t.length < 15) {
            runOnUiThread {
                if (force) { result = null; seen = ""; hint = "Không thấy chữ hoặc mã QR đủ rõ trong ảnh này." }
                else if (!paused && now - lastGoodAt > 4000) { result = null; seen = ""; hint = HINT_IDLE }
            }
            return
        }
        var r = ScamDetector.analyze(t)
        if (qr) r = r.copy(reasons = listOf("Mã QR dẫn tới: " + t.take(90)) + r.reasons)
        lastGoodAt = now
        runOnUiThread { result = r; seen = t; fromQr = qr }
    }

    private fun scanPicked(uri: Uri) {
        paused = true; result = null; hint = "Đang đọc ảnh…"
        Thread({
            try {
                val bmp = decode(uri) ?: throw IllegalStateException("decode")
                process(InputImage.fromBitmap(bmp, 0), true)
                bmp.recycle()
            } catch (_: Exception) { runOnUiThread { hint = "Không đọc được ảnh này." } }
        }, "scan-pick").start()
    }

    private fun decode(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 2200) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    @Composable private fun Screen() {
        Box(Modifier.fillMaxSize()) {
            AppBackground()
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ScanTopBar("Quét camera trực tiếp", "Soi tin nhắn, thư, màn hình và mã QR ngay khi đưa camera tới") { finish() }
                if (camDenied) {
                    Box(Modifier.fillMaxWidth().weight(1f)) {
                        CardX(Modifier.align(Alignment.Center)) {
                            Text("Cần quyền camera", color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Hãy cấp quyền để ScamShield nhìn thấy nội dung cần kiểm tra. Hình ảnh chỉ được xử lý trong máy, không lưu.",
                                color = C.Sub, fontSize = 13.sp, lineHeight = 18.sp)
                            PrimaryButton("Cấp quyền camera", leading = Icons.Rounded.CameraAlt) { camPerm.launch(Manifest.permission.CAMERA) }
                        }
                    }
                } else CameraBox(Modifier.fillMaxWidth().weight(1f), live = !paused && camGranted) { previewView = it; tryStart() }
                Column(Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val r = result
                    if (r == null) CardX {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            IconBadge(Icons.Rounded.CenterFocusStrong, C.Primary)
                            Text(hint, color = C.Body, fontSize = 13.5.sp, lineHeight = 19.sp, modifier = Modifier.weight(1f))
                        }
                    } else {
                        ResultCard(r)
                        if (seen.isNotBlank()) Text((if (fromQr) "Nội dung mã QR: " else "Chữ đọc được: ") + seen.take(160),
                            color = C.Dim, fontSize = 12.sp, maxLines = 3, lineHeight = 16.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GhostButton(if (paused) "Quét lại" else "Tạm dừng", Modifier.weight(1f),
                            leading = if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause) {
                            paused = !paused
                            if (!paused) { result = null; seen = ""; hint = HINT_IDLE }
                        }
                        GhostButton("Chọn ảnh", Modifier.weight(1f), leading = Icons.Rounded.Image) { picker.launch("image/*") }
                    }
                    Text("Quét ngay trong máy, không lưu hình và không gửi đi đâu. Chữ tiếng Việt có thể bị đọc sai dấu nên kết quả chỉ để tham khảo.",
                        color = C.Faint, fontSize = 11.5.sp, lineHeight = 16.sp)
                }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        runCatching { recognizer.close() }
        runCatching { codeScanner.close() }
        super.onDestroy()
    }

    companion object { private const val HINT_IDLE = "Đưa camera tới tin nhắn, thư, màn hình hoặc mã QR cần kiểm tra. Giữ yên khoảng 1–2 giây." }
}
