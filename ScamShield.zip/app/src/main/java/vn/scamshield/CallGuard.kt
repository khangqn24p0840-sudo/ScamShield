package vn.scamshield
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract

object CallGuard {
    private var last = ""; private var at = 0L

    // Cache kết quả lookup contacts: số -> (isKnown, timestamp)
    // TTL 5 phút để danh bạ thêm mới được nhận ra mà không cần khởi động lại app
    private val contactCache = HashMap<String, Pair<Boolean, Long>>(32)
    private const val CONTACT_CACHE_TTL = 5 * 60_000L  // 5 phút

    fun known(c: Context, num: String): Boolean {
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return false
        val key = Store.digits(num)
        if (key.length < 7) return false
        val now = System.currentTimeMillis()
        // Kiểm tra cache trước
        contactCache[key]?.let { (result, ts) ->
            if (now - ts < CONTACT_CACHE_TTL) return result
        }
        // Cache miss: query ContentResolver
        return try {
            val result = c.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup._ID), null, null, null
            )?.use { it.count > 0 } ?: false
            contactCache[key] = result to now
            // Giữ cache nhỏ (tối đa 200 số)
            if (contactCache.size > 200) {
                val oldest = contactCache.entries.minByOrNull { it.value.second }?.key
                if (oldest != null) contactCache.remove(oldest)
            }
            result
        } catch (_: Exception) { false }
    }

    /** Trả về true nếu cần chặn cuộc gọi này. */
    fun handle(c: Context, num: String): Boolean {
        if (Store.digits(num).length < 3) return false
        val foreign = num.startsWith("+") && !num.startsWith("+84")
        val block = Store.isBlocked(c, num) || (foreign && Store.blockForeign(c))
        val now = System.currentTimeMillis()
        if (num == last && now - at < 8000) return block
        last = num; at = now
        if (block) {
            Store.log(c, 2, "Đã chặn cuộc gọi", num)
            Notifier.show(c, "🛡️ Đã chặn cuộc gọi lừa đảo", "Số $num nằm trong danh sách chặn.")
        } else if (foreign || !known(c, num)) {
            Store.markCalled(c, num)
            Store.log(c, 1, if (foreign) "Số nước ngoài gọi đến" else "Số lạ gọi đến", num)
            Notifier.show(c, "⚠️ Số lạ đang gọi" + if (foreign) " (nước ngoài)" else "",
                "Số lạ $num. Công an, ngân hàng không bao giờ đòi OTP hay chuyển tiền qua điện thoại.", num)
        }
        return block
    }
}
