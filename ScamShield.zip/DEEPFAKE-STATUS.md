# Deepfake scanner: current status and limitations

## What the current implementation does
- Detects a face in captured video-call frames with ML Kit.
- Computes temporal/image heuristics (head-pose jitter, face/background sharpness variation, and face-box jumps).
- Uses a sliding observation window and delays alerts to avoid repeated notifications.
- Does not save captured frames as part of the observation model.

## Important model status
The app now packages `deepfake_model.tflite` + `deepfake_config.json` (assets), loaded by `TfliteDeepfakeClassifier`.
- Input `[1,224,224,3]` float32, RGB, normalized to [-1, 1]; output `[1,1]` = probability of REAL (config: `probability_of_real`). The app converts it to fake = 1 - real.
- If the model fails to load or its shape does not match the config, the classifier reports unavailable and the scanner falls back to heuristics only (it cannot emit the highest risk level).
- The model's training data and accuracy are NOT documented in this repo. The face crop fed to it is the tight ML Kit face box; if the model was trained on differently cropped faces, accuracy will differ.
- Model-based HIGH alerts are therefore only as trustworthy as the validation in "What is still required" below.

## Changes in deepfake-optimization
- Blink count is no longer used as evidence of manipulation because normal human blink behavior varies and eye landmarks can be unreliable in compressed/low-light video.
- Without a model output, the analyzer can only show heuristic risk; it cannot emit the highest risk level.
- A suspicious result is worded as a request for further verification, not a definitive claim that a video is fake.
- Model frame scores are aggregated with a median to reduce the effect of isolated bad frames.

## What is still required for real deepfake classification
1. Confirm the model was trained for the intended domain (face-swap and/or generated-face videos) and which face crop it expects.
2. Input normalization, tensor shape, output meaning and channel order are taken from deepfake_config.json; verify them against the training code.
3. Evaluate on a held-out set containing genuine and manipulated clips, including recompressed/low-light examples.
4. Report precision, recall, false-positive rate, and calibration separately by video quality.
5. Only enable model-based high-risk alerts after the model is actually packaged, loaded, and validated.

Do not interpret a low heuristic score as proof that a person/video is genuine. For financial or account requests, verify through a separate trusted channel.
