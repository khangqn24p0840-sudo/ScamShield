"""Tăng phiên bản model sau khi train để app tự tải bản mới."""
from pathlib import Path
import argparse
ap=argparse.ArgumentParser(); ap.add_argument('--version', required=True); a=ap.parse_args()
out=Path(__file__).resolve().parent/'exports'; out.mkdir(exist_ok=True)
model=out/'scam_text.tflite'
if not model.exists(): raise SystemExit(f'Không tìm thấy {model}; hãy train trước.')
(out/'scam_text.version').write_text(a.version.strip(), encoding='utf-8')
print(f'Đã publish model v{a.version}: {model}')
