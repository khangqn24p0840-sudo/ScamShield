"""Hằng số và hàm dùng chung cho pipeline huấn luyện mô hình khuôn mặt giả.

QUAN TRỌNG: IMG và MARGIN phải khớp với app Android (deepfake_meta.json -> cropMargin, input).
Khi train xong, train_face.py ghi chúng vào deepfake_meta.json và app tự đọc, nên chỉ cần sửa ở đây.
"""
import io
import random

import numpy as np
from PIL import Image, ImageEnhance, ImageFilter

IMG = 224          # kích thước đầu vào mô hình
STORE = 256        # kích thước lưu trên đĩa (to hơn IMG một chút để còn crop ngẫu nhiên)
MARGIN = 0.25      # phần viền thêm quanh khung mặt (25% mỗi cạnh); app cắt mặt đúng như vậy
SEED = 1337

RESAMPLE = [Image.BILINEAR, Image.BICUBIC, Image.BOX, Image.LANCZOS]


def expand_box(x, y, w, h, img_w, img_h, margin=MARGIN):
    """Nới khung mặt ra mỗi cạnh `margin` * kích thước, cắt theo biên ảnh. Trả về (l, t, r, b)."""
    dx, dy = int(w * margin), int(h * margin)
    l, t = max(0, x - dx), max(0, y - dy)
    r, b = min(img_w, x + w + dx), min(img_h, y + h + dy)
    return l, t, r, b


def jpeg_roundtrip(img, quality):
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=int(quality))
    buf.seek(0)
    return Image.open(buf).convert("RGB")


def degrade(img, rng=None, strength=1.0):
    """Mô phỏng điều kiện THỰC của app: ảnh mặt bị chụp từ màn hình ở nửa độ phân giải, video call nén mạnh,
    ô video nhỏ, ánh sáng yếu. ÁP DỤNG ĐỒNG ĐỀU cho cả ảnh thật lẫn ảnh giả; nếu chỉ làm xấu một lớp,
    mô hình sẽ học 'ảnh xấu = giả' thay vì học dấu vết giả mạo.
    """
    rng = rng or random
    w, h = img.size
    if rng.random() < 0.75 * strength:                       # ô video nhỏ -> phóng lại
        s = rng.uniform(0.18, 0.85)
        small = img.resize((max(16, int(w * s)), max(16, int(h * s))), rng.choice(RESAMPLE))
        img = small.resize((w, h), rng.choice(RESAMPLE))
    if rng.random() < 0.5 * strength:
        img = img.filter(ImageFilter.GaussianBlur(rng.uniform(0.3, 1.6)))
    if rng.random() < 0.85 * strength:                       # nén JPEG (đại diện cho nén H.264 của cuộc gọi)
        img = jpeg_roundtrip(img, rng.uniform(18, 92))
        if rng.random() < 0.3:                               # nén hai lần: quay màn hình rồi gửi lại
            img = jpeg_roundtrip(img, rng.uniform(30, 90))
    if rng.random() < 0.5 * strength:                        # ánh sáng yếu / đèn màu
        img = ImageEnhance.Brightness(img).enhance(rng.uniform(0.5, 1.3))
        img = ImageEnhance.Contrast(img).enhance(rng.uniform(0.7, 1.3))
        img = ImageEnhance.Color(img).enhance(rng.uniform(0.6, 1.3))
    if rng.random() < 0.3 * strength:                        # nhiễu cảm biến
        a = np.asarray(img).astype(np.float32)
        a += np.random.normal(0, rng.uniform(2, 8), a.shape)
        img = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
    return img


def random_crop_resize(img, rng=None, size=IMG, min_scale=0.82):
    """Cắt ngẫu nhiên 82-100% rồi resize về size x size: giả lập sai số khung mặt của ML Kit."""
    rng = rng or random
    w, h = img.size
    s = rng.uniform(min_scale, 1.0)
    cw, ch = int(w * s), int(h * s)
    x = rng.randint(0, w - cw) if w > cw else 0
    y = rng.randint(0, h - ch) if h > ch else 0
    return img.crop((x, y, x + cw, y + ch)).resize((size, size), Image.BILINEAR)


def center_resize(img, size=IMG):
    return img.resize((size, size), Image.BILINEAR)


def ahash(img, n=16):
    g = np.asarray(img.convert("L").resize((n, n), Image.BILINEAR), dtype=np.float32)
    return int("".join("1" if v else "0" for v in (g > g.mean()).flatten()), 2)
