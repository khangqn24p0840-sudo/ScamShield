"""Huấn luyện bộ phân loại khuôn mặt thật/giả và xuất TFLite cho app.

    python train_face.py --data data --out exports
    python train_face.py --data data --out exports --arch mobilenetv3large --epochs 12 --finetune-epochs 12

Kết quả trong thư mục --out:
    deepfake.tflite        mô hình cho app (đầu vào [1,224,224,3] float32 0..1 RGB, đầu ra [1,1] = xác suất GIẢ)
    deepfake_meta.json     kích thước đầu vào, viền cắt mặt, tham số hiệu chỉnh (evaluate_face.py sẽ cập nhật)
    best.weights.h5, history.json

Chạy xong PHẢI chạy evaluate_face.py: nó đo độ chính xác thật, chọn ngưỡng, hiệu chỉnh xác suất và ghi lại vào meta.

Thiết kế:
  - Học chuyển giao từ ImageNet (MobileNetV3), hai giai đoạn: đóng băng thân mạng rồi mở khóa tinh chỉnh với lr nhỏ.
  - Mỗi lần nạp ảnh là một lần làm xấu NGẪU NHIÊN (xem common.degrade): thu nhỏ, mờ, JPEG, thiếu sáng, nhiễu.
    Tập val cũng bị làm xấu nhưng CỐ ĐỊNH theo đường dẫn ảnh, để số đo val phản ánh điều kiện của app và ổn định giữa các epoch.
  - Trọng số lớp tự cân bằng khi dữ liệu thật/giả lệch nhau.
  - Chọn mô hình theo val AUC, không theo độ chính xác (độ chính xác phụ thuộc ngưỡng).
"""
import argparse
import csv
import json
import os
import random
import zlib

import numpy as np
import tensorflow as tf
from PIL import Image
from tensorflow import keras
from tensorflow.keras import layers

from common import IMG, MARGIN, SEED, center_resize, degrade, random_crop_resize

ARCH = {
    "mobilenetv3small": keras.applications.MobileNetV3Small,   # ~2.5M tham số, nhanh nhất trên điện thoại (khuyến nghị)
    "mobilenetv3large": keras.applications.MobileNetV3Large,   # chính xác hơn, ~2-3 lần chậm hơn
    "efficientnetb0": keras.applications.EfficientNetB0,
}


def read_manifest(data, split):
    out = []
    with open(os.path.join(data, "manifest.csv"), encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r["split"] == split:
                out.append((os.path.join(data, r["path"]), int(r["label"])))
    return out


def make_ds(items, batch, train, class_w):
    paths = [p for p, _ in items]
    labels = np.array([y for _, y in items], dtype=np.float32)

    def load(p, y):
        def _py(pb, yv):
            path = pb.decode("utf-8")
            img = Image.open(path).convert("RGB")
            if train:
                if random.random() < 0.5:
                    img = img.transpose(Image.FLIP_LEFT_RIGHT)
                img = degrade(random_crop_resize(img))
            else:
                rng = random.Random(zlib.crc32(path.encode()))   # cố định cho từng ảnh val
                img = degrade(center_resize(img), rng)
            return np.asarray(img, dtype=np.float32) / 255.0, np.float32(yv)

        x, yy = tf.numpy_function(_py, [p, y], [tf.float32, tf.float32])
        x.set_shape((IMG, IMG, 3)); yy.set_shape(())
        w = tf.where(yy > 0.5, class_w[1], class_w[0])
        return x, yy, w

    ds = tf.data.Dataset.from_tensor_slices((paths, labels))
    if train:
        ds = ds.shuffle(min(len(items), 20000), seed=SEED, reshuffle_each_iteration=True)
    ds = ds.map(load, num_parallel_calls=tf.data.AUTOTUNE).batch(batch).prefetch(tf.data.AUTOTUNE)
    return ds


def build(arch, weights):
    inp = keras.Input((IMG, IMG, 3), name="face")                 # RGB, 0..1: khớp TfliteDeepfakeClassifier.kt
    x = layers.Rescaling(255.0, name="to_255")(inp)               # các backbone Keras tự chuẩn hóa từ 0..255 bên trong
    base = ARCH[arch](input_shape=(IMG, IMG, 3), include_top=False, weights=weights)
    x = base(x, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(1, activation="sigmoid", name="fake_prob")(x)
    return keras.Model(inp, out), base


def compile_model(model, lr, steps_total=None):
    sched = keras.optimizers.schedules.CosineDecay(lr, steps_total) if steps_total else lr
    model.compile(optimizer=keras.optimizers.Adam(sched),
                  loss=keras.losses.BinaryCrossentropy(label_smoothing=0.05),
                  metrics=[keras.metrics.AUC(name="auc"), keras.metrics.BinaryAccuracy(name="acc")])


def export_tflite(model, val_items, out_dir, meta):
    conv = tf.lite.TFLiteConverter.from_keras_model(model)
    conv.optimizations = [tf.lite.Optimize.DEFAULT]
    conv.target_spec.supported_types = [tf.float16]               # nhỏ một nửa, gần như không mất độ chính xác
    blob = conv.convert()
    path = os.path.join(out_dir, "deepfake.tflite")
    with open(path, "wb") as f:
        f.write(blob)
    # kiểm tra tflite khớp keras trên vài ảnh val (bắt lỗi chuyển đổi/tiền xử lý sớm)
    it = tf.lite.Interpreter(model_path=path); it.allocate_tensors()
    i0, o0 = it.get_input_details()[0], it.get_output_details()[0]
    print("TFLite vào:", i0["shape"], i0["dtype"].__name__, "ra:", o0["shape"])
    diffs = []
    for p, _ in val_items[:16]:
        a = np.asarray(center_resize(Image.open(p).convert("RGB")), dtype=np.float32)[None] / 255.0
        it.set_tensor(i0["index"], a); it.invoke()
        diffs.append(abs(float(it.get_tensor(o0["index"]).flatten()[0]) - float(model.predict(a, verbose=0).flatten()[0])))
    print(f"Lệch lớn nhất keras vs tflite trên 16 ảnh: {max(diffs):.4f} (nên < 0.02)")
    with open(os.path.join(out_dir, "deepfake_meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print(f"Đã ghi {path} ({len(blob) / 1e6:.2f} MB)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="exports")
    ap.add_argument("--arch", choices=list(ARCH), default="mobilenetv3small")
    ap.add_argument("--weights", default="imagenet", help="'imagenet' (cần mạng lần đầu) hoặc 'none'")
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--epochs", type=int, default=5, help="giai đoạn 1: chỉ học đầu phân loại")
    ap.add_argument("--finetune-epochs", type=int, default=10, help="giai đoạn 2: mở khóa toàn bộ thân mạng")
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--finetune-lr", type=float, default=1e-4)
    ap.add_argument("--init-weights", default=None,
                    help="khởi động từ trọng số đã huấn luyện (best.weights.h5) để học thêm dữ liệu mới, dùng với --lr / --finetune-lr nhỏ (3e-4 / 3e-5)")
    a = ap.parse_args()

    random.seed(SEED); np.random.seed(SEED); tf.random.set_seed(SEED)
    os.makedirs(a.out, exist_ok=True)
    tr, va = read_manifest(a.data, "train"), read_manifest(a.data, "val")
    if not tr or not va:
        raise SystemExit("Thiếu dữ liệu train/val. Chạy prepare_dataset.py trước.")
    n1 = sum(y for _, y in tr); n0 = len(tr) - n1
    if n0 == 0 or n1 == 0:
        raise SystemExit("Tập train chỉ có một lớp.")
    class_w = (len(tr) / (2.0 * n0), len(tr) / (2.0 * n1))
    print(f"train: thật={n0} giả={n1}  val: {len(va)}  trọng số lớp: thật={class_w[0]:.2f} giả={class_w[1]:.2f}")

    train_ds = make_ds(tr, a.batch, True, class_w)
    val_ds = make_ds(va, a.batch, False, class_w).map(lambda x, y, w: (x, y))
    model, base = build(a.arch, None if a.weights == "none" else a.weights)
    if a.init_weights:
        model.load_weights(a.init_weights)
        print("Khởi động từ", a.init_weights)

    ckpt = keras.callbacks.ModelCheckpoint(os.path.join(a.out, "best.weights.h5"), monitor="val_auc", mode="max",
                                           save_best_only=True, save_weights_only=True, verbose=1)
    hist = {}

    # ---- giai đoạn 1: chỉ đầu phân loại
    base.trainable = False
    compile_model(model, a.lr)
    h1 = model.fit(train_ds, validation_data=val_ds, epochs=a.epochs, callbacks=[ckpt])
    hist["stage1"] = {k: [float(v) for v in vs] for k, vs in h1.history.items()}

    # ---- giai đoạn 2: tinh chỉnh (giữ BatchNorm đóng băng: ổn định hơn nhiều với batch nhỏ/dữ liệu ít)
    if a.finetune_epochs > 0:
        base.trainable = True
        for l in base.layers:
            if isinstance(l, layers.BatchNormalization):
                l.trainable = False
        steps = max(1, (len(tr) // a.batch)) * a.finetune_epochs
        compile_model(model, a.finetune_lr, steps)
        stop = keras.callbacks.EarlyStopping(monitor="val_auc", mode="max", patience=4, restore_best_weights=False)
        h2 = model.fit(train_ds, validation_data=val_ds, epochs=a.finetune_epochs, callbacks=[ckpt, stop])
        hist["stage2"] = {k: [float(v) for v in vs] for k, vs in h2.history.items()}
    with open(os.path.join(a.out, "history.json"), "w") as f:
        json.dump(hist, f, indent=2)

    best = os.path.join(a.out, "best.weights.h5")
    if os.path.exists(best):
        model.load_weights(best)
    meta = {"version": 1, "arch": a.arch, "input": IMG, "cropMargin": MARGIN, "fakeIndex": 0,
            "platt": [1.0, 0.0], "threshold": 0.5,
            "note": "platt/threshold sẽ được evaluate_face.py ghi đè sau khi đo trên tập val"}
    export_tflite(model, va, a.out, meta)
    print("\nBƯỚC TIẾP: python evaluate_face.py --data", a.data, "--out", a.out)


if __name__ == "__main__":
    main()
