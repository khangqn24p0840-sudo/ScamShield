"""Biến thư mục ảnh/video thô thành tập huấn luyện khuôn mặt (đã cắt mặt, đã chia train/val/test).

Cấu trúc đầu vào:
    raw/
      real/<nguồn>/*.jpg|png|mp4|mov|avi     # nguồn = bộ dữ liệu hoặc nhóm người, ví dụ ffhq, celeba, cuocgoi_that
      fake/<bộ_tạo>/*.jpg|png|mp4|mov|avi    # bộ_tạo = công cụ tạo giả, ví dụ stylegan, sdxl, faceswap_roop, deepfacelive

Đầu ra:
    out/images/<real|fake>/<nguồn>/<nhóm>_<k>.jpg
    out/manifest.csv   (path,label,source,group,split)      label: 0 = thật, 1 = giả

Điểm khác biệt quan trọng so với cách làm "cho vui":
  1. CHIA THEO NHÓM, không chia theo ảnh: mọi khung hình của cùng một video (hoặc cùng một người, nếu bạn đưa --group-regex)
     nằm trong cùng một tập. Nếu không, mô hình thuộc lòng gương mặt và độ chính xác ảo 99% rồi sập ngoài đời.
  2. MÃ HÓA LẠI ĐỒNG NHẤT: mọi ảnh đều giải mã -> cắt mặt -> lưu JPEG chất lượng 95, cùng kích thước. Nếu ảnh thật là JPEG
     còn ảnh giả là PNG, mô hình sẽ học định dạng tệp thay vì học dấu vết giả mạo.
  3. --holdout-generator: giữ nguyên một bộ tạo giả (ví dụ một công cụ face-swap) ra khỏi huấn luyện để đo khả năng
     nhận diện công cụ MỚI. Đây là con số thật nhất để biết mô hình có dùng được ngoài đời hay không.

Ví dụ:
    python prepare_dataset.py --raw raw --out data
    python prepare_dataset.py --raw raw --out data --holdout-generator deepfacelive --video-fps 2 --max-frames 40
    # FaceForensics++: tên file '123.mp4' (thật) và '123_456.mp4' (giả) -> gom theo id đầu tiên
    python prepare_dataset.py --raw raw --out data --group-regex "^(\\d+)"
"""
import argparse
import csv
import hashlib
import os
import re
import sys
from collections import Counter, defaultdict

import cv2
import numpy as np
from PIL import Image

from common import STORE, MARGIN, expand_box, ahash

IMG_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
VID_EXT = {".mp4", ".mov", ".avi", ".mkv", ".webm"}


class Detector:
    """Haar cascade đi kèm opencv: không cần tải thêm gì, nhưng yếu với mặt nghiêng/thiếu sáng.
    Nếu bạn có bộ phát hiện tốt hơn (RetinaFace, MediaPipe, YuNet), thay hàm find() là xong."""

    def __init__(self):
        d = cv2.data.haarcascades
        self.front = cv2.CascadeClassifier(os.path.join(d, "haarcascade_frontalface_default.xml"))
        self.prof = cv2.CascadeClassifier(os.path.join(d, "haarcascade_profileface.xml"))

    def find(self, bgr):
        g = cv2.equalizeHist(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY))
        mn = max(48, min(g.shape) // 8)
        boxes = list(self.front.detectMultiScale(g, 1.1, 5, minSize=(mn, mn)))
        if not boxes:
            boxes = list(self.prof.detectMultiScale(g, 1.1, 5, minSize=(mn, mn)))
        if not boxes:                                          # mặt quay sang phía còn lại: lật ảnh
            fl = cv2.flip(g, 1)
            for (x, y, w, h) in self.prof.detectMultiScale(fl, 1.1, 5, minSize=(mn, mn)):
                boxes.append((g.shape[1] - x - w, y, w, h))
        if not boxes:
            return None
        return max(boxes, key=lambda b: b[2] * b[3])           # mặt lớn nhất


def crop_face(bgr, det, assume_cropped):
    h, w = bgr.shape[:2]
    if assume_cropped:                                          # bộ dữ liệu đã căn mặt sẵn (FFHQ, 140k faces...)
        l, t, r, b = 0, 0, w, h
    else:
        box = det.find(bgr)
        if box is None:
            return None
        l, t, r, b = expand_box(*[int(v) for v in box], w, h, MARGIN)
    face = bgr[t:b, l:r]
    if face.size == 0 or min(face.shape[:2]) < 40:
        return None
    rgb = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb).resize((STORE, STORE), Image.LANCZOS)


def bucket(group, seed):
    return int(hashlib.md5(f"{seed}:{group}".encode()).hexdigest(), 16) % 1000 / 1000.0


def split_of(group, args):
    u = bucket(group, args.seed)
    if u < args.test_frac:
        return "test"
    if u < args.test_frac + args.val_frac:
        return "val"
    return "train"


def iter_frames(path, fps, max_frames):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        return
    src = cap.get(cv2.CAP_PROP_FPS) or 25.0
    step = max(1, int(round(src / fps)))
    i = n = 0
    while n < max_frames:
        ok, fr = cap.read()
        if not ok:
            break
        if i % step == 0:
            yield fr
            n += 1
        i += 1
    cap.release()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--val-frac", type=float, default=0.1)
    ap.add_argument("--test-frac", type=float, default=0.1)
    ap.add_argument("--video-fps", type=float, default=2.0, help="số khung lấy mỗi giây video")
    ap.add_argument("--max-frames", type=int, default=30, help="tối đa khung mỗi video (tránh một video chi phối)")
    ap.add_argument("--group-regex", default=None, help="regex trên TÊN FILE (không đuôi); nhóm 1 là khóa gom nhóm")
    ap.add_argument("--assume-cropped", nargs="*", default=[], metavar="NGUỒN",
                    help="các nguồn đã là ảnh mặt căn sẵn: bỏ qua bước phát hiện mặt")
    ap.add_argument("--holdout-generator", nargs="*", default=[], metavar="BỘ_TẠO",
                    help="bộ tạo giả dành riêng cho kiểm tra 'công cụ chưa từng thấy' (split = test_unseen)")
    ap.add_argument("--max-per-source", type=int, default=0, help="giới hạn số ảnh mỗi nguồn (0 = không giới hạn)")
    ap.add_argument("--seed", type=int, default=1337)
    a = ap.parse_args()

    det = Detector()
    rx = re.compile(a.group_regex) if a.group_regex else None
    rows, skipped, seen = [], Counter(), {}
    for label_name, label in (("real", 0), ("fake", 1)):
        root = os.path.join(a.raw, label_name)
        if not os.path.isdir(root):
            sys.exit(f"Thiếu thư mục {root}")
        for source in sorted(os.listdir(root)):
            sdir = os.path.join(root, source)
            if not os.path.isdir(sdir):
                continue
            files = sorted(os.path.join(dp, f) for dp, _, fs in os.walk(sdir) for f in fs
                           if os.path.splitext(f)[1].lower() in IMG_EXT | VID_EXT)
            if a.max_per_source:
                rng = np.random.RandomState(a.seed)
                rng.shuffle(files); files = files[:a.max_per_source]
            print(f"{label_name}/{source}: {len(files)} tệp")
            outdir = os.path.join(a.out, "images", label_name, source)
            os.makedirs(outdir, exist_ok=True)
            for fp in files:
                stem, ext = os.path.splitext(os.path.basename(fp))
                m = rx.search(stem) if rx else None
                group = m.group(1) if m else f"{label_name}_{source}_{stem}"
                if label == 1 and source in a.holdout_generator:
                    split = "test_unseen"
                else:
                    split = split_of(group, a)
                kind = "video" if ext.lower() in VID_EXT else "image"
                if kind == "video":
                    frames = iter_frames(fp, a.video_fps, a.max_frames)
                else:
                    im = cv2.imread(fp)
                    frames = [im] if im is not None else []
                for k, fr in enumerate(frames):
                    face = crop_face(fr, det, source in a.assume_cropped)
                    if face is None:
                        skipped[f"{label_name}/{source}"] += 1
                        continue
                    h = ahash(face)
                    if h in seen and seen[h] != split:        # gần như trùng lặp mà rơi vào tập khác -> rò rỉ, bỏ
                        skipped["trùng_lặp"] += 1
                        continue
                    seen[h] = split
                    name = hashlib.md5(group.encode()).hexdigest()[:10] + f"_{stem[:24]}_{k}.jpg"
                    rel = os.path.join("images", label_name, source, name)
                    face.save(os.path.join(a.out, rel), quality=95)
                    rows.append([rel.replace("\\", "/"), label, source, group, split, kind])

    with open(os.path.join(a.out, "manifest.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["path", "label", "source", "group", "split", "kind"]); w.writerows(rows)

    print(f"\nĐã ghi {len(rows)} ảnh vào {a.out}/manifest.csv")
    tab = defaultdict(Counter)
    kinds = defaultdict(Counter)
    for _, lab, _, _, sp, kd in rows:
        tab[sp][lab] += 1
        kinds[lab][kd] += 1
    for sp in ("train", "val", "test", "test_unseen"):
        if sp in tab:
            print(f"  {sp:12s} thật={tab[sp][0]:6d}  giả={tab[sp][1]:6d}")
    if skipped:
        print("Bỏ qua (không thấy mặt / trùng lặp):", dict(skipped))
    for sp in ("train", "val", "test"):
        if sp not in tab or tab[sp][0] == 0 or tab[sp][1] == 0:
            print(f"CẢNH BÁO: tập {sp} thiếu một lớp. Thêm dữ liệu hoặc đổi --seed.")
    # Lối tắt nguy hiểm: thật toàn là khung VIDEO, giả toàn là ẢNH tĩnh (hoặc ngược lại) -> mô hình học "nguồn" chứ không học "giả"
    def share_video(lab):
        n = sum(kinds[lab].values()); return kinds[lab]["video"] / n if n else 0.0
    sv0, sv1 = share_video(0), share_video(1)
    if abs(sv0 - sv1) > 0.6:
        print(f"\n!!! CẢNH BÁO LỚN: lớp thật có {sv0:.0%} khung từ video, lớp giả có {sv1:.0%}. Mô hình sẽ học phân biệt "
              "'khung video' và 'ảnh tĩnh' thay vì thật/giả, và sập khi gặp video call thật.\n"
              "    Cách sửa: đưa CẢ HAI lớp từ cùng loại nguồn (ví dụ video thật + video giả, hoặc ảnh thật + ảnh giả); "
              "ảnh AI tĩnh chỉ nên là một phần phụ của lớp giả.")
    print("Tỷ lệ thật:giả lệch quá 1:3 thì train_face.py sẽ tự cân bằng bằng trọng số lớp, nhưng tốt nhất vẫn nên cân đối.")


if __name__ == "__main__":
    main()
