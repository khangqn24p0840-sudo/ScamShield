# Huấn luyện mô hình nhận diện khuôn mặt giả cho ScamShield

Thư mục này là pipeline hoàn chỉnh: **dữ liệu thô → tập huấn luyện sạch → mô hình TFLite → đánh giá trung thực → nhét vào app**.

```
raw/ ──prepare_dataset.py──► data/ ──train_face.py──► exports/deepfake.tflite ──evaluate_face.py──► (meta + báo cáo)
                                                                                         │
                                          app/src/main/assets/  ◄── chép deepfake.tflite + deepfake_meta.json
```

## 0. Hiểu đúng bài toán trước khi thu dữ liệu

"Ảnh AI" có hai loại rất khác nhau, và **app của bạn cần loại thứ hai**:

| Loại | Ví dụ | Có trong video call lừa đảo? |
|---|---|---|
| Mặt **tạo hoàn toàn** từ nhiễu | StyleGAN, Stable Diffusion, Midjourney | Hiếm (hay gặp ở ảnh đại diện giả) |
| Mặt **hoán đổi** lên người thật, thời gian thực | DeepFaceLive, FaceFusion, các app đổi mặt | **Đây là thủ đoạn chính**: kẻ lừa đảo gọi video, đeo mặt người quen |

Hệ quả: nếu chỉ huấn luyện bằng ảnh StyleGAN/diffusion, mô hình sẽ đạt 99% trên chính loại đó rồi **gần như vô dụng** với face-swap trong cuộc gọi. Hai loại để lại dấu vết khác hẳn nhau. Hãy đưa **cả hai** vào `fake/`, nhưng ưu tiên số lượng và độ đa dạng của face-swap, đặc biệt là face-swap **đã bị nén qua video call**.

## 1. Chuẩn bị môi trường

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
TensorFlow cần Python 3.9-3.12 cho bản cũ (≤2.15); Python 3.13 cần TensorFlow mới (≥2.20). Nếu cài lỗi, tạo venv bằng Python 3.11. GPU không bắt buộc nhưng rút ngắn huấn luyện từ hàng giờ xuống vài phút (Google Colab miễn phí là đủ).

## 2. Thu dữ liệu

Cấu trúc thư mục (tên thư mục con = tên nguồn, dùng để báo cáo riêng từng nguồn):

```
raw/
  real/
    ffhq/            ảnh mặt thật (đã căn sẵn)
    cuoc_goi_that/   video/ảnh chụp từ cuộc gọi thật (Zalo, Messenger, Meet) với người tình nguyện
  fake/
    stylegan/        mặt tạo hoàn toàn
    sdxl/
    faceswap_a/      video/ảnh hoán đổi mặt, công cụ A
    faceswap_b/      công cụ B  <- nên có ít nhất 3 công cụ khác nhau
```

**Nguồn công khai thường dùng** (tự kiểm tra giấy phép; nhiều bộ yêu cầu điền form xin quyền, chỉ dùng cho nghiên cứu):
FaceForensics++, Celeb-DF v2, DFDC, DF40, WildDeepfake (deepfake video); FFHQ, CelebA (mặt thật); các bộ "real vs fake faces" trên Kaggle (mặt tạo hoàn toàn).
Các bộ này **phần lớn nhận diện kiểu phương Tây, chất lượng cao**. Mặt người Việt, camera điện thoại tầm trung, mạng yếu thì ít.

**Tự tạo dữ liệu sát thực tế (quan trọng nhất, và thường quyết định mô hình dùng được hay không):**

- *Thật:* nhờ bạn bè/gia đình **đã đồng ý** gọi video với bạn trên Zalo/Messenger, đủ điều kiện: ánh sáng yếu, mạng chậm, đeo kính, khẩu trang, quay nghiêng, nhiều kiểu điện thoại. Quay màn hình cuộc gọi.
- *Giả:* tự tạo face-swap bằng công cụ mã nguồn mở, **chỉ dùng mặt của chính bạn hoặc người đã đồng ý bằng văn bản**; gọi video thật qua cùng ứng dụng rồi quay màn hình, để dấu vết nén giống y hệt cuộc gọi thật.
- Tuyệt đối không dùng ảnh/video người khác khi chưa được đồng ý, và không đưa dữ liệu mặt người lên dịch vụ bên thứ ba.

**Cỡ dữ liệu gợi ý:** tối thiểu ~5.000 ảnh mỗi lớp để thấy mô hình học được; 30.000+ mỗi lớp để ra mô hình dùng được. Quan trọng hơn số ảnh là **số video/người/công cụ khác nhau**: 50 video × 30 khung kém xa 1.500 video × 1 khung.

## 3. Chuẩn bị tập dữ liệu

```bash
python prepare_dataset.py --raw raw --out data \
    --assume-cropped ffhq stylegan sdxl \
    --holdout-generator faceswap_b
```
- `--assume-cropped`: các nguồn đã là ảnh mặt căn sẵn, bỏ bước dò mặt (FFHQ, StyleGAN... là ảnh mặt cận cảnh).
- `--holdout-generator`: **giữ riêng một công cụ giả ra khỏi huấn luyện** để đo khả năng nhận diện công cụ *chưa từng thấy*. Xem mục 5.
- Video FaceForensics++: thêm `--group-regex "^(\d+)"` để video thật `123.mp4` và video giả `123_456.mp4` cùng vào một tập.
- Bộ dò mặt mặc định là Haar cascade của OpenCV (không phải tải gì thêm) nhưng yếu với mặt nghiêng và thiếu sáng; nếu có thể hãy thay hàm `Detector.find()` bằng RetinaFace/YuNet/MediaPipe.

Script làm ba việc để tránh những lỗi kinh điển khiến "độ chính xác 99%" là ảo:
1. **Chia theo nhóm** (cả video, hoặc cả một người): mọi khung của một video chỉ nằm ở một tập.
2. **Mã hóa lại đồng nhất**: mọi ảnh → cắt mặt → JPEG q95 cùng cỡ. Nếu ảnh thật là JPEG còn ảnh giả là PNG, mô hình sẽ học *định dạng tệp*.
3. **Loại ảnh gần trùng** nằm ở hai tập khác nhau.

## 4. Huấn luyện

```bash
python train_face.py --data data --out exports                 # mặc định: MobileNetV3-Small
python train_face.py --data data --out exports --arch mobilenetv3large --epochs 8 --finetune-epochs 15
```
Mô hình học chuyển giao từ ImageNet, hai giai đoạn (học đầu phân loại → mở khóa tinh chỉnh). Mỗi lần nạp ảnh bị **làm xấu ngẫu nhiên** (thu nhỏ rồi phóng lại, mờ, nén JPEG, thiếu sáng, nhiễu) để mô phỏng đúng điều kiện app: app chụp màn hình ở **nửa độ phân giải**, mặt trong ô video thường chỉ vài chục pixel và đã qua nén H.264. Việc làm xấu áp dụng đồng đều cho cả thật lẫn giả, nếu chỉ làm xấu một lớp, mô hình học "ảnh xấu = giả".

Kết quả: `exports/deepfake.tflite` (float16, vài MB) và `exports/deepfake_meta.json`. Script tự kiểm tra bản TFLite cho cùng kết quả với bản Keras (lệch lớn nhất nên < 0.02).

## 5. Đánh giá, và đọc kết quả cho đúng

```bash
python evaluate_face.py --data data --out exports                  # ngưỡng: ~2% khung thật bị báo nhầm
python evaluate_face.py --data data --out exports --target-fpr 0.01
```
Script đo bản **TFLite thật** (đúng thứ app chạy), chọn ngưỡng và hiệu chỉnh xác suất **trên tập val** (không đụng test), rồi ghi `platt` vào `deepfake_meta.json`. App đọc giá trị này nên xác suất 0.5 đã tương ứng đúng điểm vận hành bạn chọn.

Cách đọc báo cáo:

| Mục | Ý nghĩa | Cảnh báo |
|---|---|---|
| `test` | công cụ giả đã thấy khi train | số đẹp, **đừng dùng để báo cáo** |
| **`test_unseen`** | công cụ giả *chưa từng thấy* | **con số thật**. Rớt từ 99% xuống 60-75% là bình thường và là sự thật của lĩnh vực này |
| mức video | trung bình theo nhóm | giống cách app gộp 30 giây, thường cao hơn mức khung hình |
| Độ bền | AUC khi nén q30, thu nhỏ, mờ... | rớt mạnh = mô hình chưa hợp video call thật |

Mục tiêu hợp lý: `test_unseen` mức video đạt AUC ≥ 0.85 thì đã có giá trị làm *một chỉ báo*. Hãy lưu ý rằng nó **không phải bộ phát hiện chắc chắn**; app vẫn luôn kèm các thử thách chủ động (quay nghiêng mặt, quét tay trước mặt) và nhắc xác minh bằng kênh khác.

## 6. Đưa vào app

Cách dễ nhất, **không cần cáp, ADB hay build lại APK**:
1. Chạy `python retrain.py --raw raw` (hoặc từng bước 3-5). Cuối cùng có thư mục `mo_hinh_cho_app/` chứa **hai tệp**: `deepfake.tflite` và `deepfake_meta.json`.
2. Chép hai tệp sang điện thoại (cáp USB, Zalo "Cloud của tôi", Google Drive...).
3. Mở app → **Kiểm tra Deepfake** → bấm **"Nạp mô hình khuôn mặt từ tệp"** → chọn **cả hai tệp** (giữ ngón tay để chọn nhiều tệp).
4. App kiểm tra tệp; hợp lệ mới thay bản cũ, lỗi thì giữ nguyên bản cũ. Bấm **Dừng** rồi **Bắt đầu kiểm tra** lại: dòng trạng thái báo "Mô hình AI khuôn mặt: đang dùng (ngoài APK)".

Cách cố định vào APK: chép hai tệp vào `app/src/main/assets/` rồi build lại. App ưu tiên bản đã nạp bằng nút; bản lỗi thì tự quay về bản trong APK.

**Lỗi hay gặp:** mô hình không nạp, trạng thái báo "Chưa có mô hình". Nguyên nhân thường là TFLite trên máy phát triển *mới hơn* thư viện trong app (`org.tensorflow:tensorflow-lite:2.14.0`), gây lỗi kiểu `Didn't find op for builtin opcode 'FULLY_CONNECTED' version '12'`. Cách xử lý: nâng phiên bản dependency trong `app/build.gradle.kts` lên bản mới hơn (ví dụ `2.16.1`), hoặc cài TensorFlow cùng thế hệ với 2.14 khi huấn luyện. Có `adb logcat` sẽ thấy dòng lỗi.

## 7. Cơ chế trong app (đã nối sẵn)

- `TfliteDeepfakeClassifier.kt`: nạp mô hình + meta, cắt mặt đúng viền `cropMargin` như lúc huấn luyện, hiệu chỉnh xác suất bằng Platt.
- `FaceObserver`: chạy mô hình ở mỗi khung thứ hai (đủ dữ liệu, nhẹ pin).
- `FaceLivenessAnalyzer` có hai chỉ báo mới từ mô hình:
  - **`model`**: trung vị + tỉ lệ khung bị chấm giả trong 30 giây (một mặt giả thật bị chấm giả *đều đặn*, mặt thật chỉ thỉnh thoảng bị).
  - **`profile`**: điểm "giả" khi mặt quay ≥30° so với nhìn thẳng. Face-swap hay lộ nhất ở góc nghiêng.
  - Hai chỉ báo này cùng một nguồn nên chỉ tính là **một** bằng chứng độc lập; mức "cao" luôn cần ít nhất hai nguồn.
- Hiệu chỉnh trọng số theo dữ liệu thật của bạn: bật "Ghi số liệu để hiệu chỉnh" trong app, thu log (các cột `model`, `profile` đã có), rồi chạy `ml/face_calibrate.py` như cũ.

## 8. Vòng cải thiện (nơi độ chính xác thực sự đến từ đó)

1. Chạy app trong cuộc gọi thật (có sự đồng ý) → thấy chỗ báo nhầm/bỏ sót.
2. Lưu các khung bị sai (có đồng ý của người trong ảnh) vào `raw/real/` hoặc `raw/fake/` → huấn luyện lại. Đây là *hard-negative mining*, thường tăng chất lượng nhiều hơn đổi kiến trúc.
3. Mỗi khi xuất hiện công cụ face-swap mới, thêm vào `fake/` và lặp lại. Phát hiện deepfake là cuộc chạy đua: mô hình cũ sẽ lỗi thời.

**Hướng nâng cấp tiếp theo** (thứ tự hiệu quả/công sức): mô hình nhận chuỗi 8-16 khung thay vì từng khung (bắt được nhấp nháy theo thời gian); thêm cặp thử thách chủ động có chấm điểm trong app; đồng bộ môi - tiếng khi có âm thanh; tín hiệu mạch máu trên da (rPPG) làm chỉ báo phụ.

## 9. Chỉ có vài video và ảnh AI thì sao?

**Mô hình không thể học từ 2-3 video.** Hai ba video chỉ là vài trăm khung gần như giống hệt nhau; mô hình sẽ thuộc lòng đúng những video đó (độ chính xác ảo rất cao) rồi sai ngay khi gặp người khác. Ngoài ra chia theo video thì tập kiểm tra gần như trống, nên không đo được gì.

Vài video và ảnh của bạn **dùng được cho ba việc có ích**:
1. **Bổ sung vào bộ dữ liệu lớn hơn** (vài trăm video/vài nghìn ảnh từ bộ công khai và tự quay), không dùng một mình.
2. **Học thêm các ca app đang chẩn đoán sai** (xem dưới).
3. **Làm tập thử riêng** (không huấn luyện): cho app xem các video đó, xem điểm có đúng không.

**Cạm bẫy phải tránh:** thật = video, giả = ảnh AI tĩnh. Mô hình sẽ học "có dấu vết nén video = thật, ảnh sạch = giả", chứ không học thật/giả. `prepare_dataset.py` sẽ in cảnh báo đỏ khi gặp tình huống này. Cả hai lớp phải cùng loại nguồn: video thật với video giả (face-swap trong cuộc gọi), ảnh thật với ảnh AI. Ảnh AI tĩnh chỉ dạy mô hình nhận ảnh AI tĩnh, không giúp nhận face-swap trong video call.

**Vòng sửa chẩn đoán sai:**
1. App báo sai một cuộc gọi → quay lại video đó (người trong video đồng ý), cho vào `raw/real/ca_sai/` nếu thật bị báo giả, hoặc `raw/fake/ca_sai/` nếu giả bị bỏ sót.
2. Chạy `python retrain.py --raw raw --continue-from exports`: học tiếp từ mô hình cũ với tốc độ học nhỏ, không bắt đầu lại từ đầu.
3. Nạp hai tệp mới vào app (mục 6), thử lại đúng video cũ **và** vài video khác để chắc là không sửa chỗ này làm hỏng chỗ khác.
