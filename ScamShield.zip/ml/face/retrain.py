"""Chạy trọn quy trình bằng MỘT lệnh: chuẩn bị dữ liệu -> huấn luyện -> đánh giá -> gom hai tệp cần nạp vào app.

    python retrain.py --raw raw
    python retrain.py --raw raw --holdout-generator faceswap_b           # giữ một công cụ giả ra để đo công cụ lạ
    python retrain.py --raw raw --continue-from exports                  # học thêm từ mô hình cũ (sau khi bổ sung ca sai)

Kết quả: thư mục  mo_hinh_cho_app/  chứa deepfake.tflite + deepfake_meta.json
Chép hai tệp đó sang điện thoại, mở app -> Kiểm tra Deepfake -> "Nạp mô hình khuôn mặt từ tệp" -> chọn CẢ HAI tệp.
"""
import argparse
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def run(*args):
    cmd = [sys.executable, *args]
    print("\n$", " ".join(cmd), flush=True)
    r = subprocess.run(cmd, cwd=HERE)
    if r.returncode != 0:
        sys.exit(f"Dừng: bước '{os.path.basename(args[0])}' lỗi (mã {r.returncode}).")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw", required=True, help="thư mục raw/ có real/ và fake/")
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="exports")
    ap.add_argument("--deliver", default="mo_hinh_cho_app")
    ap.add_argument("--holdout-generator", nargs="*", default=[])
    ap.add_argument("--assume-cropped", nargs="*", default=[])
    ap.add_argument("--continue-from", default=None, help="thư mục exports cũ (có best.weights.h5) để học tiếp")
    ap.add_argument("--target-fpr", type=float, default=0.02)
    a = ap.parse_args()

    prep = ["prepare_dataset.py", "--raw", a.raw, "--out", a.data]
    if a.holdout_generator:
        prep += ["--holdout-generator", *a.holdout_generator]
    if a.assume_cropped:
        prep += ["--assume-cropped", *a.assume_cropped]
    run(*prep)

    train = ["train_face.py", "--data", a.data, "--out", a.out]
    if a.continue_from:
        w = os.path.join(a.continue_from, "best.weights.h5")
        if not os.path.exists(os.path.join(HERE, w)) and not os.path.exists(w):
            sys.exit(f"Không thấy {w}")
        train += ["--init-weights", w, "--lr", "3e-4", "--finetune-lr", "3e-5", "--epochs", "2", "--finetune-epochs", "6"]
    run(*train)
    run("evaluate_face.py", "--data", a.data, "--out", a.out, "--target-fpr", str(a.target_fpr))

    dst = os.path.join(HERE, a.deliver)
    os.makedirs(dst, exist_ok=True)
    for f in ("deepfake.tflite", "deepfake_meta.json"):
        shutil.copy(os.path.join(HERE, a.out, f), os.path.join(dst, f))
    print(f"\nXONG. Hai tệp cần nạp vào app nằm ở: {dst}")
    print("Trên điện thoại: Kiểm tra Deepfake -> 'Nạp mô hình khuôn mặt từ tệp' -> chọn CẢ HAI tệp -> Bắt đầu kiểm tra lại.")
    print("ĐỌC báo cáo ở trên (đặc biệt test_unseen) trước khi tin mô hình.")


if __name__ == "__main__":
    main()
