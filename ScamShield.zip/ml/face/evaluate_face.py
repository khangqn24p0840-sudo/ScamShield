"""Đo mô hình TFLite ĐÚNG như app sẽ chạy, chọn ngưỡng, hiệu chỉnh xác suất, ghi lại vào deepfake_meta.json.

    python evaluate_face.py --data data --out exports
    python evaluate_face.py --data data --out exports --target-fpr 0.01     # chặt hơn: ít báo nhầm hơn, bỏ sót nhiều hơn

Báo cáo gồm:
  1. Mức khung hình và mức video (trung bình theo nhóm - giống cách app gộp 30 giây): AUC, EER, TPR tại FPR 1% / 5%.
  2. Tập 'test_unseen' (công cụ giả CHƯA TỪNG thấy khi train): con số quan trọng nhất. Thường thấp hơn test thường rất nhiều.
  3. Từng nguồn: tỷ lệ phát hiện của từng bộ tạo giả, tỷ lệ báo nhầm của từng nguồn thật.
  4. Độ bền: đo lại khi ảnh bị nén JPEG mạnh, thu nhỏ, làm mờ, thiếu sáng.
Ngưỡng chọn trên tập VAL (không phải test) để số đo test không bị 'lọt' thông tin.
"""
import argparse
import csv
import json
import os
import random
import zlib
from collections import defaultdict

import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, roc_curve

from common import IMG, center_resize, degrade, jpeg_roundtrip


def load_interpreter(path):
    try:
        from tflite_runtime.interpreter import Interpreter
    except ImportError:
        import tensorflow as tf
        Interpreter = tf.lite.Interpreter
    it = Interpreter(model_path=path)
    it.allocate_tensors()
    return it


def predict(it, imgs, fake_index=0):
    i0, o0 = it.get_input_details()[0], it.get_output_details()[0]
    out = []
    for im in imgs:
        a = (np.asarray(im, dtype=np.float32) / 255.0)[None]
        it.set_tensor(i0["index"], a); it.invoke()
        out.append(float(it.get_tensor(o0["index"]).flatten()[fake_index]))
    return np.array(out)


def metrics(y, p):
    """AUC, EER, TPR tại FPR 1%/5%. Trả về dict; None nếu chỉ có một lớp."""
    y = np.asarray(y); p = np.asarray(p)
    if len(set(y.tolist())) < 2:
        return None
    fpr, tpr, _ = roc_curve(y, p)
    fnr = 1 - tpr
    i = int(np.nanargmin(np.abs(fnr - fpr)))
    return {"auc": float(roc_auc_score(y, p)), "eer": float((fpr[i] + fnr[i]) / 2),
            "tpr@1%fpr": float(np.interp(0.01, fpr, tpr)), "tpr@5%fpr": float(np.interp(0.05, fpr, tpr)), "n": int(len(y))}


def video_level(y, p, groups):
    d = defaultdict(list); lab = {}
    for yi, pi, g in zip(y, p, groups):
        d[g].append(pi); lab[g] = yi
    ks = list(d)
    return np.array([lab[k] for k in ks]), np.array([np.mean(d[k]) for k in ks])


def logit(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


STRESS = {
    "sach": lambda im: im,
    "jpeg_q30": lambda im: jpeg_roundtrip(im, 30),
    "thu_nho_0.3": lambda im: im.resize((max(16, int(IMG * .3)),) * 2, Image.BILINEAR).resize((IMG, IMG), Image.BILINEAR),
    "mo": lambda im: im.filter(ImageFilter.GaussianBlur(1.5)),
    "thieu_sang": lambda im: ImageEnhance.Brightness(im).enhance(0.55),
    "tong_hop": lambda im: jpeg_roundtrip(im.resize((int(IMG * .4),) * 2).resize((IMG, IMG)), 35),
}


def read_split(data, split):
    rows = []
    with open(os.path.join(data, "manifest.csv"), encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r["split"] == split:
                rows.append(r)
    return rows


def run(it, data, rows, tf_img, fi):
    imgs = [tf_img(center_resize(Image.open(os.path.join(data, r["path"])).convert("RGB"))) for r in rows]
    return predict(it, imgs, fi)


def val_degrade(im, path):
    return degrade(im, random.Random(zlib.crc32(path.encode())))   # giống tập val khi train


def pct(x):
    return f"{100 * x:5.1f}%"


def show(name, m):
    if m is None:
        print(f"  {name:28s} (thiếu một lớp)"); return
    print(f"  {name:28s} AUC={m['auc']:.3f}  EER={pct(m['eer'])}  TPR@1%FPR={pct(m['tpr@1%fpr'])}  TPR@5%FPR={pct(m['tpr@5%fpr'])}  n={m['n']}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="exports")
    ap.add_argument("--target-fpr", type=float, default=0.02,
                    help="tỷ lệ báo nhầm mong muốn trên KHUNG HÌNH thật; ngưỡng được chọn để đạt mức này")
    a = ap.parse_args()

    meta_path = os.path.join(a.out, "deepfake_meta.json")
    meta = json.load(open(meta_path, encoding="utf-8"))
    fi = int(meta.get("fakeIndex", 0))
    it = load_interpreter(os.path.join(a.out, "deepfake.tflite"))

    # ---- 1. hiệu chỉnh trên VAL (đã làm xấu cố định như lúc train)
    val = read_split(a.data, "val")
    yv = np.array([int(r["label"]) for r in val])
    pv_raw = predict(it, [val_degrade(center_resize(Image.open(os.path.join(a.data, r["path"])).convert("RGB")), os.path.join(a.data, r["path"])) for r in val], fi)
    lr = LogisticRegression(C=1e4, class_weight="balanced", max_iter=1000).fit(logit(pv_raw)[:, None], yv)
    A, B = float(lr.coef_[0][0]), float(lr.intercept_[0])
    if A <= 0:
        raise SystemExit("Mô hình không phân biệt được thật/giả trên tập val (hệ số hiệu chỉnh <= 0). Không ghi meta. "
                         "Kiểm tra dữ liệu/nhãn hoặc huấn luyện lại.")
    cal = 1 / (1 + np.exp(-(A * logit(pv_raw) + B)))
    real_scores = np.sort(cal[yv == 0])
    t = float(np.quantile(real_scores, 1 - a.target_fpr))        # ngưỡng để chỉ a.target_fpr khung thật vượt qua
    t = float(np.clip(t, 0.05, 0.95))
    B2 = B - float(logit(np.array([t]))[0])                       # dời để ngưỡng vận hành ứng với xác suất 0.5
    print(f"Hiệu chỉnh Platt: a={A:.3f} b={B2:.3f}; ngưỡng vận hành (FPR≈{a.target_fpr:.0%} khung thật) -> p=0.5 sau hiệu chỉnh")

    def calibrated(p):
        return 1 / (1 + np.exp(-(A * logit(p) + B2)))

    report = {"platt": [A, B2], "target_fpr": a.target_fpr}
    for split in ("test", "test_unseen"):
        rows = read_split(a.data, split)
        if not rows:
            continue
        if split == "test_unseen":                                # cặp với phần THẬT của tập test để có hai lớp
            rows = rows + [r for r in read_split(a.data, "test") if r["label"] == "0"]
        print(f"\n=== {split} ({len(rows)} ảnh) ===")
        y = np.array([int(r["label"]) for r in rows])
        grp = [r["group"] for r in rows]
        raw = run(it, a.data, rows, lambda im: im, fi)
        p = calibrated(raw)
        m_f, m_v = metrics(y, p), None
        yy, pp = video_level(y, p, grp)
        m_v = metrics(yy, pp)
        show("mức khung hình", m_f); show("mức video/nhóm (trung bình)", m_v)
        flagged = p >= 0.5
        print(f"  Tại ngưỡng vận hành: bỏ sót giả = {pct(1 - flagged[y == 1].mean()) if (y == 1).any() else '—'}, "
              f"báo nhầm thật = {pct(flagged[y == 0].mean()) if (y == 0).any() else '—'}")
        per = defaultdict(list)
        for r, f in zip(rows, flagged):
            per[(r["label"], r["source"])].append(f)
        for (lab, src), fl in sorted(per.items()):
            tag = "GIẢ " if lab == "1" else "THẬT"
            what = "phát hiện" if lab == "1" else "báo nhầm"
            print(f"    {tag} {src:24s} {what} {pct(np.mean(fl))}  (n={len(fl)})")
        report[split] = {"frame": m_f, "video": m_v}

    # ---- 3. độ bền (trên test thường)
    rows = read_split(a.data, "test")
    if rows:
        print("\n=== Độ bền khi ảnh xấu đi (AUC mức khung hình, test) ===")
        y = np.array([int(r["label"]) for r in rows])
        rob = {}
        for name, fn in STRESS.items():
            m = metrics(y, run(it, a.data, rows, fn, fi))
            rob[name] = m["auc"] if m else None
            print(f"  {name:14s} AUC={rob[name]:.3f}" if m else f"  {name}: thiếu lớp")
        report["robustness_auc"] = rob
        print("  AUC rơi mạnh ở 'thu_nho'/'tong_hop' nghĩa là mô hình chưa hợp với video call thật: tăng cường làm xấu khi train hoặc thêm dữ liệu quay màn hình.")

    meta["platt"] = [A, B2]
    meta["threshold"] = 0.5
    meta["targetFpr"] = a.target_fpr
    json.dump(meta, open(meta_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    json.dump(report, open(os.path.join(a.out, "report.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(f"\nĐã cập nhật {meta_path} và report.json.")
    print("Chép deepfake.tflite + deepfake_meta.json vào app/src/main/assets/ (hoặc models/ ngoài APK, xem README_FACE.md).")


if __name__ == "__main__":
    main()
