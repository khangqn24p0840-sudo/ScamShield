"""Evaluate the SMS rule + TFLite decision logic on a labelled CSV holdout set."""
import argparse
import csv
import re
import sys
from pathlib import Path
import numpy as np
from features import featurize, norm

HERE = Path(__file__).resolve().parent
KT = HERE.parent / "app" / "src" / "main" / "java" / "vn" / "scamshield" / "ScamDetector.kt"
MODEL = HERE.parent / "app" / "src" / "main" / "assets" / "scam_text.tflite"
SOLO = {"Đòi phí / thuế mới cho rút tiền (dấu hiệu sàn lừa)"}


def load_rules():
    src = KT.read_text(encoding="utf-8")
    pattern = r'Rule\(Regex\("""(.*?)"""\),\s*(\d+),\s*"(.*?)",\s*\'([A-Z])\'\)'
    rules = [(re.compile(m.group(1)), int(m.group(2)), m.group(3), m.group(4)) for m in re.finditer(pattern, src, re.S)]
    if not rules:
        sys.exit("Không đọc được Rule(Regex(...)) từ ScamDetector.kt")
    return rules

RULES = load_rules()


def predict_model(model_path):
    try:
        import tensorflow as tf
        interpreter = tf.lite.Interpreter(model_path=str(model_path))
        interpreter.allocate_tensors()
        inp = interpreter.get_input_details()[0]["index"]
        out = interpreter.get_output_details()[0]["index"]
        def predict(text):
            interpreter.set_tensor(inp, featurize(text).reshape(1, -1).astype(np.float32))
            interpreter.invoke()
            return float(interpreter.get_tensor(out)[0][0])
        return predict
    except Exception as e:
        print(f"Không nạp được model: {e}")
        return None


def decide(text, p=None):
    t = norm(text)
    warning_phrases = ("canh bao lua dao", "phong tranh lua dao", "ngan hang khong bao gio yeu cau",
                       "khong bao gio cung cap otp", "khong cung cap otp", "khong chia se otp",
                       "tuyet doi khong chia se ma xac thuc", "tuyet doi khong cung cap ma otp")
    if any(phrase in t for phrase in warning_phrases):
        return 0
    score, strong, n, stages, reasons = 0, 0, 0, set(), []
    solo = False
    for rx, pts, label, stage in RULES:
        if rx.search(t):
            score += pts; n += 1; reasons.append(label)
            if pts >= 25: strong += 1
            if stage != "N": stages.add(stage)
            if label in SOLO: solo = True
    if p is not None and p >= 0.85:
        score += int(max(0, min(20, ((p - 0.85) / 0.15) * 20)))
        n += 1; reasons.append("ML")
        if p >= 0.92: strong += 1
    corroborated = solo or (n >= 2 and strong >= 1 and (len(stages) >= 2 or (score >= 60 and strong >= 2)))
    solid = strong >= 2 or n >= 4
    score = min(100, score)
    level = 2 if corroborated and score >= 50 and solid else 1 if corroborated and score >= 25 else 0
    return level


def metrics(y, pred):
    y, pred = np.asarray(y), np.asarray(pred)
    tp = int(((pred == 1) & (y == 1)).sum()); fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum()); tn = int(((pred == 0) & (y == 0)).sum())
    pr = tp / (tp + fp) if tp + fp else 0.0; rc = tp / (tp + fn) if tp + fn else 0.0
    return {"TP": tp, "FP": fp, "FN": fn, "TN": tn, "Precision": pr, "Recall": rc,
            "F1": 2 * pr * rc / (pr + rc) if pr + rc else 0.0, "FPR": fp / (fp + tn) if fp + tn else 0.0}

ap = argparse.ArgumentParser()
ap.add_argument("--csv", required=True)
ap.add_argument("--model", default=str(MODEL))
a = ap.parse_args()
texts, labels = [], []
with open(a.csv, encoding="utf-8-sig", newline="") as f:
    for row in csv.DictReader(f):
        text, label = (row.get("content") or "").strip(), str(row.get("label", "")).strip()
        if text and label in {"0", "1"}:
            texts.append(text); labels.append(int(label))
if len(set(labels)) != 2:
    sys.exit("Tập kiểm tra cần có cả hai nhãn 0 và 1.")

pred_rules = [int(decide(t) > 0) for t in texts]
print(f"Tập kiểm tra: {len(texts)} tin; rule-only: {metrics(labels, pred_rules)}")
model_predict = predict_model(Path(a.model).resolve())
if model_predict:
    probs = [model_predict(t) for t in texts]
    pred_combined = [int(decide(t, p) > 0) for t, p in zip(texts, probs)]
    print(f"Rule + TFLite: {metrics(labels, pred_combined)}")
else:
    print("Bỏ qua kết quả kết hợp vì không nạp được TFLite.")
print("Lưu ý: phép đo này mô phỏng SMS đơn lẻ; không bao gồm ThreadGuard, danh sách cộng đồng, quyền Android và trạng thái thông báo.")
