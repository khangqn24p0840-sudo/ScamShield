"""
Đo Precision, Recall, F1, FPR trên tập kiểm tra (test.csv) cho: (1) bộ quy tắc, (2) bộ quy tắc + mô hình TFLite,
đúng cách app đang kết hợp. Bộ quy tắc được đọc thẳng từ ScamDetector.kt nên luôn khớp với app.
Chạy (trong thư mục ml, đã bật venv có tensorflow):   python evaluate.py --csv test.csv
Kết quả in thành bảng để chép vào báo cáo và lưu vào ket_qua_danh_gia.csv.
"""
import argparse
import csv
import re
import sys
import time
from pathlib import Path

import numpy as np

from features import featurize, norm

HERE = Path(__file__).resolve().parent
KT = HERE.parent / "app" / "src" / "main" / "java" / "vn" / "scamshield" / "ScamDetector.kt"
MODEL = HERE.parent / "app" / "src" / "main" / "assets" / "scam_text.tflite"


def load_rules():
    src = KT.read_text(encoding="utf-8")
    rules = []
    for m in re.finditer(r'Triple\("((?:[^"\\]|\\.)*)",\s*(\d+),', src):
        rules.append((re.compile(m.group(1).replace("\\\\", "\\")), int(m.group(2))))
    if not rules:
        sys.exit("Không đọc được bộ quy tắc từ ScamDetector.kt")
    return rules


RULES = load_rules()


def rule_score(text):
    t = norm(text)
    return min(100, sum(pts for rx, pts in RULES if rx.search(t)))


def load_model():
    try:
        import tensorflow as tf
        it = tf.lite.Interpreter(model_path=str(MODEL))
    except Exception as e:
        print(f"[!] Không nạp được mô hình TFLite ({e}). Chỉ đo bộ quy tắc.")
        return None
    it.allocate_tensors()
    inp, out = it.get_input_details()[0]["index"], it.get_output_details()[0]["index"]

    def predict(text):
        it.set_tensor(inp, featurize(text).reshape(1, -1).astype(np.float32))
        it.invoke()
        return float(it.get_tensor(out)[0][0])
    return predict


def combine(rule, p):
    """Giống ScamDetector.analyze: mô hình chỉ cộng điểm (tối đa 30) khi p >= 0.5."""
    return min(100, rule + int((p - 0.5) * 60)) if p >= 0.5 else rule


def metrics(y, pred):
    y, pred = np.array(y), np.array(pred)
    tp, fp = int(((pred == 1) & (y == 1)).sum()), int(((pred == 1) & (y == 0)).sum())
    fn, tn = int(((pred == 0) & (y == 1)).sum()), int(((pred == 0) & (y == 0)).sum())
    pr = tp / (tp + fp) if tp + fp else 0.0
    rc = tp / (tp + fn) if tp + fn else 0.0
    return dict(TP=tp, FP=fp, FN=fn, TN=tn, Precision=pr, Recall=rc, F1=2 * pr * rc / (pr + rc) if pr + rc else 0.0,
                FPR=fp / (fp + tn) if fp + tn else 0.0)


ap = argparse.ArgumentParser()
ap.add_argument("--csv", required=True)
ap.add_argument("--threshold", type=int, default=30, help="điểm từ mức này trở lên coi là cảnh báo (app: 30 = vàng, 60 = đỏ)")
a = ap.parse_args()

texts, labels = [], []
with open(a.csv, encoding="utf-8-sig", newline="") as f:
    for r in csv.DictReader(f):
        t, l = (r.get("content") or "").strip(), str(r.get("label", "")).strip()
        if t and l in ("0", "1"):
            texts.append(t)
            labels.append(int(l))
if len(set(labels)) < 2:
    sys.exit("Tập kiểm tra cần có cả hai nhãn.")

t0 = time.perf_counter()
rs = [rule_score(t) for t in texts]
ms_rules = (time.perf_counter() - t0) * 1000 / len(texts)

predict = load_model()
results = {"Bộ quy tắc": metrics(labels, [int(s >= a.threshold) for s in rs])}
ms_ml = None
if predict:
    t0 = time.perf_counter()
    ps = [predict(t) for t in texts]
    ms_ml = (time.perf_counter() - t0) * 1000 / len(texts)
    results["+ Mô hình TFLite"] = metrics(labels, [int(combine(s, p) >= a.threshold) for s, p in zip(rs, ps)])

print(f"\nTập kiểm tra: {len(texts)} dòng (lừa đảo {sum(labels)}, bình thường {len(labels) - sum(labels)}), ngưỡng cảnh báo = {a.threshold} điểm\n")
names = list(results)
print("| Thước đo | " + " | ".join(names) + " |")
print("|---|" + "---|" * len(names))
for k in ("Precision", "Recall", "F1", "FPR"):
    print(f"| {k} | " + " | ".join(f"{results[n][k]:.3f}" for n in names) + " |")
for k in ("TP", "FP", "FN", "TN"):
    print(f"| ({k}) | " + " | ".join(str(results[n][k]) for n in names) + " |")
print(f"\nThời gian TRUNG BÌNH trên máy tính này (chỉ để tham khảo, KHÔNG phải số đo trên điện thoại): "
      f"quy tắc {ms_rules:.3f} ms/tin" + (f", mô hình TFLite {ms_ml:.3f} ms/tin" if ms_ml is not None else ""))

with open(HERE / "ket_qua_danh_gia.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["cau_hinh", "TP", "FP", "FN", "TN", "Precision", "Recall", "F1", "FPR"])
    for n in names:
        m = results[n]
        w.writerow([n, m["TP"], m["FP"], m["FN"], m["TN"], round(m["Precision"], 3), round(m["Recall"], 3), round(m["F1"], 3), round(m["FPR"], 3)])
print("Đã lưu ket_qua_danh_gia.csv")
