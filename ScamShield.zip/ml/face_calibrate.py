"""
Hiệu chỉnh trọng số/ngưỡng cho phần kiểm tra khuôn mặt video call từ DỮ LIỆU THẬT do app ghi lại.

Cách thu dữ liệu (mỗi phiên = một cuộc gọi hoặc một video):
  1. Trong app: Kiểm tra Deepfake -> bật "Ghi số liệu để hiệu chỉnh" -> Bắt đầu kiểm tra.
  2. Gọi video / phát video MỘT loại duy nhất trong mỗi phiên, rồi dừng.
       - phiên THẬT : gọi video với người thật (nhiều điều kiện: ánh sáng yếu, mạng chậm, đeo kính, khẩu trang, Zalo/Messenger/Meet...)
       - phiên GIẢ  : video đổi mặt/deepfake mà BẠN TỰ TẠO hoặc có giấy phép (không dùng ảnh/video của người khác khi chưa được đồng ý)
  3. Lấy file face_log_*.csv từ điện thoại: Android/data/vn.scamshield/files/
  4. Chạy:
        python face_calibrate.py --real thật1.csv thật2.csv ... --fake giả1.csv giả2.csv ... --out face_calib.json
  5. Chép face_calib.json vào app/src/main/assets/ rồi build lại. Không có file thì app dùng giá trị mặc định.

Cần:  pip install numpy scikit-learn
Lưu ý: cần ít nhất ~5 phiên mỗi loại, càng đa dạng càng tốt. Các dòng trong cùng một phiên giống nhau rất nhiều, nên script
đánh giá theo từng PHIÊN (bỏ ra một phiên làm kiểm tra), không trộn các dòng của cùng một phiên vào cả học lẫn kiểm tra.
"""
import argparse
import csv
import json
import sys

import numpy as np
from sklearn.linear_model import LogisticRegression

FEATS = ["blink", "jitter", "blend", "box", "model", "profile"]
DEFAULT_W = {"blink": 2.0, "jitter": 0.8, "blend": 1.0, "box": 0.8, "model": 3.5, "profile": 1.2}
DEFAULT_B = -2.2
MIN_ROWS = 10
MAX_W, MAX_B = 12.0, 15.0     # phải khớp FaceCalibration.kt; vượt mức này thường nghĩa là dữ liệu quá ít/quá sạch


def load_session(path):
    rows = []
    with open(path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            if "blink" not in r:
                sys.exit(f"{path}: không phải file log của app (thiếu cột blink)")
            # log cũ (trước khi có chỉ báo 'profile') không có cột đó: coi như không đo được
            rows.append([float(r[k]) if (r.get(k) or "").strip() != "" else np.nan for k in FEATS])
    return np.array(rows, dtype=float).reshape(-1, len(FEATS))


def fit(X, y, cols):
    """Hồi quy logistic có hệ số không âm (chỉ báo càng cao càng đáng ngờ): hệ số âm thì bỏ chỉ báo đó rồi học lại."""
    cols = list(cols)
    while cols:
        m = LogisticRegression(C=0.3, class_weight="balanced", max_iter=2000)
        m.fit(X[:, cols], y)
        neg = [c for c, w in zip(cols, m.coef_[0]) if w < 0]
        if not neg:
            return cols, m.coef_[0], float(m.intercept_[0])
        cols = [c for c in cols if c not in neg]
    return [], np.array([]), DEFAULT_B


def predict(X, cols, w, b):
    z = b + (X[:, cols] @ w if cols else 0.0)
    return 1.0 / (1.0 + np.exp(-z))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--real", nargs="+", required=True)
    ap.add_argument("--fake", nargs="+", required=True)
    ap.add_argument("--out", default="face_calib.json")
    a = ap.parse_args()

    Xs, ys, gs, names = [], [], [], []
    for lab, files in ((0, a.real), (1, a.fake)):
        for p in files:
            x = load_session(p)
            if len(x) < MIN_ROWS:
                print(f"BỎ QUA {p}: chỉ {len(x)} dòng (cần >= {MIN_ROWS})")
                continue
            Xs.append(x); ys += [lab] * len(x); gs += [len(names)] * len(x); names.append((p, lab))
    if not Xs:
        sys.exit("Không có phiên hợp lệ.")
    X = np.nan_to_num(np.vstack(Xs), nan=0.0)         # chỉ báo thiếu = 0 điểm, giống cách app tính
    present = ~np.isnan(np.vstack(Xs))
    y, g = np.array(ys), np.array(gs)
    n_real = sum(1 for _, l in names if l == 0)
    n_fake = len(names) - n_real
    print(f"{len(names)} phiên: {n_real} thật, {n_fake} giả; {len(y)} dòng")
    if n_real < 2 or n_fake < 2:
        sys.exit("Cần ít nhất 2 phiên mỗi loại để đánh giá (khuyến nghị 5+).")
    if n_real < 5 or n_fake < 5:
        print("CẢNH BÁO: dưới 5 phiên mỗi loại, kết quả chỉ mang tính tham khảo.")

    usable = [i for i, f in enumerate(FEATS) if present[:, i].mean() > 0.5]
    skipped = [FEATS[i] for i in range(len(FEATS)) if i not in usable]
    if skipped:
        print("Chỉ báo không có dữ liệu (giữ trọng số mặc định):", ", ".join(skipped))

    # đánh giá bỏ-một-phiên (leave-one-session-out)
    cv = np.zeros(len(y))
    for s in range(len(names)):
        te = g == s
        cols, w, b = fit(X[~te], y[~te], usable)
        cv[te] = predict(X[te], cols, w, b)

    pr, pf = cv[y == 0], cv[y == 1]
    sus = float(np.clip(np.quantile(pr, 0.90), 0.20, 0.90))     # ~10% dòng của phiên thật bị "đáng ngờ"
    high = float(np.clip(np.quantile(pr, 0.98), sus + 0.05, 0.95))  # ~2% dòng của phiên thật bị "cao"
    print(f"\nTrên dữ liệu bỏ-một-phiên: ngưỡng đáng ngờ {sus:.2f}, ngưỡng cao {high:.2f}")
    print(f"  Phiên GIẢ: {np.mean(pf >= sus) * 100:.0f}% dòng >= đáng ngờ, {np.mean(pf >= high) * 100:.0f}% dòng >= cao")
    print(f"  Phiên THẬT: {np.mean(pr >= sus) * 100:.0f}% dòng >= đáng ngờ, {np.mean(pr >= high) * 100:.0f}% dòng >= cao")
    print("  Theo từng phiên (tỉ lệ dòng >= đáng ngờ):")
    for s, (p, lab) in enumerate(names):
        print(f"    {'GIẢ ' if lab else 'THẬT'}  {np.mean(cv[g == s] >= sus) * 100:5.0f}%  {p}")
    print("  (Điều kiện chạy thực tế còn chặt hơn: mức CAO cần >= 2 chỉ báo cùng bất thường và kéo dài.)")

    cols, w, b = fit(X, y, usable)
    weights = dict(DEFAULT_W)
    for c, wi in zip(cols, w):
        weights[FEATS[c]] = round(float(wi), 3)
    dropped = [FEATS[c] for c in usable if c not in cols]
    if dropped:
        print("Chỉ báo bị loại vì không giúp phân biệt (trọng số 0):", ", ".join(dropped))
        for d in dropped:
            weights[d] = 0.0
    if max(weights.values()) > MAX_W or abs(b) > MAX_B:
        print(f"CẢNH BÁO: hệ số vượt {MAX_W}/{MAX_B} (sẽ bị app cắt bớt). Thường do quá ít phiên hoặc dữ liệu quá dễ tách; hãy thu thêm phiên đa dạng.")
        weights = {k: min(v, MAX_W) for k, v in weights.items()}
        b = float(np.clip(b, -MAX_B, MAX_B))
    out = {"weights": weights, "bias": round(b, 3), "suspiciousAt": round(sus, 3), "highAt": round(high, 3),
           "info": {"sessions_real": n_real, "sessions_fake": n_fake, "rows": int(len(y))}}
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\nĐã ghi {a.out}:\n{json.dumps(out, ensure_ascii=False, indent=2)}")


if __name__ == "__main__":
    main()
