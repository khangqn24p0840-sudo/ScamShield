# Mô hình học máy SMS ScamShield

Ứng dụng dùng mô hình TFLite `scam_text.tflite` với vector đặc trưng hashed n-gram 4096 chiều. Cách trích xuất đặc trưng trong `features.py` phải khớp `TextModel.kt`.

## Dữ liệu

Không dùng dữ liệu tổng hợp để tuyên bố độ chính xác thực tế. Hãy đọc `huong_dan_du_lieu_sms.md` và bắt đầu từ `du_lieu_sms_mau.csv`.

CSV tối thiểu có `content,label`; khuyến nghị thêm `group_id` để các tin cùng chiến dịch/mẫu câu luôn nằm trong cùng một split. Script loại trùng nội dung tuyệt đối và báo lỗi nếu cùng nội dung bị gắn hai nhãn khác nhau. Chỉ dùng dữ liệu đã được xác minh, đã ẩn thông tin cá nhân và có sự đồng ý phù hợp.

Lưu ý: `train.csv`, `test.csv` và `du_lieu_mau.csv` có cột `nguon=ai_viet`/dữ liệu tạo mẫu; chúng chỉ phù hợp kiểm tra quy trình, không đại diện SMS thực tế.

## Huấn luyện model mới

```bash
pip install -r requirements.txt
python train_tflite.py --csv du_lieu_sms.csv --epochs 35
```

Kết quả mặc định:
- `ml/exports/scam_text.tflite`
- `ml/exports/scam_text.metrics.json`

Script tách train/validation/test theo nhóm, dùng validation để theo dõi overfit và chỉ báo cáo kết quả trên test giữ riêng. Chỉ số được tính ở ngưỡng xác suất 0.85, tương ứng với ngưỡng ML hỗ trợ hiện tại trong ứng dụng.

Đánh giá logic bộ quy tắc + model trên tập test độc lập:

```bash
python evaluate.py --csv tap_test_chua_tung_hoc.csv
```

Lưu ý: evaluator mô phỏng phân tích SMS đơn lẻ; không bao gồm ThreadGuard, dữ liệu cộng đồng, quyền Android và trạng thái notification.

## Cập nhật model không cần build APK

Chép `scam_text.tflite` vào:

`Android/data/vn.scamshield/files/models/scam_text.tflite`

Hoặc trong ứng dụng vào **Cài đặt → Mô hình học máy → Cập nhật mô hình AI**. App ưu tiên model ngoài APK và tự nạp lại khi file thay đổi; nếu file ngoài lỗi, app quay về model trong assets.

Luôn sao lưu model cũ và kiểm tra false positive/false negative trước khi triển khai rộng.
