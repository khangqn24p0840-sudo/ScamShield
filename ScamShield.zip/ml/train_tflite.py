"""Train the ScamShield SMS model from a reviewed CSV dataset.

CSV columns: content,label[,group_id]
label: 1=scam, 0=benign. group_id keeps messages from the same campaign/template
in one split to reduce train/validation/test leakage.
"""
import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import tensorflow as tf
from sklearn.model_selection import GroupShuffleSplit

from features import DIM, featurize_many, norm

HERE = Path(__file__).resolve().parent
DEFAULT_OUT = HERE / "exports" / "scam_text.tflite"
APP_ASSET = HERE.parent / "app" / "src" / "main" / "assets" / "scam_text.tflite"


def read_dataset(path):
    texts, labels, groups = [], [], []
    seen = {}
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        required = {"content", "label"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("CSV phải có ít nhất hai cột content,label")
        for row_no, row in enumerate(reader, start=2):
            text = (row.get("content") or "").strip()
            label = str(row.get("label", "")).strip()
            if not text:
                continue
            if label not in {"0", "1"}:
                raise ValueError(f"Dòng {row_no}: label phải là 0 hoặc 1")
            normalized = norm(text)
            if normalized in seen:
                if seen[normalized] != int(label):
                    raise ValueError(f"Dòng {row_no}: cùng một nội dung bị gắn hai nhãn khác nhau; cần kiểm tra lại.")
                continue  # bỏ bản sao y hệt, tránh làm phình dataset
            seen[normalized] = int(label)
            texts.append(text)
            labels.append(int(label))
            # Khuyến nghị group_id = cùng chiến dịch, cùng mẫu câu hoặc cùng đợt gửi.
            group = (row.get("group_id") or "").strip()
            groups.append(group if group else "text:" + normalized)
    if len(texts) < 100:
        raise ValueError(f"Chỉ có {len(texts)} mẫu. Nên có ít nhất 100 mẫu đã kiểm duyệt trước khi huấn luyện.")
    if len(set(labels)) != 2:
        raise ValueError("Dataset phải có cả tin lừa đảo (1) và tin bình thường (0).")
    counts = np.bincount(labels, minlength=2)
    if min(counts) < 30:
        raise ValueError(f"Mỗi nhãn cần ít nhất 30 mẫu; hiện bình thường={counts[0]}, lừa đảo={counts[1]}.")
    return texts, np.asarray(labels, dtype=np.float32), np.asarray(groups)


def split_groups(y, groups):
    """Tách 70/15/15 theo group; thử nhiều seed để mỗi phần có đủ hai nhãn."""
    indices = np.arange(len(y))
    for seed in range(100):
        outer = GroupShuffleSplit(n_splits=1, test_size=0.30, random_state=seed)
        train_idx, hold_idx = next(outer.split(indices, y, groups))
        inner = GroupShuffleSplit(n_splits=1, test_size=0.50, random_state=seed + 1000)
        val_rel, test_rel = next(inner.split(hold_idx, y[hold_idx], groups[hold_idx]))
        val_idx, test_idx = hold_idx[val_rel], hold_idx[test_rel]
        if all(len(np.unique(y[idx])) == 2 for idx in (train_idx, val_idx, test_idx)):
            return train_idx, val_idx, test_idx
    raise ValueError("Không thể chia dữ liệu theo group có đủ hai nhãn. Hãy bổ sung group_id/campaign đa dạng hơn.")


def metric_row(y, pred):
    tp = int(((pred == 1) & (y == 1)).sum())
    fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum())
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    return {
        "n": int(len(y)), "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "precision": round(precision, 4), "recall": round(recall, 4),
        "f1": round(2 * precision * recall / (precision + recall), 4) if precision + recall else 0.0,
        "fpr": round(fp / (fp + tn), 4) if fp + tn else 0.0,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="CSV đã kiểm duyệt, cột content,label và khuyến nghị group_id")
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    ap.add_argument("--epochs", type=int, default=35)
    ap.add_argument("--batch-size", type=int, default=32)
    args = ap.parse_args()

    texts, y, groups = read_dataset(args.csv)
    tr, va, te = split_groups(y, groups)
    X = featurize_many(texts)

    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(DIM,)),
        tf.keras.layers.Dense(1, activation="sigmoid", kernel_regularizer=tf.keras.regularizers.l2(1e-4)),
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.01), loss="binary_crossentropy")
    # Validation dùng để phát hiện overfit; test giữ kín tới bước đánh giá cuối.
    class_weight = {0: len(tr) / (2 * max(1, int((y[tr] == 0).sum()))),
                    1: len(tr) / (2 * max(1, int((y[tr] == 1).sum())))}
    model.fit(X[tr], y[tr], epochs=args.epochs, batch_size=args.batch_size,
              class_weight=class_weight, verbose=0, validation_data=(X[va], y[va]),
              callbacks=[tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=5,
                                                           restore_best_weights=True)])
    val_p = model.predict(X[va], verbose=0).reshape(-1)
    # Ngưỡng vận hành của app hiện là 0.85; đánh giá đúng ngưỡng này để tránh số liệu đẹp nhưng không khớp ứng dụng.
    val_metrics = metric_row(y[va].astype(int), (val_p >= 0.85).astype(int))
    test_p = model.predict(X[te], verbose=0).reshape(-1)
    test_metrics = metric_row(y[te].astype(int), (test_p >= 0.85).astype(int))

    # Bản phát hành cuối học trên train + validation. Test vẫn không tham gia huấn luyện.
    final = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(DIM,)),
        tf.keras.layers.Dense(1, activation="sigmoid", kernel_regularizer=tf.keras.regularizers.l2(1e-4)),
    ])
    final.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.01), loss="binary_crossentropy")
    final_idx = np.concatenate([tr, va])
    final_class_weight = {0: len(final_idx) / (2 * max(1, int((y[final_idx] == 0).sum()))),
                          1: len(final_idx) / (2 * max(1, int((y[final_idx] == 1).sum())))}
    final.fit(X[final_idx], y[final_idx], class_weight=final_class_weight,
              epochs=max(5, min(args.epochs, 35)), batch_size=args.batch_size, verbose=0)

    blob = tf.lite.TFLiteConverter.from_keras_model(final).convert()
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(blob)
    report = {
        "source": str(Path(args.csv).resolve()),
        "samples": len(texts),
        "class_counts": {"benign_0": int((y == 0).sum()), "scam_1": int((y == 1).sum())},
        "split_sizes": {"train": len(tr), "validation": len(va), "test": len(te)},
        "threshold": 0.85,
        "validation": val_metrics,
        "test": test_metrics,
        "warning": "Kết quả phụ thuộc chất lượng và tính đại diện của dữ liệu; test không phải cam kết hiệu quả ngoài đời.",
    }
    report_path = out.with_suffix(".metrics.json")
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"\nĐã xuất model: {out} ({len(blob):,} bytes)")
    print(f"Báo cáo: {report_path}")
    print("Chỉ triển khai nếu test có precision/recall phù hợp và đã kiểm tra thủ công các false positive/false negative.")


if __name__ == "__main__":
    main()
