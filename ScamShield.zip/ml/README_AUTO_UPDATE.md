# Tự động cập nhật model ML

Sau khi build APK có phiên bản này **một lần**, điện thoại sẽ tự kiểm tra model khi mở app và khi quay lại app.

## Trên máy tính

Trước khi publish, huấn luyện từ CSV đã kiểm duyệt theo hướng dẫn `huong_dan_du_lieu_sms.md`. Không dùng tập dữ liệu mẫu AI để đánh giá chất lượng triển khai.

```bash
cd ml
python train_tflite.py --csv du_lieu_moi.csv --epochs 40
python publish_model.py --version 2
python model_server.py
```

Server mặc định chạy cổng 8080 và cung cấp:

- `/api/model/manifest`
- `/api/model/scam_text.tflite`

Để điện thoại truy cập từ Internet, hãy đặt server sau một HTTPS reverse proxy/tunnel. Sau đó đổi `Config.SERVER_URL` trong app thành địa chỉ HTTPS đó **và build APK một lần**.

Mỗi lần model mới được train:

```bash
python train_tflite.py --csv du_lieu_moi.csv --epochs 40
python publish_model.py --version 3
```

Không cần build lại app. Điện thoại sẽ thấy version 3 khác version đang lưu và tự tải model mới.

## An toàn

App tải model vào file tạm, kiểm tra bằng TensorFlow Lite trước, rồi mới thay model đang dùng. Nếu tải lỗi, model cũ vẫn được giữ.
