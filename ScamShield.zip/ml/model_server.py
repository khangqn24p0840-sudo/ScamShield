"""Máy chủ model đơn giản cho ScamShield.

Cách dùng:
  1) python train_tflite.py --csv du_lieu.csv --epochs 40 --out exports/scam_text.tflite
  2) Đặt biến MODEL_VERSION, rồi chạy: python model_server.py
  3) App sẽ gọi GET /api/model/manifest và /api/model/scam_text.tflite.

Có thể dùng ngrok/reverse proxy để điện thoại ngoài mạng LAN truy cập HTTPS.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, os

ROOT = Path(__file__).resolve().parent
MODEL = Path(os.environ.get("SCAM_MODEL", ROOT / "exports" / "scam_text.tflite")).resolve()
VERSION_FILE = Path(os.environ.get("SCAM_MODEL_VERSION_FILE", ROOT / "exports" / "scam_text.version"))
HOST = os.environ.get("SCAM_MODEL_HOST", "0.0.0.0")
PORT = int(os.environ.get("SCAM_MODEL_PORT", "8080"))

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[{self.address_string()}] {fmt % args}")

    def do_GET(self):
        if self.path == "/api/model/manifest":
            version = VERSION_FILE.read_text(encoding="utf-8").strip() if VERSION_FILE.exists() else "1"
            body = json.dumps({"version": version}, ensure_ascii=False).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
        if self.path == "/api/model/scam_text.tflite":
            if not MODEL.is_file(): self.send_error(404, "model not found"); return
            data = MODEL.read_bytes()
            self.send_response(200); self.send_header("Content-Type", "application/octet-stream"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
        self.send_error(404)

if __name__ == "__main__":
    print(f"Model: {MODEL}")
    print(f"Version: {VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else '1'}")
    print(f"Listening on http://{HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
