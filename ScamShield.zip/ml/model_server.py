"""Máy chủ model đơn giản cho ScamShield.

Cách dùng:
  1) python train_tflite.py --csv du_lieu.csv --epochs 40 --out exports/scam_text.tflite
  2) Đặt biến MODEL_VERSION, rồi chạy: python model_server.py
  3) App sẽ gọi GET /api/model/manifest và /api/model/scam_text.tflite.

Có thể dùng ngrok/reverse proxy để điện thoại ngoài mạng LAN truy cập HTTPS.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, os, sqlite3
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent
MODEL = Path(os.environ.get("SCAM_MODEL", ROOT / "exports" / "scam_text.tflite")).resolve()
VERSION_FILE = Path(os.environ.get("SCAM_MODEL_VERSION_FILE", ROOT / "exports" / "scam_text.version"))
HOST = os.environ.get("SCAM_MODEL_HOST", "0.0.0.0")
PORT = int(os.environ.get("SCAM_MODEL_PORT", "8080"))
ACCOUNT_DB = Path(os.environ.get("SCAM_ACCOUNT_DB", ROOT / "exports" / "accounts.sqlite3")).resolve()

def db_init():
    ACCOUNT_DB.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(ACCOUNT_DB) as db:
        db.execute("""CREATE TABLE IF NOT EXISTS accounts (
            number TEXT NOT NULL, bank TEXT NOT NULL DEFAULT '', reports INTEGER NOT NULL DEFAULT 0,
            verified INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(number, bank))""")
        db.commit()

def account_check(number, bank):
    with sqlite3.connect(ACCOUNT_DB) as db:
        row = db.execute("SELECT reports, verified FROM accounts WHERE number=? AND (bank=? OR bank='') ORDER BY verified DESC, reports DESC LIMIT 1", (number, bank)).fetchone()
    if not row:
        return {"verified": False, "reports": 0}
    return {"verified": bool(row[1]), "reports": int(row[0])}

def account_report(number, bank):
    with sqlite3.connect(ACCOUNT_DB) as db:
        row = db.execute("SELECT reports FROM accounts WHERE number=? AND bank=?", (number, bank)).fetchone()
        if row:
            reports = int(row[0]) + 1
            db.execute("UPDATE accounts SET reports=?, verified=? WHERE number=? AND bank=?", (reports, 1 if reports >= 3 else 0, number, bank))
        else:
            reports = 1
            db.execute("INSERT INTO accounts(number, bank, reports, verified) VALUES(?,?,?,0)", (number, bank, reports))
        db.commit()
    return {"verified": reports >= 3, "reports": reports}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[{self.address_string()}] {fmt % args}")

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/accounts/check":
            q = parse_qs(parsed.query)
            number = "".join(ch for ch in q.get("number", [""])[0] if ch.isdigit())
            bank = q.get("bank", [""])[0].strip()
            if not (6 <= len(number) <= 19):
                self.send_error(400, "invalid account number"); return
            body = json.dumps(account_check(number, bank), ensure_ascii=False).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
        if parsed.path == "/api/accounts":
            with sqlite3.connect(ACCOUNT_DB) as db:
                rows = db.execute("SELECT number, bank FROM accounts WHERE verified=1 ORDER BY reports DESC").fetchall()
            body = json.dumps({"accounts": [{"n": n, "b": b} for n,b in rows]}, ensure_ascii=False).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
        if parsed.path == "/api/model/manifest":
            version = VERSION_FILE.read_text(encoding="utf-8").strip() if VERSION_FILE.exists() else "1"
            body = json.dumps({"version": version}, ensure_ascii=False).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
        if self.path == "/api/model/scam_text.tflite":
            if not MODEL.is_file(): self.send_error(404, "model not found"); return
            data = MODEL.read_bytes()
            self.send_response(200); self.send_header("Content-Type", "application/octet-stream"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
        self.send_error(404)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/accounts/report":
            try:
                n = int(self.headers.get("Content-Length", "0"))
                obj = json.loads(self.rfile.read(n) or b"{}")
                number = "".join(ch for ch in str(obj.get("number", "")) if ch.isdigit())
                bank = str(obj.get("bank", "")).strip()
                if not (6 <= len(number) <= 19):
                    self.send_error(400, "invalid account number"); return
                body = json.dumps(account_report(number, bank), ensure_ascii=False).encode()
                self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
            except Exception as e:
                self.send_error(400, str(e)); return
        self.send_error(404)

if __name__ == "__main__":
    db_init()
    print(f"Model: {MODEL}")
    print(f"Version: {VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else '1'}")
    print(f"Listening on http://{HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
