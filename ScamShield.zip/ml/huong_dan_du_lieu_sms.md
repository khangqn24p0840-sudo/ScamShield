# Hướng dẫn bổ sung dữ liệu SMS cho ScamShield

## 1. Định dạng CSV

Dùng UTF-8 hoặc UTF-8-SIG, có các cột:

```csv
content,label,group_id,source
"Nội dung tin nhắn đã ẩn thông tin cá nhân",0,"otp-ngan-hang-01","sms_da_xac_minh"
"Nội dung tin nhắn lừa đảo đã xác minh",1,"gia-mao-ngan-hang-02","sms_da_xac_minh"
```

- `content`: nội dung tin nhắn. Giữ nguyên cách viết, dấu câu và URL giả lập nếu cần phân tích; không đưa dữ liệu nhạy cảm thật.
- `label`: `0` = bình thường; `1` = lừa đảo đã được xác minh.
- `group_id`: rất nên có. Gán cùng ID cho các tin cùng chiến dịch, cùng mẫu câu hoặc cùng đợt phát tán. Bộ chia dữ liệu sẽ giữ cả nhóm trong cùng một phần để tránh rò rỉ dữ liệu giữa train/validation/test.
- `source`: nguồn xác minh, ví dụ `sms_da_xac_minh`, `ngan_hang_xac_nhan`, `nguoi_dung_bao_cao_da_kiem_tra`. Không bắt buộc.

File mẫu trống: `du_lieu_sms_mau.csv`.

## 2. Quy tắc gắn nhãn

### Nhãn 1 – lừa đảo

Chỉ gắn nhãn 1 khi có căn cứ xác minh hoặc nội dung thể hiện rõ thủ đoạn, ví dụ:
- Giả danh cơ quan/ngân hàng để yêu cầu chuyển tiền vào “tài khoản an toàn”.
- Yêu cầu đọc/gửi OTP, mật khẩu, CVV hoặc thông tin thẻ cho người khác.
- Link giả mạo yêu cầu đăng nhập, cài APK hoặc chia sẻ màn hình.
- Bắt nạp tiền/đặt cọc/đóng phí để nhận việc, rút tiền hoặc nhận thưởng.
- Mạo danh người thân, sếp để vay/chuyển tiền gấp.

### Nhãn 0 – bình thường

Cần đưa vào nhiều ví dụ dễ gây nhầm:
- OTP thật có câu “không chia sẻ mã cho bất kỳ ai”.
- SMS ngân hàng thông báo số dư/giao dịch/bảo trì.
- Tin giao hàng, hoàn tiền, học phí, viện phí, hóa đơn hợp pháp.
- Quảng cáo khuyến mãi, du lịch, tuyển dụng hợp pháp.
- Tin nhắn cá nhân có các từ như “chuyển khoản”, “ngân hàng”, “mã xác thực”, “giao hàng”.

Nếu không chắc, không gắn nhãn đoán mò; để vào danh sách cần xác minh.

## 3. Bảo vệ riêng tư

- Xóa/che số điện thoại, họ tên, địa chỉ, số tài khoản, mã OTP, mã đơn hàng và dữ liệu cá nhân.
- Không thu thập SMS của người khác khi chưa được đồng ý.
- Không tải nội dung SMS lên dịch vụ bên ngoài nếu chưa có sự đồng ý rõ ràng.
- Không dùng dữ liệu người dùng báo cáo làm nhãn đúng ngay lập tức; cần kiểm duyệt trước khi huấn luyện.
- Không đưa nguyên văn OTP hoặc mật khẩu vào dataset. Thay bằng `[OTP]`, `[MAT_KHAU]`.

## 4. Số lượng và cân bằng dữ liệu

- Bắt đầu từ ít nhất 100 mẫu đã kiểm duyệt, tối thiểu 30 mẫu mỗi nhãn; đây chỉ là mức tối thiểu kỹ thuật, chưa đủ để khẳng định độ chính xác.
- Mục tiêu thực tế nên có hàng trăm đến hàng nghìn tin mỗi nhãn, từ nhiều chiến dịch và nhiều tình huống khác nhau.
- Bổ sung tin bình thường “dễ nhầm” thường xuyên để giảm false positive.
- Không nhân bản cùng một tin nhiều lần để làm dataset trông lớn hơn.
- Dành riêng các chiến dịch/nhóm mẫu chưa từng xuất hiện trong train làm test.

## 5. Huấn luyện

Trong thư mục `ml`:

```bash
pip install -r requirements.txt
python train_tflite.py --csv du_lieu_sms.csv --epochs 35
```

Script tự chia train/validation/test theo `group_id`, dừng sớm khi validation không cải thiện, rồi xuất:

- `exports/scam_text.tflite`
- `exports/scam_text.metrics.json`

Đánh giá thêm trên tập test độc lập:

```bash
python evaluate.py --csv tap_test_chua_tung_hoc.csv
```

Model được xuất theo cùng vector đặc trưng 4096 chiều với `TextModel.kt`. App hiện chỉ dùng xác suất ML cao (>= 0.85) như tín hiệu hỗ trợ; ML không tự kích hoạt cảnh báo khi không có bằng chứng độc lập từ bộ quy tắc.

## 6. Triển khai

Sao lưu model hiện tại trước. Chép model mới vào:

`Android/data/vn.scamshield/files/models/scam_text.tflite`

Hoặc dùng mục Cài đặt → Mô hình học máy → Cập nhật mô hình AI trong app. Không cần build APK lại khi chỉ thay model.

Sau khi thay model, chạy thử một bộ tin nhắn bình thường và lừa đảo đã gắn nhãn. Nếu false positive tăng mạnh hoặc recall giảm, quay lại model cũ.

## 7. Chỉ số cần theo dõi

- Precision: trong các cảnh báo, bao nhiêu phần trăm thực sự là lừa đảo.
- Recall: trong toàn bộ tin lừa đảo, app phát hiện được bao nhiêu phần trăm.
- F1: cân bằng precision và recall.
- FPR: tỷ lệ tin bình thường bị cảnh báo nhầm.

Không chọn model chỉ vì accuracy cao. Với app SMS, cần theo dõi cả precision, recall và FPR trên tập dữ liệu độc lập, đại diện cho người dùng thực tế.
