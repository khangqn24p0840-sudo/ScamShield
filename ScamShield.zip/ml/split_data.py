"""
Chia dữ liệu thành tập HỌC (train.csv) và tập KIỂM TRA (test.csv), giữ nguyên mọi cột (content,label,nguon...).
Tập kiểm tra là phần mô hình KHÔNG được nhìn thấy khi học, nhờ đó các chỉ số đo được mới đáng tin.
Chạy:  python split_data.py du_lieu.csv            (mặc định 20% làm tập kiểm tra, cố định hạt giống để chia lại ra y hệt)
"""
import argparse
import csv
import random
import sys
from pathlib import Path

from features import norm

ap = argparse.ArgumentParser()
ap.add_argument("csv")
ap.add_argument("--test", type=float, default=0.2, help="tỉ lệ tập kiểm tra (mặc định 0.2)")
ap.add_argument("--seed", type=int, default=42)
a = ap.parse_args()

with open(a.csv, encoding="utf-8-sig", newline="") as f:
    rd = csv.DictReader(f)
    fields = rd.fieldnames
    rows = [r for r in rd if (r.get("content") or "").strip() and str(r.get("label", "")).strip() in ("0", "1")]
if not fields or "content" not in fields or "label" not in fields:
    sys.exit("File phải có hàng đầu là: content,label (có thể thêm cột nguon)")

seen, uniq, dup = set(), [], 0
for r in rows:                      # bỏ tin trùng nhau (trùng sau khi bỏ dấu, viết thường) để tập kiểm tra không lặp lại tập học
    k = " ".join(norm(r["content"]).split())
    if k in seen:
        dup += 1
        continue
    seen.add(k)
    uniq.append(r)

rnd = random.Random(a.seed)
train, test = [], []
for lab in ("0", "1"):
    grp = [r for r in uniq if str(r["label"]).strip() == lab]
    rnd.shuffle(grp)
    n_test = max(1, round(len(grp) * a.test))
    test += grp[:n_test]
    train += grp[n_test:]
rnd.shuffle(train)
rnd.shuffle(test)

out = Path(a.csv).resolve().parent
for name, data in (("train.csv", train), ("test.csv", test)):
    with open(out / name, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(data)

cnt = lambda d, l: sum(1 for r in d if str(r["label"]).strip() == l)
print(f"Đọc {len(rows)} dòng, bỏ {dup} dòng trùng.")
print(f"train.csv: {len(train)} dòng (lừa đảo {cnt(train,'1')}, bình thường {cnt(train,'0')})")
print(f"test.csv : {len(test)} dòng (lừa đảo {cnt(test,'1')}, bình thường {cnt(test,'0')})")
if len(test) < 40:
    print("LƯU Ý: tập kiểm tra dưới 40 dòng nên các chỉ số dao động rất mạnh, chỉ mang tính tham khảo.")
