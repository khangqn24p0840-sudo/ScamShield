package vn.scamshield.finance

import java.util.Calendar
import org.junit.Assert.*
import org.junit.Test

class FinanceRiskTest {

    private fun ts(day: Int, hour: Int, minute: Int): Long {
        val c = Calendar.getInstance()
        c.set(2026, Calendar.OCTOBER, day, hour, minute, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun tx(id: String, t: Long, amount: Long, payee: String?, balanceAfter: Long? = 5_000_000L) =
        Transaction(id, t, Direction.OUT, amount, payee, balanceAfter, null, "test")

    /** 20 lần chuyển nhỏ lúc ~12h cho 3 người quen. */
    private fun seededEngine(): RiskEngine {
        val e = RiskEngine()
        val payees = listOf("111111", "222222", "333333")
        for (i in 0 until 20) {
            e.assess(tx("h$i", ts(1 + i % 9, 12, i), 200_000L + (i % 5) * 50_000L, payees[i % 3], 3_000_000L + i))
        }
        return e
    }

    // ------------------------------------------------------------ parser

    @Test fun parse_vcb_style() {
        val t = TransactionParser.parse(
            "VCB Digibank: 14/10/2026 10:30 So du TK VCB - 0011001234567 -500,000 VND. " +
                "So du cuoi: 10,000,000 VND. Ref MBVCB.123.NGUYEN VAN A chuyen tien", "VCB", 1L)!!
        assertEquals(Direction.OUT, t.direction)
        assertEquals(500_000L, t.amountVnd)
        assertEquals(10_000_000L, t.balanceAfterVnd)
    }

    @Test fun parse_mb_style_with_account() {
        val t = TransactionParser.parse(
            "TK 0123456789|GD: -2,000,000VND 14/10/26 09:00|SD: 8,000,000VND|ND: CHUYEN TIEN DEN 9704123456789 NGUYEN VAN B",
            "MBBank", 1L)!!
        assertEquals(Direction.OUT, t.direction)
        assertEquals(2_000_000L, t.amountVnd)
        assertEquals(8_000_000L, t.balanceAfterVnd)
        assertEquals("9704123456789", t.counterparty)
    }

    @Test fun parse_incoming() {
        val t = TransactionParser.parse(
            "TK 19031234567 +2,000,000 VND luc 14-10-2026 10:30. So du 5,000,000 VND. ND: NGUYEN VAN C chuyen tien", "TCB", 1L)!!
        assertEquals(Direction.IN, t.direction)
        assertEquals(2_000_000L, t.amountVnd)
    }

    @Test fun parse_unsigned_with_keyword() {
        val t = TransactionParser.parse(
            "Tai khoan 0123456789 giam 300,000 VND luc 10:00. So du: 1,200,000 VND", "X", 1L)!!
        assertEquals(Direction.OUT, t.direction)
        assertEquals(300_000L, t.amountVnd)
        assertEquals(1_200_000L, t.balanceAfterVnd)
    }

    @Test fun otp_is_ignored() {
        assertNull(TransactionParser.parse("Ma OTP cua ban la 123456. TK 0123456789", "X", 1L))
    }

    // ------------------------------------------------------------ engine

    @Test fun normal_transfer_is_low() {
        val a = seededEngine().assess(tx("n1", ts(20, 12, 5), 300_000L, "111111"))!!
        assertEquals(RiskLevel.LOW, a.level)
    }

    @Test fun call_then_big_transfer_to_new_payee_at_night_is_high() {
        val e = seededEngine()
        val t = ts(20, 2, 10)
        e.recordContext(ContextEvent(ContextType.CALL, t - 15 * 60_000L, fromContact = false, durationMs = 20 * 60_000L))
        val a = e.assess(tx("s1", t, 30_000_000L, "999999", balanceAfter = 2_000_000L))!!
        assertEquals(RiskLevel.HIGH, a.level)
        assertTrue(a.reasons.isNotEmpty())
    }

    @Test fun duplicate_sms_and_notification_are_collapsed() {
        val e = RiskEngine()
        val msg = "TK 0123456789|GD: -1,000,000VND|SD: 4,000,000VND|ND: test"
        assertNotNull(e.onBankMessage(msg, "SMS", 1_000L))
        assertNull(e.onBankMessage(msg, "notif", 5_000L))
    }

    @Test fun feedback_changes_model_and_roundtrips() {
        val e = seededEngine()
        val before = e.exportModel()
        val a = e.assess(tx("f1", ts(21, 12, 5), 3_000_000L, "888888"))!!
        assertTrue(e.feedback(a.tx.id, true))
        val after = e.exportModel()
        assertNotEquals(before, after)
        assertTrue(RiskEngine().importModel(after))
    }

    @Test fun model_learns_to_raise_probability() {
        val m = RiskModel.default()
        val x = DoubleArray(10).also { it[Features.NEW_PAYEE] = 1.0; it[Features.LARGE_ABS] = 0.5 }
        val p0 = m.probability(x)
        repeat(5) { m.learn(x, true) }
        assertTrue(m.probability(x) > p0)
    }
}
