package vn.scamshield.finance

import kotlin.math.exp

/** Chỉ số các đặc trưng trong vector đầu vào của mô hình. */
internal object Features {
    const val AMOUNT_Z = 0
    const val NEW_PAYEE = 1
    const val ODD_HOUR = 2
    const val BURST = 3
    const val DRAIN = 4
    const val NOTE_RISK = 5
    const val CTX_CALL = 6
    const val CTX_FLAG = 7
    const val CTX_CALL_X_NEW = 8
    const val LARGE_ABS = 9
    const val SIZE = 10

    val REASONS = arrayOf(
        "Số tiền lớn bất thường so với các lần chuyển trước của bạn",
        "Người nhận mới, chưa từng chuyển trước đây",
        "Chuyển vào khung giờ bạn hiếm khi giao dịch",
        "Nhiều giao dịch dồn dập trong thời gian ngắn",
        "Chuyển gần hết số dư trong tài khoản",
        "Nội dung chuyển khoản có từ khóa thường gặp trong lừa đảo",
        "Vừa có cuộc gọi dài từ số lạ trước khi chuyển tiền",
        "Ứng dụng vừa cảnh báo cuộc gọi/tin nhắn nghi lừa đảo trước đó",
        "Chuyển cho người nhận mới ngay sau cuộc gọi từ số lạ",
        "Giá trị giao dịch lớn"
    )
}

/**
 * Hồi quy logistic có thể giải thích được (trọng số >= 0 nên mọi đặc trưng chỉ làm tăng rủi ro).
 * Khởi đầu từ trọng số "tiên nghiệm" do chuyên gia đặt, sau đó tự học dần từ phản hồi của người dùng
 * (SGD + kéo nhẹ về tiên nghiệm để không bị lệch khi có ít phản hồi).
 */
class RiskModel private constructor(
    private val weights: DoubleArray,
    private var bias: Double
) {
    fun logit(x: DoubleArray): Double {
        var s = bias
        for (i in x.indices) s += weights[i] * x[i]
        return s
    }

    fun probability(x: DoubleArray): Double = 1.0 / (1.0 + exp(-logit(x)))

    internal fun contributions(x: DoubleArray): DoubleArray =
        DoubleArray(x.size) { weights[it] * x[it] }

    /** Một bước học từ phản hồi: scam=true nếu người dùng xác nhận đây là lừa đảo. */
    fun learn(x: DoubleArray, scam: Boolean) {
        val y = if (scam) 1.0 else 0.0
        val err = (probability(x) - y) * (if (scam) POS_WEIGHT else 1.0)
        for (i in weights.indices) {
            val grad = err * x[i] + L2 * (weights[i] - PRIOR_W[i])
            weights[i] = (weights[i] - LR * grad).coerceIn(0.0, 5.0)
        }
        bias = (bias - LR * (err + L2 * (bias - PRIOR_B))).coerceIn(-6.0, -0.5)
    }

    fun serialize(): String = "$bias;${weights.joinToString(",")}"

    companion object {
        private val PRIOR_W = doubleArrayOf(1.2, 1.6, 0.9, 1.1, 1.5, 2.2, 0.8, 2.0, 1.8, 1.0)
        private const val PRIOR_B = -3.2
        private const val LR = 0.15
        private const val L2 = 0.01
        private const val POS_WEIGHT = 2.0   // bỏ sót lừa đảo tệ hơn báo nhầm

        fun default(): RiskModel = RiskModel(PRIOR_W.copyOf(), PRIOR_B)

        fun deserialize(s: String): RiskModel? {
            val parts = s.split(";")
            if (parts.size != 2) return null
            val b = parts[0].toDoubleOrNull() ?: return null
            val w = parts[1].split(",").map { it.toDoubleOrNull() ?: return null }
            if (w.size != Features.SIZE) return null
            return RiskModel(w.toDoubleArray(), b)
        }
    }
}
