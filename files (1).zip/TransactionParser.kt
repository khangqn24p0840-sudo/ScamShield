package vn.scamshield.finance

/**
 * Tách giao dịch từ nội dung SMS biến động số dư hoặc thông báo của app ngân hàng.
 * Là bộ parser "tổng quát"; mỗi ngân hàng nên bổ sung mẫu riêng sau khi thử trên tin thật.
 */
object TransactionParser {

    private val LOOKS_BANK =
        Regex("""(?<![a-z])(?:tk|stk|so du|sd|gd|giao dich|bien dong)(?![a-z])""")
    private val SIGNED_AMOUNT =
        Regex("""([+-])\s?(\d{1,3}(?:[.,]\d{3})+|\d+)\s?(?:vnd|d)(?![a-z0-9])""")
    private val UNSIGNED_AMOUNT =
        Regex("""(?<![\d.,])(\d{1,3}(?:[.,]\d{3})+|\d+)\s?(?:vnd|d)(?![a-z0-9])""")
    private val BALANCE =
        Regex("""(?<![a-z])(?:so du cuoi|so du|sd)\s*:?\s*(\d[\d.,]*)\s?(?:vnd|d)(?![a-z0-9])""")
    private val NOTE =
        Regex("""(?<![a-z])(?:nd|noi dung|content)\s*:\s*(.+)""")

    private val OUT_ACCOUNT =
        Regex("""(?<![a-z])(?:den|toi|nguoi nhan|ben nhan|tk nhan)\s*:?\s*(?:tk\s*)?(\d{6,})""")
    private val IN_ACCOUNT =
        Regex("""(?<![a-z])(?:tu|nguoi gui|ben gui)\s*:?\s*(?:tk\s*)?(\d{6,})""")
    private val OUT_NAME =
        Regex("""(?<![a-z])(?:den|toi|nguoi nhan|ben nhan)\s*:?\s+([a-z]+(?: [a-z]+){1,4})""")
    private val IN_NAME =
        Regex("""(?<![a-z])(?:tu|nguoi gui|ben gui)\s*:?\s+([a-z]+(?: [a-z]+){1,4})""")

    private val NAME_STOP = setOf(
        "dong", "tai", "khoan", "tk", "so", "luc", "ngay", "viec", "day", "may", "ban", "vnd"
    )
    private val OUT_WORDS = Regex("""(?<![a-z])(?:giam|thanh toan|rut tien|ghi no|tru tien)(?![a-z])""")
    private val IN_WORDS = Regex("""(?<![a-z])(?:tang|ghi co|nhan duoc|nap tien|cong tien)(?![a-z])""")

    private const val MAX_AMOUNT = 50_000_000_000L

    /** @return null nếu không phải tin biến động số dư (hoặc là OTP). */
    fun parse(raw: String, source: String?, receivedAt: Long): Transaction? {
        val t = raw.fold().replace(Regex("\\s+"), " ").trim()
        if (t.contains("otp") || t.contains("ma xac thuc")) return null
        if (!LOOKS_BANK.containsMatchIn(t)) return null

        val balanceMatch = BALANCE.find(t)
        val balance = balanceMatch?.let { toVnd(it.groupValues[1]) }

        val amount: Long
        val dir: Direction
        val signed = SIGNED_AMOUNT.find(t)
        if (signed != null) {
            dir = if (signed.groupValues[1] == "+") Direction.IN else Direction.OUT
            amount = toVnd(signed.groupValues[2]) ?: return null
        } else {
            val m = UNSIGNED_AMOUNT.findAll(t).firstOrNull { cand ->
                balanceMatch == null || cand.range.first !in balanceMatch.range
            } ?: return null
            val isOut = OUT_WORDS.containsMatchIn(t)
            val isIn = IN_WORDS.containsMatchIn(t)
            dir = when {
                isOut && !isIn -> Direction.OUT
                isIn && !isOut -> Direction.IN
                else -> return null
            }
            amount = toVnd(m.groupValues[1]) ?: return null
        }
        if (amount <= 0 || amount > MAX_AMOUNT) return null

        val note = NOTE.find(t)?.groupValues?.get(1)?.trim()?.take(200)
        val counterparty = findCounterparty(t, dir)
        val id = "$receivedAt-${dir.name}-$amount-${balance ?: 0}"
        return Transaction(id, receivedAt, dir, amount, counterparty, balance, note, source)
    }

    private fun findCounterparty(t: String, dir: Direction): String? {
        val acc = if (dir == Direction.OUT) OUT_ACCOUNT else IN_ACCOUNT
        acc.find(t)?.let { return it.groupValues[1] }
        val name = if (dir == Direction.OUT) OUT_NAME else IN_NAME
        val n = name.find(t)?.groupValues?.get(1)?.trim() ?: return null
        return if (n.substringBefore(' ') in NAME_STOP) null else n
    }

    private fun toVnd(s: String): Long? =
        s.replace(".", "").replace(",", "").toLongOrNull()
}
