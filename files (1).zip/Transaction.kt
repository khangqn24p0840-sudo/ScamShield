package vn.scamshield.finance

import java.text.Normalizer

enum class Direction { IN, OUT }

/** Một giao dịch đã được chuẩn hóa từ SMS / thông báo ngân hàng. */
data class Transaction(
    val id: String,
    val timestamp: Long,          // epoch ms, thời điểm nhận tin
    val direction: Direction,
    val amountVnd: Long,
    val counterparty: String?,    // số tài khoản (ưu tiên) hoặc tên người nhận/gửi, đã bỏ dấu
    val balanceAfterVnd: Long?,
    val note: String?,
    val source: String?           // số tổng đài SMS hoặc package app ngân hàng
)

private val COMBINING_MARKS = Regex("\\p{Mn}+")

/** Bỏ dấu tiếng Việt + chữ thường để so khớp từ khóa/regex ổn định. */
internal fun String.fold(): String =
    Normalizer.normalize(this, Normalizer.Form.NFD)
        .replace(COMBINING_MARKS, "")
        .replace('đ', 'd')
        .replace('Đ', 'D')
        .replace('−', '-')
        .lowercase()
