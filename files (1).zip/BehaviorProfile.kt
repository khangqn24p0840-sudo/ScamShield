package vn.scamshield.finance

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max

/**
 * Hồ sơ hành vi chuyển tiền của CHÍNH CHỦ MÁY (lưu trên thiết bị, không gửi đi đâu).
 * Chỉ ghi nhận giao dịch chuyển đi. Không thread-safe: RiskEngine đã đồng bộ hóa.
 */
class BehaviorProfile(
    private val maxHistory: Int = 500,
    private val timeZone: TimeZone = TimeZone.getDefault()
) {
    private val history = ArrayList<Transaction>()      // cũ -> mới
    private val payeeCount = HashMap<String, Int>()
    private val hourHist = IntArray(24)

    fun size(): Int = history.size

    fun observe(tx: Transaction) {
        if (tx.direction != Direction.OUT) return
        if (history.any { it.id == tx.id }) return
        history.add(tx)
        tx.counterparty?.let { payeeCount[it] = (payeeCount[it] ?: 0) + 1 }
        hourHist[hourOf(tx.timestamp)]++
        while (history.size > maxHistory) dropAt(0)
    }

    /** Dùng khi người dùng xác nhận giao dịch là lừa đảo: không để nó thành "thói quen". */
    fun forget(txId: String) {
        val i = history.indexOfFirst { it.id == txId }
        if (i >= 0) dropAt(i)
    }

    fun isNewPayee(key: String?): Boolean = key != null && !payeeCount.containsKey(key)

    /** Độ lệch (đơn vị ~độ lệch chuẩn, trên thang log) so với số tiền thường chuyển. null nếu chưa đủ dữ liệu. */
    fun amountZ(amount: Long): Double? {
        if (history.size < MIN_SAMPLES) return null
        val logs = history.map { ln(max(it.amountVnd, 1L).toDouble()) }.sorted()
        val med = median(logs)
        val mad = median(logs.map { abs(it - med) }.sorted())
        val scale = max(mad * 1.4826, 0.25)             // sàn để không bị "nổ" khi thói quen quá đều
        return (ln(max(amount, 1L).toDouble()) - med) / scale
    }

    fun isUnusualHour(ts: Long): Boolean {
        val h = hourOf(ts)
        if (history.size < 20) return h in 0..4        // chưa đủ dữ liệu: dùng giả định chung
        val near = hourHist[(h + 23) % 24] + hourHist[h] + hourHist[(h + 1) % 24]
        return near.toDouble() / history.size < 0.04
    }

    /** 0..1: số lần chuyển đi trong 10 phút trước đó (>=3 lần -> 1.0). */
    fun burst(ts: Long): Double {
        val from = ts - 10 * 60_000L
        val n = history.count { it.timestamp in from until ts }
        return (n / 3.0).coerceAtMost(1.0)
    }

    private fun dropAt(i: Int) {
        val tx = history.removeAt(i)
        tx.counterparty?.let { k ->
            val n = (payeeCount[k] ?: 1) - 1
            if (n <= 0) payeeCount.remove(k) else payeeCount[k] = n
        }
        val h = hourOf(tx.timestamp)
        if (hourHist[h] > 0) hourHist[h]--
    }

    private fun hourOf(ts: Long): Int {
        val c = Calendar.getInstance(timeZone)
        c.timeInMillis = ts
        return c.get(Calendar.HOUR_OF_DAY)
    }

    private fun median(sorted: List<Double>): Double {
        val n = sorted.size
        return if (n % 2 == 1) sorted[n / 2] else (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0
    }

    companion object {
        const val MIN_SAMPLES = 8
    }
}
