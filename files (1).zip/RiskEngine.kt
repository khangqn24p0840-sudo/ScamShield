package vn.scamshield.finance

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max

enum class RiskLevel { LOW, MEDIUM, HIGH }
enum class ContextType { CALL, SCAM_FLAG }

/**
 * Sự kiện ngữ cảnh do các thành phần có sẵn của app đẩy vào:
 *  - CALL: từ PhoneStateReceiver/CallGuard (fromContact = số có trong danh bạ)
 *  - SCAM_FLAG: khi ScamDetector đã gắn cờ một cuộc gọi/SMS/tin nhắn mạng xã hội (strength 0..1)
 */
data class ContextEvent(
    val type: ContextType,
    val timestamp: Long,
    val fromContact: Boolean = false,
    val ongoing: Boolean = false,
    val durationMs: Long = 0L,
    val strength: Double = 1.0
)

data class Assessment(
    val tx: Transaction,
    val probability: Double,
    val level: RiskLevel,
    val reasons: List<String>,
    val features: List<Double>,
    val advice: String
)

class RiskEngine(
    private val profile: BehaviorProfile = BehaviorProfile(),
    private var model: RiskModel = RiskModel.default()
) {
    private val context = ArrayList<ContextEvent>()
    private val pending = LinkedHashMap<String, Assessment>()
    private val seen = HashMap<String, Long>()

    @Synchronized
    fun recordContext(e: ContextEvent) {
        context.add(e)
        val cutoff = e.timestamp - 2 * HOUR
        context.removeAll { it.timestamp < cutoff }
    }

    /** Gọi từ SmsReceiver / SocialListener với nội dung tin của ngân hàng. null = không phải giao dịch hoặc bị trùng. */
    @Synchronized
    fun onBankMessage(text: String, source: String?, receivedAt: Long): Assessment? {
        val tx = TransactionParser.parse(text, source, receivedAt) ?: return null
        return assess(tx)
    }

    @Synchronized
    fun assess(tx: Transaction): Assessment? {
        // SMS và thông báo app thường đến cùng lúc cho một giao dịch -> bỏ bản trùng
        val key = "${tx.direction}|${tx.amountVnd}|${tx.balanceAfterVnd}"
        val last = seen[key]
        if (last != null && abs(tx.timestamp - last) < 120_000L) return null
        seen[key] = tx.timestamp
        if (seen.size > 200) seen.entries.removeAll { tx.timestamp - it.value > 600_000L }

        if (tx.direction == Direction.IN) {
            return Assessment(tx, 0.0, RiskLevel.LOW, emptyList(), List(Features.SIZE) { 0.0 }, "")
        }

        val x = buildFeatures(tx)
        val p = model.probability(x)
        val level = when {
            p >= HIGH_T -> RiskLevel.HIGH
            p >= MEDIUM_T -> RiskLevel.MEDIUM
            else -> RiskLevel.LOW
        }
        val contrib = model.contributions(x)
        val reasons = contrib.indices
            .filter { contrib[it] >= 0.4 }
            .sortedByDescending { contrib[it] }
            .map { Features.REASONS[it] }

        profile.observe(tx)   // sau khi tính, để giao dịch này không tự làm "bình thường hóa" chính nó

        val a = Assessment(tx, p, level, reasons, x.toList(), adviceFor(level))
        pending[tx.id] = a
        if (pending.size > 100) pending.remove(pending.keys.first())
        return a
    }

    /**
     * Rủi ro "trước khi chuyển", chỉ dựa trên ngữ cảnh (đang/vừa có cuộc gọi lạ, vừa có cảnh báo).
     * Gọi khi phát hiện app ngân hàng được mở để quyết định có hiện cảnh báo chủ động hay không.
     */
    @Synchronized
    fun preTransferRisk(now: Long): Double {
        val (call, flag) = contextSignals(now)
        val x = DoubleArray(Features.SIZE)
        x[Features.CTX_CALL] = call
        x[Features.CTX_FLAG] = flag
        x[Features.NEW_PAYEE] = 0.5                 // chưa biết người nhận: giả định nửa chừng
        x[Features.CTX_CALL_X_NEW] = call * 0.5
        return model.probability(x)
    }

    /** Phản hồi của người dùng -> mô hình tự học. @return false nếu giao dịch đã quá cũ/không còn lưu. */
    @Synchronized
    fun feedback(txId: String, isScam: Boolean): Boolean {
        val a = pending[txId] ?: return false
        model.learn(a.features.toDoubleArray(), isScam)
        if (isScam) profile.forget(txId)
        pending.remove(txId)
        return true
    }

    @Synchronized fun exportModel(): String = model.serialize()

    @Synchronized
    fun importModel(s: String): Boolean {
        val m = RiskModel.deserialize(s) ?: return false
        model = m
        return true
    }

    // ---------------------------------------------------------------- đặc trưng

    private fun buildFeatures(tx: Transaction): DoubleArray {
        val x = DoubleArray(Features.SIZE)
        val z = profile.amountZ(tx.amountVnd) ?: 0.0
        x[Features.AMOUNT_Z] = z.coerceIn(0.0, 5.0) / 5.0
        x[Features.NEW_PAYEE] = if (profile.isNewPayee(tx.counterparty)) 1.0 else 0.0
        x[Features.ODD_HOUR] = if (profile.isUnusualHour(tx.timestamp)) 1.0 else 0.0
        x[Features.BURST] = profile.burst(tx.timestamp)
        x[Features.DRAIN] = drain(tx)
        x[Features.NOTE_RISK] = noteRisk(tx.note)
        val (call, flag) = contextSignals(tx.timestamp)
        x[Features.CTX_CALL] = call
        x[Features.CTX_FLAG] = flag
        x[Features.CTX_CALL_X_NEW] = call * x[Features.NEW_PAYEE]
        x[Features.LARGE_ABS] = (ln(tx.amountVnd / 5_000_000.0) / ln(20.0)).coerceIn(0.0, 1.0)
        return x
    }

    private fun drain(tx: Transaction): Double {
        val after = tx.balanceAfterVnd ?: return 0.0
        val before = after + tx.amountVnd
        if (before <= 0) return 0.0
        val ratio = tx.amountVnd.toDouble() / before
        return ((ratio - 0.5) / 0.5).coerceIn(0.0, 1.0)
    }

    private fun noteRisk(note: String?): Double {
        if (note == null) return 0.0
        val t = note.fold()
        val hits = RISKY_NOTE_WORDS.count { t.contains(it) }
        return (hits / 2.0).coerceAtMost(1.0)
    }

    /** @return (cuộc gọi lạ trong 30 phút trước, cảnh báo scam trong 60 phút trước) */
    private fun contextSignals(ts: Long): Pair<Double, Double> {
        var call = 0.0
        var flag = 0.0
        for (e in context) {
            val age = ts - e.timestamp
            if (age < 0) continue
            when (e.type) {
                ContextType.CALL ->
                    if (!e.fromContact && age <= 30 * MINUTE && (e.ongoing || e.durationMs >= 45_000L)) call = 1.0
                ContextType.SCAM_FLAG ->
                    if (age <= HOUR) flag = max(flag, e.strength.coerceIn(0.0, 1.0))
            }
        }
        return Pair(call, flag)
    }

    private fun adviceFor(level: RiskLevel): String = when (level) {
        RiskLevel.HIGH ->
            "Có nhiều dấu hiệu lừa đảo. Nếu bạn không tự chủ động chuyển, hoặc đang được ai đó hướng dẫn qua điện thoại: " +
            "hãy gọi ngay tổng đài ngân hàng để yêu cầu tra soát/tạm khóa giao dịch và trình báo công an."
        RiskLevel.MEDIUM ->
            "Giao dịch khác thường so với thói quen của bạn. Hãy chắc chắn chính bạn đã thực hiện và biết rõ người nhận."
        RiskLevel.LOW -> ""
    }

    companion object {
        private const val MINUTE = 60_000L
        private const val HOUR = 60 * MINUTE
        const val MEDIUM_T = 0.40
        const val HIGH_T = 0.65

        private val RISKY_NOTE_WORDS = listOf(
            "cong an", "toa an", "vien kiem sat", "phong toa", "tam giu", "xac minh", "dieu tra",
            "nhiem vu", "hoa hong", "dat coc", "dau tu", "trung thuong", "nhan thuong",
            "hoan tien", "tai khoan an toan", "kich hoat"
        )
    }
}
