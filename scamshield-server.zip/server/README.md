# ScamShield Server

Máy chủ quản lý tài khoản cho ứng dụng ScamShield VN: đăng ký/đăng nhập, khảo sát, thống kê ẩn danh (chỉ khi người dùng đồng ý), danh sách số lừa đảo do cộng đồng báo cáo, phân tích văn bản bằng AI và chuyển tiếp ảnh tới dịch vụ nhận diện giả mạo.

## Chạy thử trên máy
```bash
npm install
JWT_SECRET=$(openssl rand -hex 32) ADMIN_KEY=khoa-quan-tri npm start
npm test        # chạy kiểm thử tự động
```

## Biến môi trường
| Biến | Bắt buộc | Ý nghĩa |
|---|---|---|
| JWT_SECRET | Có | Chuỗi ngẫu nhiên ≥ 32 ký tự để ký phiên đăng nhập |
| ADMIN_KEY | Nên có | Khóa gọi các API /admin (header x-admin-key) |
| DB_PATH | Không | Đường dẫn tệp SQLite (mặc định data.db) |
| ANTHROPIC_API_KEY | Không | Bật phân tích văn bản bằng Claude |
| CLAUDE_MODEL | Không | Mặc định claude-sonnet-5-5 |
| DETECTOR_URL, DETECTOR_KEY | Không | Dịch vụ nhận diện ảnh giả mạo do bạn tự triển khai |

## Triển khai (ví dụ Render, Railway, Fly.io…)
1. Đưa thư mục này lên một repo GitHub.
2. Tạo Web Service từ repo, chọn **Docker** (đã có Dockerfile).
3. Đặt các biến môi trường ở bảng trên; gắn ổ đĩa lưu trữ (volume) tại `/data` để không mất cơ sở dữ liệu.
4. Dịch vụ sẽ có địa chỉ **https://...**; nhập địa chỉ đó vào ô "Địa chỉ máy chủ" trong app.

## API
| Phương thức | Đường dẫn | Mô tả |
|---|---|---|
| POST | /api/register, /api/login | Trả về `token` |
| GET / DELETE | /api/me | Thông tin / xóa tài khoản và toàn bộ dữ liệu |
| POST | /api/consent | `{analytics:true/false}` bật/tắt gửi thống kê ẩn danh |
| POST / GET | /api/survey | Gửi / xem câu trả lời khảo sát |
| POST | /api/events | `{kind, level}` – chỉ nhận khi người dùng đã đồng ý |
| POST | /api/report-number | Báo cáo một số điện thoại lừa đảo |
| GET | /api/blocklist | Các số có ≥ 3 người báo cáo |
| POST | /api/analyze/text | AI đánh giá văn bản (cần ANTHROPIC_API_KEY) |
| POST | /api/analyze/media | Chuyển ảnh tới DETECTOR_URL (trả 501 nếu chưa cấu hình) |
| GET/POST/DELETE | /admin/users, /admin/stats | Quản trị (header `x-admin-key`) |

Ví dụ quản trị:
```bash
curl -H "x-admin-key: KHOA" https://may-chu/admin/stats
curl -X POST -H "x-admin-key: KHOA" https://may-chu/admin/users/5/disable
```

## Dịch vụ nhận diện ảnh giả mạo (DETECTOR_URL)
Server **không kèm mô hình**. Bạn cần tự triển khai một dịch vụ nhận `POST {mime, data(base64)}` và trả `{ "score": 0..1 }` (1 = nhiều khả năng giả). Có thể dùng mô hình mã nguồn mở hoặc API của bên thứ ba. Kết quả nhận diện deepfake luôn không chắc chắn, app chỉ hiển thị như tham khảo.

## Quyền riêng tư và bảo mật
- Chỉ lưu: email, mật khẩu đã băm (bcrypt), câu trả lời khảo sát, sự kiện ẩn danh (loại + mức, chỉ khi đồng ý), số điện thoại được báo cáo.
- **Không** lưu nội dung tin nhắn, số tiền giao dịch, danh bạ hay âm thanh.
- Bắt buộc dùng HTTPS khi triển khai; đã bật helmet, giới hạn tần suất, khóa tài khoản qua API quản trị, người dùng tự xóa dữ liệu qua DELETE /api/me.
- Không đưa tệp .env, khóa API lên GitHub công khai. Sao lưu tệp cơ sở dữ liệu định kỳ.
