process.env.JWT_SECRET = 'x'.repeat(40); process.env.ADMIN_KEY = 'adminkey-test'; process.env.DB_PATH = ':memory:';
const assert = require('assert'); const app = require('../server');
const srv = app.listen(0, async () => {
  const base = 'http://127.0.0.1:' + srv.address().port;
  const call = async (m, p, b, h = {}) => { const r = await fetch(base + p, { method: m, headers: { 'content-type': 'application/json', ...h }, body: b ? JSON.stringify(b) : undefined }); let j = null; try { j = await r.json(); } catch {} return [r.status, j]; };
  try {
    let [s, j] = await call('POST', '/api/register', { email: 'a@x.vn', password: 'short' }); assert.equal(s, 400);
    [s, j] = await call('POST', '/api/register', { email: 'a@x.vn', password: 'matkhau123' }); assert.equal(s, 201);
    const tok = [j.token]; const A = (i = 0) => ({ authorization: 'Bearer ' + tok[i] });
    [s] = await call('POST', '/api/register', { email: 'a@x.vn', password: 'matkhau123' }); assert.equal(s, 409);
    [s] = await call('POST', '/api/login', { email: 'a@x.vn', password: 'sai-mat-khau' }); assert.equal(s, 401);
    [s, j] = await call('POST', '/api/login', { email: 'a@x.vn', password: 'matkhau123' }); assert.equal(s, 200);
    [s] = await call('GET', '/api/me'); assert.equal(s, 401);
    [s, j] = await call('GET', '/api/me', null, A()); assert.equal(j.surveyDone, false);
    [s] = await call('POST', '/api/survey', { answers: ['18-30', 'Hiếm'] }, A()); assert.equal(s, 200);
    [s, j] = await call('GET', '/api/me', null, A()); assert.equal(j.surveyDone, true);
    [s] = await call('POST', '/api/events', { kind: 'call', level: 1 }, A()); assert.equal(s, 204);   // chưa đồng ý -> bỏ qua
    await call('POST', '/api/consent', { analytics: true }, A());
    [s] = await call('POST', '/api/events', { kind: 'call', level: 1 }, A()); assert.equal(s, 201);
    [s] = await call('POST', '/api/events', { kind: 'hack', level: 9 }, A()); assert.equal(s, 400);
    for (let i = 0; i < 3; i++) { [s, j] = await call('POST', '/api/register', { email: `u${i}@x.vn`, password: 'matkhau123' }); tok.push(j.token); }
    for (let i = 0; i < 3; i++) await call('POST', '/api/report-number', { number: '+84 901 234 567' }, A(i + 1));
    [s, j] = await call('GET', '/api/blocklist', null, A()); assert.deepEqual(j.numbers, ['84901234567']);
    [s] = await call('POST', '/api/analyze/text', { text: 'xin chào' }, A()); assert.equal(s, 501);
    [s] = await call('POST', '/api/analyze/media', { mime: 'image/png', data: 'AAAA' }, A()); assert.equal(s, 501);
    [s] = await call('GET', '/admin/users'); assert.equal(s, 403);
    [s, j] = await call('GET', '/admin/stats', null, { 'x-admin-key': 'adminkey-test' }); assert.equal(j.users, 4);
    [s, j] = await call('GET', '/admin/users', null, { 'x-admin-key': 'adminkey-test' });
    await call('POST', `/admin/users/${j.users[0].id}/disable`, null, { 'x-admin-key': 'adminkey-test' });
    [s] = await call('GET', '/api/me', null, A(3)); assert.equal(s, 401);                               // đã bị khóa
    [s] = await call('DELETE', '/api/me', null, A()); assert.equal(s, 200);
    [s] = await call('GET', '/api/me', null, A()); assert.equal(s, 401);
    console.log('✅ Tất cả kiểm thử đạt'); srv.close(); process.exit(0);
  } catch (e) { console.error('❌ Lỗi kiểm thử:', e.message); srv.close(); process.exit(1); }
});
